#' Creates a `teal_modules` object.
#'
#' @description `r lifecycle::badge("stable")`
#' This function collects a list of `teal_modules` and `teal_module` objects and returns a `teal_modules` object
#' containing the passed objects.
#'
#' This function dictates what modules are included in a `teal` application. The internal structure of `teal_modules`
#' shapes the navigation panel of a `teal` application.
#'
#' @param ... (`teal_module` or `teal_modules`) see [module()] and [modules()] for more details
#' @param label (`character(1)`) label of modules collection (default `"root"`).
#' If using the `label` argument then it must be explicitly named.
#' For example `modules("lab", ...)` should be converted to `modules(label = "lab", ...)`
#'
#' @export
#'
#' @return object of class \code{teal_modules}. Object contains following fields
#' - `label`: taken from the `label` argument
#' - `children`: a list containing objects passed in `...`. List elements are named after
#' their `label` attribute converted to a valid `shiny` id.
#' @examples
#' library(shiny)
#'
#' app <- init(
#'   data = teal_data(dataset("iris", iris)),
#'   modules = modules(
#'     label = "Modules",
#'     modules(
#'       label = "Module",
#'       module(
#'         label = "Inner module",
#'         server = function(id, datasets) {
#'           moduleServer(
#'             id,
#'             module = function(input, output, session) {
#'               output$data <- renderDataTable(datasets$get_data("iris"))
#'             }
#'           )
#'         },
#'         ui = function(id, datasets) {
#'           ns <- NS(id)
#'           tagList(dataTableOutput(ns("data")))
#'         },
#'         filters = "all"
#'       )
#'     ),
#'     module(
#'       label = "Another module",
#'       server = function(id, datasets) {
#'         moduleServer(
#'           id,
#'           module = function(input, output, session) {
#'             output$text <- renderText("Another module")
#'           }
#'         )
#'       },
#'       ui = function(id, datasets) {
#'         ns <- NS(id)
#'         tagList(textOutput(ns("text")))
#'       },
#'       filters = NULL
#'     )
#'   )
#' )
#' \dontrun{
#' runApp(app)
#' }
modules <- function(..., label = "root") {
  checkmate::assert_string(label)
  submodules <- list(...)

  if (any(vapply(submodules, is.character, FUN.VALUE = logical(1)))) {
    stop(
      "The only character argument to modules() must be 'label' and it must be named, ",
      "change modules('lab', ...) to modules(label = 'lab', ...)"
    )
  }

  checkmate::assert_list(submodules, min.len = 1, any.missing = FALSE, types = c("teal_module", "teal_modules"))

  # name them so we can more easily access the children
  # beware however that the label of the submodules should not be changed as it must be kept synced
  labels <- vapply(submodules, function(submodule) submodule$label, character(1))
  names(submodules) <- make.unique(gsub("[^[:alnum:]]", "_", tolower(labels)), sep = "_")
  structure(
    list(
      label = label,
      children = submodules
    ),
    class = "teal_modules"
  )
}



#' Function which appends a teal_module onto the children of a teal_modules object
#' @keywords internal
#' @param modules `teal_modules`
#' @param module `teal_module` object to be appended onto the children of `modules`
#' @return `teal_modules` object with `module` appended
append_module <- function(modules, module) {
  checkmate::assert_class(modules, "teal_modules")
  checkmate::assert_class(module, "teal_module")
  modules$children <- c(modules$children, list(module))
  labels <- vapply(modules$children, function(submodule) submodule$label, character(1))
  names(modules$children) <- make.unique(gsub("[^[:alnum:]]", "_", tolower(labels)), sep = "_")
  modules
}

#' Does the object make use of the `arg`
#'
#' @param modules (`teal_module` or `teal_modules`) object
#' @param arg (`character(1)`) names of the arguments to be checked against formals of `teal` modules.
#' @return `logical` whether the object makes use of `arg`
#' @rdname is_arg_used
#' @keywords internal
is_arg_used <- function(modules, arg) {
  checkmate::assert_string(arg)
  UseMethod("is_arg_used", modules)
}

#' @rdname is_arg_used
#' @keywords internal
#' @export
is_arg_used.default <- function(modules, arg) {
  stop("is_arg_used function not implemented for this object")
}

#' @rdname is_arg_used
#' @export
#' @keywords internal
is_arg_used.teal_modules <- function(modules, arg) {
  any(unlist(lapply(modules$children, is_arg_used, arg)))
}

#' @rdname is_arg_used
#' @export
#' @keywords internal
is_arg_used.teal_module <- function(modules, arg) {
  is_arg_used(modules$server, arg) || is_arg_used(modules$ui, arg)
}

#' @rdname is_arg_used
#' @export
#' @keywords internal
is_arg_used.function <- function(modules, arg) {
  isTRUE(arg %in% names(formals(modules)))
}

#' Deprecated: Creates the root modules container
#'
#' @description `r lifecycle::badge("deprecated")`
#' This function is deprecated, you should call `teal::modules` directly instead.
#'
#' @details
#' The function [modules()] can also be used. The purpose of this
#' function is to not confuse the end-user as the label of the top-module
#' will not be displayed as a tab name (because the root is only one element
#' which has multiple children).
#'
#' @inheritParams modules
#'
#' @export
#' @examples
#' library(shiny)
#'
#' app <- init(
#'   data = teal_data(dataset("iris", iris)),
#'   modules = modules(
#'     module(
#'       label = "Module",
#'       server = function(id, datasets) {
#'         moduleServer(
#'           id,
#'           module = function(input, output, session) {
#'             output$data <- renderDataTable(datasets$get_data("iris"))
#'           }
#'         )
#'       },
#'       ui = function(id, datasets) {
#'         ns <- NS(id)
#'         tagList(dataTableOutput(ns("data")))
#'       },
#'       filters = "all"
#'     ),
#'     module(
#'       label = "Another module",
#'       server = function(id, datasets) {
#'         moduleServer(
#'           id,
#'           module = function(input, output, session) {
#'             output$text <- renderText("Another module")
#'           }
#'         )
#'       },
#'       ui = function(id, datasets) {
#'         ns <- NS(id)
#'         tagList(textOutput(ns("text")))
#'       },
#'       filters = NULL
#'     )
#'   )
#' )
#' \dontrun{
#' runApp(app)
#' }
root_modules <- function(...) {
  lifecycle::deprecate_soft(
    when = "0.10.2",
    what = "root_modules()",
    details = "Use `teal::modules` instead of `teal::root_modules`. `teal::root_modules` might be removed in future
      versions of `teal`."
  )

  if (nargs() == 0) {
    # we don't put this check at the modules level because we want to allow
    # empty modules that only have a filtering panel
    stop("You must provide at least one module.")
  }
  modules(label = "root", ...)
}


#' Creates a `teal_module` object.
#'
#' @description `r lifecycle::badge("stable")`
#' This function embeds a `shiny` module inside a `teal` application. One `teal_module` maps to one `shiny` module.
#'
#' @param label (`character(1)`) Label shown in the navigation item for the module.
#' @param server (`function`) `shiny` module with following arguments:
#'  - `id` - teal will set proper shiny namespace for this module (see [shiny::moduleServer()]).
#'  - `input`, `output`, `session` - (not recommended) then [shiny::callModule()] will be used to call a module.
#'  - `data` (optional) module will receive list of reactive (filtered) data specified in the `filters` argument. `filters`
#'   can't be NULL
#'  - `datasets` (optional) module will receive `FilteredData`. (See `[teal.slice::FilteredData]`).
#'  - `reporter` (optional) module will receive `Reporter`. (See [teal.reporter::Reporter]).
#   - `filter_panel_api` (optional) module will receive `FilterPanelAPI`. (See [teal.slice::FilterPanelAPI]).
#'  - `...` (optional) `server_args` elements will be passed to the module named argument or to the `...`.
#' @param ui (`function`) Shiny ui module function with following arguments:
#'  - `id` - teal will set proper shiny namespace for this module.
#'  - `data` (optional)  module will receive list of reactive (filtered) data specified in the `filters` argument.
#'  - `datasets` (optional)  module will receive `FilteredData`. (See `[teal.slice::FilteredData]`).
#'  - `...` (optional) `ui_args` elements will be passed to the module named argument or to the `...`.
#' @param filters (`character`) A vector with datanames that are relevant for the item. The
#'   filter panel will automatically update the shown filters to include only
#'   filters in the listed datasets. `NULL` will hide the filter panel,
#'   and the keyword `'all'` will show the filters of all datasets. `filters` can't be `NULL` when
#'   `data` argument is present in the `server` formals.
#' @param server_args (named `list`) with additional arguments passed on to the
#'   `server` function.
#' @param ui_args (named `list`) with additional arguments passed on to the
#'   `ui` function.
#'
#' @return object of class `teal_module`.
#' @export
#' @examples
#' library(shiny)
#'
#' app <- init(
#'   data = teal_data(dataset("iris", iris)),
#'   modules = list(
#'     module(
#'       label = "Module",
#'       server = function(id, datasets) {
#'         moduleServer(
#'           id,
#'           module = function(input, output, session) {
#'             output$data <- renderDataTable(datasets$get_data("iris"))
#'           }
#'         )
#'       },
#'       ui = function(id, datasets) {
#'         ns <- NS(id)
#'         tagList(dataTableOutput(ns("data")))
#'       }
#'     )
#'   )
#' )
#' \dontrun{
#' runApp(app)
#' }
module <- function(label = "module",
                   server = function(id, ...) {
                     moduleServer(id, function(input, output, session) {})
                   },
                   ui = function(id, ...) {
                     tags$p(paste0("This module has no UI (id: ", id, " )"))
                   },
                   filters = "all",
                   server_args = NULL,
                   ui_args = NULL) {
  checkmate::assert_string(label)
  checkmate::assert_function(server)
  checkmate::assert_function(ui)
  checkmate::assert_character(filters, min.len = 1, null.ok = TRUE, any.missing = FALSE)
  checkmate::assert_list(server_args, null.ok = TRUE, names = "named")
  checkmate::assert_list(ui_args, null.ok = TRUE, names = "named")

  server_formals <- names(formals(server))
  if (!(
    "id" %in% server_formals ||
      all(c("input", "output", "session") %in% server_formals)
  )) {
    stop(
      "\nmodule() `server` argument requires a function with following arguments:",
      "\n - id - teal will set proper shiny namespace for this module.",
      "\n - input, output, session (not recommended) - then shiny::callModule will be used to call a module.",
      "\n\nFollowing arguments can be used optionaly:",
      "\n - `data` - module will receive list of reactive (filtered) data specified in the `filters` argument",
      "\n - `datasets` - module will receive `FilteredData`. See `help(teal.slice::FilteredData)`",
      "\n - `reporter` - module will receive `Reporter`. See `help(teal.reporter::Reporter)`",
      "\n - `filter_panel_api` - module will receive `FilterPanelAPI`. (See [teal.slice::FilterPanelAPI]).",
      "\n - `...` server_args elements will be passed to the module named argument or to the `...`"
    )
  }

  srv_extra_args <- setdiff(names(server_args), server_formals)
  if (length(srv_extra_args) > 0 && !"..." %in% server_formals) {
    stop(
      "\nFollowing `server_args` elements have no equivalent in the formals of the `server`:\n",
      paste(paste(" -", srv_extra_args), collapse = "\n"),
      "\n\nUpdate the `server` arguments by including above or add `...`"
    )
  }

  if ("data" %in% server_formals && is.null(filters)) {
    stop(
      "\n`filters = NULL` indicates that the module doesn't need any data while it has the `data` in formals.",
      "\nPlease specify `filters` with the names of needed datasets or exclude `data` from the arguments."
    )
  }

  ui_formals <- names(formals(ui))
  if (!"id" %in% ui_formals) {
    stop(
      "\nmodule() `ui` argument requires a function with following arguments:",
      "\n - id - teal will set proper shiny namespace for this module.",
      "\n\nFollowing arguments can be used optionaly:",
      "\n - `data` - module will receive list of reactive (filtered) data specied in the `filters` argument",
      "\n - `datasets` - module will receive `FilteredData`. See `help(teal.slice::FilteredData)`",
      "\n - `...` ui_args elements will be passed to the module argument of the same name or to the `...`"
    )
  }

  ui_extra_args <- setdiff(names(ui_args), ui_formals)
  if (length(ui_extra_args) > 0 && !"..." %in% ui_formals) {
    stop(
      "\nFollowing `ui_args` elements have no equivalent in the formals of `ui`:\n",
      paste(paste(" -", ui_extra_args), collapse = "\n"),
      "\n\nUpdate the `ui` arguments by including above or add `...`"
    )
  }

  structure(
    list(
      label = label,
      server = server, ui = ui, filters = filters,
      server_args = server_args, ui_args = ui_args
    ),
    class = "teal_module"
  )
}


#' Get module depth
#'
#' Depth starts at 0, so a single `teal.module` has depth 0.
#' Nesting it increases overall depth by 1.
#'
#' @inheritParams init
#' @param depth optional, integer determining current depth level
#'
#' @return depth level for given module
#' @keywords internal
#'
#' @examples
#' mods <- modules(
#'   label = "d1",
#'   modules(
#'     label = "d2",
#'     modules(
#'       label = "d3",
#'       module(label = "aaa1"), module(label = "aaa2"), module(label = "aaa3")
#'     ),
#'     module(label = "bbb")
#'   ),
#'   module(label = "ccc")
#' )
#' stopifnot(teal:::modules_depth(mods) == 3L)
#'
#' mods <- modules(
#'   label = "a",
#'   modules(
#'     label = "b1", module(label = "c")
#'   ),
#'   module(label = "b2")
#' )
#' stopifnot(teal:::modules_depth(mods) == 2L)
modules_depth <- function(modules, depth = 0L) {
  checkmate::assert(
    checkmate::check_class(modules, "teal_module"),
    checkmate::check_class(modules, "teal_modules")
  )
  checkmate::assert_int(depth, lower = 0)
  if (inherits(modules, "teal_modules")) {
    max(vapply(modules$children, modules_depth, integer(1), depth = depth + 1L))
  } else {
    depth
  }
}

#' Converts `teal_modules` to a string
#'
#' @param x (`teal_modules`) to print
#' @param indent (`integer`) indent level;
#'   each submodule is indented one level more
#' @param ... (optional) additional parameters to pass to recursive calls of `toString`
#' @return (`character`)
#' @export
#' @rdname modules
toString.teal_modules <- function(x, indent = 0, ...) { # nolint
  # argument must be `x` to be consistent with base method
  paste(c(
    paste0(rep(" ", indent), "+ ", x$label),
    unlist(lapply(x$children, toString, indent = indent + 1, ...))
  ), collapse = "\n")
}

#' Converts `teal_module` to a string
#'
#' @inheritParams toString.teal_modules
#' @param x `teal_module`
#' @param ... ignored
#' @export
#' @rdname module
toString.teal_module <- function(x, indent = 0, ...) { # nolint
  paste0(paste(rep(" ", indent), collapse = ""), "+ ", x$label, collapse = "")
}

#' Prints `teal_modules`
#' @param x `teal_modules`
#' @param ... parameters passed to `toString`
#' @export
#' @rdname modules
print.teal_modules <- function(x, ...) {
  s <- toString(x, ...)
  cat(s)
  return(invisible(s))
}

#' Prints `teal_module`
#' @param x `teal_module`
#' @param ... parameters passed to `toString`
#' @export
#' @rdname module
print.teal_module <- print.teal_modules
