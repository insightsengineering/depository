## ---- message=FALSE-----------------------------------------------------------
library(teal)
example_module <- function(label = "example teal module") {
  checkmate::assert_string(label)
  module(
    label,
    server = function(id, datasets) {
      moduleServer(id, function(input, output, session) {
        output$text <- renderPrint(datasets$get_data(input$dataname, filtered = TRUE))
      })
    },
    ui = function(id, datasets) {
      ns <- NS(id)
      teal.widgets::standard_layout(
        output = verbatimTextOutput(ns("text")),
        encoding = selectInput(ns("dataname"), "Choose a dataset", choices = datasets$datanames())
      )
    },
    filters = "all"
  )
}

## -----------------------------------------------------------------------------
library(teal)

# ui function for the module
# histogram_var is a teal.transform::data_extract_spec object
# specifying which columns of which datasets users can choose
ui_histogram_example <- function(id, datasets, histogram_var) {
  ns <- NS(id)
  teal.widgets::standard_layout(
    output = plotOutput(ns("plot")),
    encoding = div(
      teal.transform::data_extract_ui(
        id = ns("histogram_var"),
        label = "Variable",
        data_extract_spec = histogram_var
      )
    ),
    # we have a show R code button to show the code needed
    # to generate the histogram
    forms = teal::get_rcode_ui(ns("rcode"))
  )
}

# server function for the module
# histogram_var is a teal.transform::data_extract_spec object
# specifying which columns of which datasets users can choose
srv_histogram_example <- function(id, datasets, histogram_var) {
  moduleServer(id, function(input, output, session) {
    # initialize the reproducibility part of teal (i.e. "chunks")
    teal.code::init_chunks()

    # get the selected dataset and column from the UI
    extracted <- teal.transform::data_extract_srv("histogram_var", datasets, histogram_var)
    dataname <- reactive(extracted()$dataname)
    selected <- reactive(extracted()$select)

    # the reactive which adds the code to plot the histogram into the chunks
    plot_code <- reactive({
      validate(need(length(selected) == 1, "Please select a variable"))

      # take the filtered data from the datasets object and add it into the chunks environment
      new_env <- new.env()
      assign(dataname(), datasets$get_data(dataname(), filtered = TRUE), envir = new_env)
      teal.code::chunks_reset(envir = new_env)

      # add the code for the plot into the chunks
      teal.code::chunks_push(
        bquote(hist(.(as.name(dataname()))[, .(selected())]))
      )

      # evaluate the chunks
      teal.code::chunks_safe_eval()
    })

    # shiny component to view
    output$plot <- renderPlot({
      plot_code()
    })

    # Show the R code when user clicks 'Show R Code' button
    teal::get_rcode_srv(
      id = "rcode",
      datasets = datasets,
      modal_title = "R code for custom plot",
      code_header = "R code for custom plot"
    )
  })
}

# the function which creates the teal module for users
tm_histogram_example <- function(label, histogram_var) {
  checkmate::assert_character(label)
  checkmate::assert_class(histogram_var, "data_extract_spec")

  module(
    label = label,
    server = srv_histogram_example,
    ui = ui_histogram_example,
    ui_args = list(histogram_var = histogram_var),
    server_args = list(histogram_var = histogram_var),
    filters = "all"
  )
}

## -----------------------------------------------------------------------------

library(teal)

app <- init(
  data = teal_data(
    dataset("IRIS", iris, code = "IRIS <- iris"),
    check = TRUE
  ),
  modules = modules(
    tm_histogram_example(
      label = "Simple Module",
      histogram_var = data_extract_spec(
        dataname = "IRIS",
        select = select_spec(
          choices = c("Sepal.Length", "Sepal.Width", "Petal.Length", "Petal.Width")
        )
      )
    )
  ),
  header = "Simple app with custom histogram module"
)

if (interactive()) {
  shinyApp(app$ui, app$server)
}

