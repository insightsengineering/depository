## ---- eval = FALSE------------------------------------------------------------
#  library(teal)
#  utils::data(miniACC, package = "MultiAssayExperiment")
#  
#  mae_d <- dataset("MAE", miniACC, metadata = list(type = "example"))
#  
#  app <- init(
#    data = teal_data(mae_d),
#    modules = modules(
#      example_module()
#    )
#  )
#  
#  if (interactive()) {
#    shinyApp(app$ui, app$server)
#  }

