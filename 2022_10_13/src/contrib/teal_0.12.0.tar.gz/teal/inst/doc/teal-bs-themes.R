## ---- message=FALSE-----------------------------------------------------------
options("teal.bs_theme" = bslib::bs_theme(version = "5"))
library(teal)

app <- init(
  data = teal_data(
    dataset("IRIS", iris),
    dataset("MTCARS", mtcars)
  ),
  modules = modules(example_module(), example_module()),
  header = "My first teal application"
)

if (interactive()) {
  # Run with themer
  bslib::run_with_themer(shinyApp(app$ui, app$server))
}

## ---- message=FALSE-----------------------------------------------------------
options("teal.bs_theme" = bslib::bs_theme(version = "5", bootswatch = "lux"))
library(teal)

app <- init(
  data = teal_data(
    dataset("IRIS", iris),
    dataset("MTCARS", mtcars)
  ),
  modules = modules(example_module(), example_module()),
  header = "My first teal application"
)

if (interactive()) {
  shinyApp(app$ui, app$server)
}

