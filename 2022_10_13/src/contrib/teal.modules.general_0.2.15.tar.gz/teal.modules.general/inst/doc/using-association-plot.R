## ----echo=TRUE, message=FALSE, warning=FALSE, results="hide"------------------
library(teal.modules.general) # used to create the app
library(scda) # used to create data sets
library(dplyr) # used to modify data sets

## ----echo=TRUE, message=FALSE, warning=FALSE, results="hide"------------------
ADSL <- synthetic_cdisc_data("latest")$adsl # nolint
ADSL2 <- synthetic_cdisc_data("latest")$adsl %>% # nolint
  mutate(TRTDUR = round(as.numeric(TRTEDTM - TRTSDTM), 1))
ADRS <- synthetic_cdisc_data("latest")$adrs # nolint
ADTTE <- synthetic_cdisc_data("latest")$adtte # nolint
ADLB <- synthetic_cdisc_data("latest")$adlb %>% # nolint
  mutate(CHGC = as.factor(case_when(
    CHG < 1 ~ "N",
    CHG > 1 ~ "P",
    TRUE ~ "-"
  )))

## ----echo=TRUE, message=FALSE, warning=FALSE, results="hide"------------------
app <- init(
  data = cdisc_data(
    cdisc_dataset("ADSL", ADSL, code = "ADSL <- synthetic_cdisc_data(\"latest\")$adsl"),
    cdisc_dataset(
      "ADSL2",
      ADSL2,
      keys = get_cdisc_keys("ADSL"),
      code = "ADSL2 <- synthetic_cdisc_data(\"latest\")$adsl %>%
              mutate(TRTDUR = round(as.numeric(TRTEDTM - TRTSDTM), 1))"
    ),
    cdisc_dataset("ADRS", ADRS, code = "ADRS <- synthetic_cdisc_data(\"latest\")$adrs"),
    cdisc_dataset("ADTTE", ADTTE, code = "ADTTE <- synthetic_cdisc_data(\"latest\")$adtte"),
    cdisc_dataset(
      "ADLB",
      ADLB,
      code = "ADLB <- synthetic_cdisc_data(\"latest\")$adlb %>%
            mutate(CHGC = as.factor(case_when(
            CHG < 1 ~ 'N',
            CHG > 1 ~ 'P',
            TRUE ~ '-'
            )))"
    ),
    check = TRUE
  ),
  modules = modules(
    # tm_g_association ----
    modules(
      label = "Association plot",
      tm_g_association(
        label = "Single wide dataset",
        ref = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            label = "Select variable:",
            choices = variable_choices(ADSL),
            selected = "AGE",
            fixed = FALSE
          )
        ),
        vars = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            label = "Select variables:",
            choices = variable_choices(ADSL),
            selected = "BMRKR1",
            multiple = TRUE,
            fixed = FALSE
          )
        )
      ),
      tm_g_association(
        label = "Two wide datasets",
        ref = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            label = "Select variable:",
            choices = variable_choices(ADSL, c("AGE", "SEX", "STRATA1", "RACE")),
            selected = "STRATA1",
            multiple = FALSE,
            fixed = FALSE
          )
        ),
        vars = data_extract_spec(
          dataname = "ADSL2",
          select = select_spec(
            label = "Select variables:",
            choices = variable_choices(ADSL2, c("AGE", "SEX", "RACE", "COUNTRY")),
            selected = c("AGE", "COUNTRY", "RACE"),
            multiple = TRUE,
            fixed = FALSE
          )
        )
      ),
      tm_g_association(
        label = "Multiple different long datasets",
        ref = data_extract_spec(
          dataname = "ADTTE",
          select = select_spec(
            label = "Select variables:",
            choices = variable_choices(ADTTE),
            selected = "AVAL",
            multiple = FALSE,
            fixed = FALSE
          ),
          filter = filter_spec(
            label = "Select endpoint:",
            vars = "PARAMCD",
            choices = value_choices(ADTTE, "PARAMCD", "PARAM"),
            selected = c("PFS", "EFS"),
            multiple = TRUE
          )
        ),
        vars = data_extract_spec(
          dataname = "ADRS",
          reshape = TRUE,
          select = select_spec(
            label = "Select variable:",
            choices = variable_choices(ADRS, c("AVALC", "BMRKR1", "BMRKR2", "ARM")),
            selected = "AVALC",
            multiple = TRUE,
            fixed = FALSE
          ),
          filter = list(
            filter_spec(
              label = "Select endpoints:",
              vars = "PARAMCD",
              choices = value_choices(ADRS, "PARAMCD", "PARAM"),
              selected = "BESRSPI",
              multiple = TRUE
            ),
            filter_spec(
              label = "Select endpoints:",
              vars = "AVISIT",
              choices = levels(ADRS$AVISIT),
              selected = "SCREENING",
              multiple = TRUE
            )
          )
        )
      ),
      tm_g_association(
        label = "Wide and long datasets",
        ref = data_extract_spec(
          dataname = "ADRS",
          select = select_spec(
            choices = variable_choices(ADRS, c("AVAL", "AVALC")),
            selected = "AVALC",
            multiple = FALSE,
            fixed = FALSE,
            label = "Selected variable:"
          ),
          filter = list(
            filter_spec(
              vars = "PARAMCD",
              choices = value_choices(ADRS, "PARAMCD", "PARAM"),
              selected = levels(ADRS$PARAMCD),
              multiple = TRUE,
              label = "Select response"
            ),
            filter_spec(
              vars = "AVISIT",
              choices = levels(ADRS$AVISIT),
              selected = levels(ADRS$AVISIT),
              multiple = TRUE,
              label = "Select visit:"
            )
          )
        ),
        vars = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            choices = variable_choices(ADSL, c("SEX", "AGE", "RACE", "COUNTRY", "BMRKR1", "STRATA1", "ARM")),
            selected = "AGE",
            multiple = TRUE,
            fixed = FALSE,
            label = "Select variable:"
          )
        )
      ),
      tm_g_association(
        label = "Same long datasets (same subsets)",
        ref = data_extract_spec(
          dataname = "ADRS",
          select = select_spec(
            choices = variable_choices(ADRS),
            selected = "AVALC",
            multiple = FALSE,
            fixed = FALSE,
            label = "Select variable:"
          )
        ),
        vars = data_extract_spec(
          dataname = "ADRS",
          select = select_spec(
            choices = variable_choices(ADRS),
            selected = "PARAMCD",
            multiple = TRUE,
            fixed = FALSE,
            label = "Select variable:"
          )
        )
      ),
      tm_g_association(
        label = "Same long datasets (different subsets)",
        ref = data_extract_spec(
          dataname = "ADLB",
          filter = list(
            filter_spec(
              vars = "PARAMCD",
              choices = value_choices(ADLB, "PARAMCD", "PARAM"),
              selected = levels(ADLB$PARAMCD)[1],
              multiple = FALSE,
              label = "Select lab:"
            ),
            filter_spec(
              vars = "AVISIT",
              choices = levels(ADLB$AVISIT),
              selected = levels(ADLB$AVISIT)[1],
              multiple = FALSE,
              label = "Select visit:"
            )
          ),
          select = select_spec(
            choices = variable_choices(ADLB, c("AVAL", "CHG2", "PCHG2")),
            selected = "AVAL",
            multiple = FALSE
          )
        ),
        vars = data_extract_spec(
          dataname = "ADLB",
          filter = list(
            filter_spec(
              vars = "PARAMCD",
              choices = value_choices(ADLB, "PARAMCD", "PARAM"),
              selected = levels(ADLB$PARAMCD)[1],
              multiple = FALSE,
              label = "Select labs:"
            ),
            filter_spec(
              vars = "AVISIT",
              choices = levels(ADLB$AVISIT),
              selected = levels(ADLB$AVISIT)[1],
              multiple = FALSE,
              label = "Select visit:"
            )
          ),
          select = select_spec(
            choices = variable_choices(ADLB),
            selected = "STRATA1",
            multiple = TRUE
          )
        )
      )
    )
  )
)

## ----echo=TRUE----------------------------------------------------------------
shinyApp(app$ui, app$server, options = list(height = 1024, width = 1024))

