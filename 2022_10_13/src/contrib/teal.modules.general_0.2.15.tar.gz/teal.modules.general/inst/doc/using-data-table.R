## ----echo=TRUE, message=FALSE, warning=FALSE, results="hide"------------------
library(teal.modules.general) # used to create the app
library(scda) # used to create data sets

## ----echo=TRUE, message=FALSE, warning=FALSE, results="hide"------------------
ADSL <- synthetic_cdisc_data("latest")$adsl # nolint
ADTTE <- synthetic_cdisc_data("latest")$adtte # nolint
ADLB <- synthetic_cdisc_data("latest")$adlb # nolint

## ----echo=TRUE, message=FALSE, warning=FALSE, results="hide"------------------
app <- init(
  data = cdisc_data(
    cdisc_dataset("ADSL", ADSL, code = "ADSL <- synthetic_cdisc_data(\"latest\")$adsl"),
    cdisc_dataset("ADTTE", ADTTE, code = "ADTTE <- synthetic_cdisc_data(\"latest\")$adtte"),
    cdisc_dataset("ADLB", ADLB, code = "ADLB <- synthetic_cdisc_data(\"latest\")$adlb"),
    check = TRUE
  ),
  modules = modules(
    # two-datasets example
    tm_data_table(
      label = "Two datasets",
      variables_selected = list(
        ADSL = c("STUDYID", "USUBJID", "SUBJID", "SITEID", "AGE", "SEX"),
        ADTTE = c(
          "STUDYID", "USUBJID", "SUBJID", "SITEID",
          "PARAM", "PARAMCD", "ARM", "ARMCD", "AVAL", "CNSR"
        )
      )
    ),
    # subsetting or changing order of datasets
    tm_data_table(
      label = "Datasets order",
      variables_selected = list(
        ADSL = c("STUDYID", "USUBJID", "SUBJID", "SITEID", "AGE", "SEX"),
        ADLB = c(
          "STUDYID", "USUBJID", "SUBJID", "SITEID",
          "PARAM", "PARAMCD", "AVISIT", "AVISITN", "AVAL", "CHG"
        )
      ),
      datasets_selected = c("ADTTE", "ADLB", "ADSL")
    ),
    # advanced usage of DT options and extensions
    tm_data_table(
      label = "Advanced DT usage",
      dt_args = list(extensions = c("Buttons", "ColReorder", "FixedHeader")),
      dt_options = list(
        searching = FALSE,
        pageLength = 30,
        lengthMenu = c(5, 15, 25, 50, 100),
        scrollX = FALSE,
        dom = "lBrtip",
        buttons = c("copy", "csv", "excel", "pdf", "print"),
        colReorder = TRUE,
        fixedHeader = TRUE
      )
    )
  )
)

## ----echo=TRUE----------------------------------------------------------------
shinyApp(app$ui, app$server, options = list(height = 1024, width = 1024))

