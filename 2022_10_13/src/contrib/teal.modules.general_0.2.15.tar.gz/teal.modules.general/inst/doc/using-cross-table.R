## ----echo=TRUE, message=FALSE, warning=FALSE, results="hide"------------------
library(teal.modules.general) # used to create the app
library(scda) # used to create data sets
library(dplyr) # used to modify data sets

## ----echo=TRUE, message=FALSE, warning=FALSE, results="hide"------------------
ADSL <- synthetic_cdisc_data("latest")$adsl # nolint
ADSL2 <- synthetic_cdisc_data("latest")$adsl %>% # nolint
  mutate(TRTDUR = round(as.numeric(TRTEDTM - TRTSDTM), 1))
ADRS <- synthetic_cdisc_data("latest")$adrs # nolint
ADTTE <- synthetic_cdisc_data("latest")$adtte # nolint
ADLB <- synthetic_cdisc_data("latest")$adlb %>% # nolint
  mutate(CHGC = as.factor(case_when(
    CHG < 1 ~ "N",
    CHG > 1 ~ "P",
    TRUE ~ "-"
  )))

## ----echo=TRUE, message=FALSE, warning=FALSE, results="hide"------------------
app <- init(
  data = cdisc_data(
    cdisc_dataset("ADSL", ADSL, code = "ADSL <- synthetic_cdisc_data(\"latest\")$adsl"),
    cdisc_dataset(
      "ADSL2",
      ADSL2,
      keys = get_cdisc_keys("ADSL"),
      code = "ADSL2 <- synthetic_cdisc_data(\"latest\")$adsl %>%
              mutate(TRTDUR = round(as.numeric(TRTEDTM - TRTSDTM), 1))"
    ),
    cdisc_dataset("ADRS", ADRS, code = "ADRS <- synthetic_cdisc_data(\"latest\")$adrs"),
    cdisc_dataset("ADTTE", ADTTE, code = "ADTTE <- synthetic_cdisc_data(\"latest\")$adtte"),
    cdisc_dataset("ADLB", ADLB,
      code = "ADLB <- synthetic_cdisc_data(\"latest\")$adlb %>%
            mutate(CHGC = as.factor(case_when(
            CHG < 1 ~ 'N',
            CHG > 1 ~ 'P',
            TRUE ~ '-'
            )))"
    ),
    check = TRUE
  ),
  modules = modules(
    modules(
      label = "Cross table",
      tm_t_crosstable(
        label = "Single wide dataset",
        x = data_extract_spec(
          "ADSL",
          select = select_spec(
            label = "Select variable:",
            choices = variable_choices(ADSL),
            selected = names(ADSL)[5],
            multiple = TRUE,
            fixed = FALSE,
            ordered = TRUE
          )
        ),
        y = data_extract_spec(
          "ADSL",
          select = select_spec(
            label = "Select variable:",
            choices = variable_choices(ADSL),
            selected = names(ADSL)[6],
            multiple = FALSE,
            fixed = FALSE
          )
        )
      ),
      tm_t_crosstable(
        label = "Same long datasets (different subsets)",
        x = data_extract_spec(
          dataname = "ADLB",
          filter = filter_spec(
            vars = "PARAMCD",
            choices = value_choices(ADLB, "PARAMCD", "PARAM"),
            selected = levels(ADLB$PARAMCD)[1],
            multiple = FALSE
          ),
          select = select_spec(
            choices = variable_choices(ADLB),
            selected = "AVISIT",
            multiple = TRUE,
            fixed = FALSE,
            ordered = TRUE,
            label = "Select variable:"
          )
        ),
        y = data_extract_spec(
          dataname = "ADLB",
          filter = filter_spec(
            vars = "PARAMCD",
            choices = value_choices(ADLB, "PARAMCD", "PARAM"),
            selected = levels(ADLB$PARAMCD)[1],
            multiple = FALSE
          ),
          select = select_spec(
            choices = variable_choices(ADLB),
            selected = "LOQFL",
            multiple = FALSE,
            fixed = FALSE,
            label = "Select variable:"
          )
        )
      )
    )
  )
)

## ----echo=TRUE----------------------------------------------------------------
shinyApp(app$ui, app$server, options = list(height = 1024, width = 1024))

