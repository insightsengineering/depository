## ----echo=TRUE, message=FALSE, warning=FALSE, results="hide"------------------
library(teal.modules.general) # used to create the app
library(scda) # used to create data sets
library(dplyr) # used to modify data sets

## ----echo=TRUE, message=FALSE, warning=FALSE, results="hide"------------------
ADSL <- synthetic_cdisc_data("latest")$adsl # nolint
ADSL2 <- synthetic_cdisc_data("latest")$adsl %>% # nolint
  mutate(TRTDUR = round(as.numeric(TRTEDTM - TRTSDTM), 1))
ADRS <- synthetic_cdisc_data("latest")$adrs # nolint
ADTTE <- synthetic_cdisc_data("latest")$adtte # nolint
ADLB <- synthetic_cdisc_data("latest")$adlb %>% # nolint
  mutate(CHGC = as.factor(case_when(
    CHG < 1 ~ "N",
    CHG > 1 ~ "P",
    TRUE ~ "-"
  )))

## ----echo=TRUE, message=FALSE, warning=FALSE, results="hide"------------------
app <- init(
  data = cdisc_data(
    cdisc_dataset("ADSL", ADSL, code = "ADSL <- synthetic_cdisc_data(\"latest\")$adsl"),
    cdisc_dataset(
      "ADSL2",
      ADSL2,
      keys = get_cdisc_keys("ADSL"),
      code = "ADSL2 <- synthetic_cdisc_data(\"latest\")$adsl %>%
              mutate(TRTDUR = round(as.numeric(TRTEDTM - TRTSDTM), 1))"
    ),
    cdisc_dataset("ADRS", ADRS, code = "ADRS <- synthetic_cdisc_data(\"latest\")$adrs"),
    cdisc_dataset("ADTTE", ADTTE, code = "ADTTE <- synthetic_cdisc_data(\"latest\")$adtte"),
    cdisc_dataset(
      "ADLB",
      ADLB,
      code = "ADLB <- synthetic_cdisc_data(\"latest\")$adlb %>%
            mutate(CHGC = as.factor(case_when(
            CHG < 1 ~ 'N',
            CHG > 1 ~ 'P',
            TRUE ~ '-'
            )))"
    ),
    check = TRUE
  ),
  modules = modules(
    # tm_g_bivariate ------
    modules(
      label = "Bivariate plot",
      tm_g_bivariate(
        label = "Single wide dataset",
        x = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            label = "Select variable:",
            choices = variable_choices(ADSL),
            selected = "BMRKR1",
            fixed = FALSE
          )
        ),
        y = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            label = "Select variable:",
            choices = variable_choices(ADSL),
            selected = "SEX",
            multiple = FALSE,
            fixed = FALSE
          )
        ),
        row_facet = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            label = "Select variables:",
            choices = variable_choices(ADSL),
            selected = NULL,
            multiple = TRUE,
            fixed = FALSE
          )
        ),
        col_facet = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            label = "Select variables:",
            choices = variable_choices(ADSL),
            selected = NULL,
            multiple = TRUE,
            fixed = FALSE
          )
        )
      ),
      tm_g_bivariate(
        label = "Two wide datasets",
        x = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            label = "Select variable:",
            choices = variable_choices(ADSL, c("BMRKR1", "AGE", "SEX", "STRATA1", "RACE")),
            selected = c("BMRKR1"),
            multiple = FALSE
          )
        ),
        y = data_extract_spec(
          dataname = "ADSL2",
          select = select_spec(
            label = "Select variables:",
            choices = variable_choices(ADSL2, c("COUNTRY", "AGE", "RACE")),
            selected = "RACE",
            multiple = FALSE
          )
        ),
        row_facet = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            label = "Select variable:",
            choices = variable_choices(ADSL),
            selected = NULL,
            multiple = FALSE,
            fixed = FALSE
          )
        ),
        col_facet = data_extract_spec(
          dataname = "ADSL2",
          select = select_spec(
            label = "Select variables:",
            choices = variable_choices(ADSL2),
            selected = NULL,
            multiple = TRUE,
            fixed = FALSE
          )
        )
      ),
      tm_g_bivariate(
        label = "Multiple different long datasets",
        x = data_extract_spec(
          dataname = "ADRS",
          filter = filter_spec(
            label = "Select endpoints:",
            vars = c("PARAMCD", "AVISIT"),
            choices = value_choices(ADRS, c("PARAMCD", "AVISIT"), c("PARAM", "AVISIT")),
            selected = "OVRINV - END OF INDUCTION",
            multiple = TRUE
          ),
          select = select_spec(
            choices = variable_choices(ADRS, c("AVALC", "AVAL")),
            selected = "AVALC",
            multiple = FALSE
          )
        ),
        y = data_extract_spec(
          dataname = "ADTTE",
          select = select_spec(
            label = "Select variable:",
            choices = variable_choices(ADTTE, c("AVAL", "CNSR")),
            selected = "AVAL",
            multiple = FALSE,
            fixed = FALSE
          ),
          filter = filter_spec(
            label = "Select endpoint:",
            vars = c("PARAMCD"),
            choices = value_choices(ADTTE, "PARAMCD", "PARAM"),
            selected = "OS",
            multiple = FALSE
          )
        ),
        row_facet = data_extract_spec(
          dataname = "ADRS",
          filter = filter_spec(
            label = "Select endpoints:",
            vars = c("PARAMCD", "AVISIT"),
            choices = value_choices(ADRS, c("PARAMCD", "AVISIT"), c("PARAM", "AVISIT")),
            selected = "OVRINV - SCREENING",
            multiple = TRUE
          ),
          select = select_spec(
            label = "Select variable:",
            choices = variable_choices(ADRS, c("SEX", "RACE", "COUNTRY", "ARM", "PARAMCD", "AVISIT")),
            selected = "SEX",
            multiple = FALSE,
            fixed = FALSE
          )
        ),
        col_facet = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            label = "Select variables:",
            choices = variable_choices(ADSL, c("SEX", "RACE")),
            selected = NULL,
            multiple = TRUE,
            fixed = FALSE
          )
        ),
        color_settings = TRUE,
        color = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            choices = variable_choices(ADSL, c("SEX", "RACE", "COUNTRY")),
            selected = NULL,
            multiple = FALSE,
            fixed = FALSE,
            label = "Select variable:"
          )
        ),
        fill = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            choices = variable_choices(ADSL, c("SEX", "RACE", "COUNTRY")),
            selected = NULL,
            multiple = FALSE,
            fixed = FALSE,
            label = "Select variable:"
          )
        ),
        size = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            choices = variable_choices(ADSL, c("AGE", "BMRKR1")),
            selected = NULL,
            multiple = FALSE,
            fixed = FALSE,
            label = "Select variable:"
          )
        ),
        plot_height = c(600, 200, 2000),
        ggtheme = "gray"
      ),
      tm_g_bivariate(
        label = "Wide and long datasets",
        x = data_extract_spec(
          dataname = "ADRS",
          filter = list(
            filter_spec(
              vars = "PARAMCD",
              choices = value_choices(ADRS, "PARAMCD", "PARAM"),
              selected = levels(ADRS$PARAMCD)[1],
              multiple = FALSE,
              label = "Select response:"
            ),
            filter_spec(
              vars = "AVISIT",
              choices = levels(ADRS$AVISIT),
              selected = levels(ADRS$AVISIT)[1],
              multiple = FALSE,
              label = "Select visit:"
            )
          ),
          select = select_spec(
            choices = variable_choices(ADRS, c("AVALC", "AVAL")),
            selected = "AVALC",
            multiple = FALSE,
            label = "Select variable:"
          )
        ),
        y = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            choices = variable_choices(ADSL, c("BMRKR1", "SEX", "AGE", "RACE", "COUNTRY")),
            selected = "BMRKR1",
            multiple = FALSE,
            label = "Select variable:",
            fixed = FALSE
          )
        ),
        row_facet = data_extract_spec(
          dataname = "ADRS",
          select = select_spec(
            choices = variable_choices(ADRS, c("SEX", "RACE", "ARMCD", "PARAMCD")),
            selected = "SEX",
            multiple = FALSE,
            label = "Select variable:"
          )
        ),
        col_facet = data_extract_spec(
          dataname = "ADRS",
          select = select_spec(
            choices = variable_choices(ADRS, c("SEX", "RACE", "ARMCD", "PARAMCD", "AVISIT")),
            selected = "ARMCD",
            multiple = FALSE,
            fixed = FALSE,
            label = "Select variable:"
          )
        )
      ),
      tm_g_bivariate(
        label = "Wide and multiple long datasets",
        x = data_extract_spec(
          dataname = "ADRS",
          filter = list(
            filter_spec(
              vars = "PARAMCD",
              choices = value_choices(ADRS, "PARAMCD", "PARAM"),
              selected = levels(ADRS$PARAMCD)[1],
              multiple = FALSE,
              label = "Select response:"
            ),
            filter_spec(
              vars = "AVISIT",
              choices = levels(ADRS$AVISIT),
              selected = levels(ADRS$AVISIT)[1],
              multiple = FALSE,
              label = "Select visit:"
            )
          ),
          select = select_spec(
            choices = variable_choices(ADRS, c("AVALC", "AVAL")),
            selected = "AVALC",
            multiple = FALSE,
            label = "Select variable:"
          )
        ),
        y = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            choices = variable_choices(ADSL, c("BMRKR1", "SEX", "AGE", "RACE", "COUNTRY")),
            selected = "BMRKR1",
            multiple = FALSE,
            fixed = FALSE
          )
        ),
        row_facet = data_extract_spec(
          dataname = "ADLB",
          filter = list(
            filter_spec(
              vars = "PARAMCD",
              choices = value_choices(ADLB, "PARAMCD", "PARAM"),
              selected = levels(ADLB$PARAMCD)[1],
              multiple = FALSE,
              label = "Select measurement:"
            ),
            filter_spec(
              vars = "AVISIT",
              choices = levels(ADLB$AVISIT),
              selected = levels(ADLB$AVISIT)[1],
              multiple = FALSE,
              label = "Select visit:"
            )
          ),
          select = select_spec(
            choices = "ARMCD",
            selected = NULL,
            multiple = FALSE,
            fixed = FALSE,
            label = "Select variable:"
          )
        ),
        col_facet = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            choices = variable_choices(ADSL, c("SEX", "AGE", "RACE", "COUNTRY")),
            selected = NULL,
            multiple = FALSE,
            fixed = FALSE,
            label = "Select variable:"
          )
        ),
        color_settings = TRUE,
        color = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            choices = variable_choices(ADSL, c("SEX", "RACE", "COUNTRY")),
            selected = NULL,
            multiple = FALSE,
            fixed = FALSE,
            label = "Select variable:"
          )
        ),
        fill = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            choices = variable_choices(ADSL, c("SEX", "RACE", "COUNTRY")),
            selected = NULL,
            multiple = FALSE,
            fixed = FALSE,
            label = "Select variable:"
          )
        ),
        size = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            choices = variable_choices(ADSL, c("AGE", "BMRKR1")),
            selected = NULL,
            multiple = FALSE,
            fixed = FALSE,
            label = "Select variable:"
          )
        ),
        plot_height = c(600, 200, 2000),
        ggtheme = "gray"
      ),
      tm_g_bivariate(
        label = "Same long datasets (same subset)",
        x = data_extract_spec(
          dataname = "ADRS",
          select = select_spec(
            choices = variable_choices(ADRS, c("AVALC", "AVAL")),
            selected = "AVALC",
            multiple = FALSE,
            fixed = FALSE,
            label = "Select variable:"
          )
        ),
        y = data_extract_spec(
          dataname = "ADRS",
          select = select_spec(
            choices = variable_choices(ADRS, c("SEX", "RACE", "COUNTRY", "ARMCD", "BMRKR1", "BMRKR2")),
            selected = "BMRKR1",
            multiple = FALSE,
            fixed = FALSE,
            label = "Select variable:"
          )
        ),
        row_facet = data_extract_spec(
          dataname = "ADRS",
          select = select_spec(
            choices = variable_choices(ADRS, c("AVISIT", "PARAMCD")),
            selected = "PARAMCD",
            multiple = TRUE,
            label = "Select variables:"
          )
        ),
        col_facet = data_extract_spec(
          dataname = "ADRS",
          select = select_spec(
            choices = variable_choices(ADRS, c("AVISIT", "PARAMCD")),
            selected = "AVISIT",
            multiple = TRUE,
            label = "Select variables:"
          )
        )
      ),
      tm_g_bivariate(
        label = "Same datasets (different subsets)",
        x = data_extract_spec(
          dataname = "ADLB",
          filter = list(
            filter_spec(
              vars = "PARAMCD",
              choices = value_choices(ADLB, "PARAMCD", "PARAM"),
              selected = levels(ADLB$PARAMCD)[1],
              multiple = FALSE,
              label = "Select lab:"
            ),
            filter_spec(
              vars = "AVISIT",
              choices = levels(ADLB$AVISIT),
              selected = levels(ADLB$AVISIT)[1],
              multiple = FALSE,
              label = "Select visit:"
            )
          ),
          select = select_spec(
            choices = "AVAL",
            selected = "AVAL",
            multiple = FALSE,
            fixed = TRUE
          )
        ),
        y = data_extract_spec(
          dataname = "ADLB",
          filter = list(
            filter_spec(
              vars = "PARAMCD",
              choices = value_choices(ADLB, "PARAMCD", "PARAM"),
              selected = levels(ADLB$PARAMCD)[1],
              multiple = FALSE,
              label = "Select lab:"
            ),
            filter_spec(
              vars = "AVISIT",
              choices = levels(ADLB$AVISIT),
              selected = levels(ADLB$AVISIT)[1],
              multiple = FALSE,
              label = "Select visit:"
            )
          ),
          select = select_spec(
            choices = "AVAL",
            selected = "AVAL",
            multiple = FALSE,
            fixed = TRUE
          )
        ),
        use_density = FALSE,
        row_facet = data_extract_spec(
          dataname = "ADLB",
          filter = list(
            filter_spec(
              vars = "PARAMCD",
              choices = value_choices(ADLB, "PARAMCD", "PARAM"),
              selected = levels(ADLB$PARAMCD)[1],
              multiple = FALSE,
              label = "Select lab:"
            ),
            filter_spec(
              vars = "AVISIT",
              choices = levels(ADLB$AVISIT),
              selected = levels(ADLB$AVISIT)[1],
              multiple = FALSE,
              label = "Select category:"
            )
          ),
          select = select_spec(
            choices = variable_choices(ADLB, c("RACE", "SEX", "ARMCD", "ACTARMCD")),
            selected = NULL,
            multiple = TRUE,
            fixed = FALSE,
            label = "Select variable:"
          )
        ),
        col_facet = data_extract_spec(
          dataname = "ADLB",
          filter = list(
            filter_spec(
              vars = "PARAMCD",
              choices = value_choices(ADLB, "PARAMCD", "PARAM"),
              selected = levels(ADLB$PARAMCD)[1],
              multiple = FALSE,
              label = "Select lab:"
            ),
            filter_spec(
              vars = "AVISIT",
              choices = levels(ADLB$AVISIT),
              selected = levels(ADLB$AVISIT)[1],
              multiple = FALSE,
              label = "Select category:"
            )
          ),
          select = select_spec(
            choices = variable_choices(ADLB, c("RACE", "SEX", "ARMCD", "ACTARMCD")),
            selected = "ARMCD",
            multiple = TRUE,
            fixed = FALSE,
            label = "Select variables:"
          )
        ),
        color_settings = TRUE,
        color = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            choices = variable_choices(ADSL, c("SEX", "RACE", "COUNTRY")),
            selected = NULL,
            multiple = FALSE,
            fixed = FALSE,
            label = "Select variable:"
          )
        ),
        fill = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            choices = variable_choices(ADSL, c("SEX", "RACE", "COUNTRY")),
            selected = NULL,
            multiple = FALSE,
            fixed = FALSE,
            label = "Select variable:"
          )
        ),
        size = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            choices = variable_choices(ADSL, c("AGE", "BMRKR1")),
            selected = NULL,
            multiple = FALSE,
            fixed = FALSE,
            label = "Select variable:"
          )
        ),
        plot_height = c(600, 200, 2000),
        ggtheme = "gray"
      )
    )
  )
)

## ----echo=TRUE----------------------------------------------------------------
shinyApp(app$ui, app$server, options = list(height = 1024, width = 1024))

