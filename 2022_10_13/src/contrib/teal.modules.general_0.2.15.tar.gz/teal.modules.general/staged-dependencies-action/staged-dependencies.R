#!/usr/bin/env Rscript

split_to_map <- function(args) {
  tmp <- strsplit(x = unlist(strsplit(args, ",")), "=")
  content <- unlist(lapply(tmp, function(x) x[2]))
  names(content) <- unlist(lapply(tmp, function(x) x[1]))
  return(content)
}

repo_path <- Sys.getenv("SD_REPO_PATH", ".")
sd_version <- Sys.getenv("SD_STAGED_DEPENDENCIES_VERSION", "v0.2.7")
git_ref <- Sys.getenv("SD_GIT_REF")
threads <- Sys.getenv("SD_THREADS", "auto")
cran_repos <- Sys.getenv(
  "SD_CRAN_REPOSITORIES",
  "CRAN=https://cloud.r-project.org/"
)
cran_repos_biomarker <- Sys.getenv("SD_ENABLE_BIOMARKER_REPOSITORIES", "false")
token_mapping <- Sys.getenv(
  "SD_TOKEN_MAPPING",
  "https://github.com=GITHUB_PAT,https://gitlab.com=GITLAB_PAT"
)
check <- Sys.getenv("SD_ENABLE_CHECK", "true")

cat("\n==================================\n")
cat("Running staged dependencies installer\n")
cat(paste("repo_path: \"", repo_path, "\"\n", sep = ""))
cat(paste("sd_version: \"", sd_version, "\"\n", sep = ""))
cat(paste("git_ref: \"", git_ref, "\"\n", sep = ""))
cat(paste("threads: \"", threads, "\"\n", sep = ""))
cat(paste("check: \"", check, "\"\n", sep = ""))
cat(paste("cran_repos: \"", cran_repos, "\"\n", sep = ""))
cat(paste("cran_repos_biomarker: \"", cran_repos_biomarker, "\"\n", sep = ""))
cat(paste("token_mapping: \"", token_mapping, "\"\n", sep = ""))
cat("==================================\n")

setwd(repo_path)

if (cran_repos_biomarker == "true") {
  options(repos = c(split_to_map(cran_repos), BiocManager::repositories()))
} else {
  options(repos = split_to_map(cran_repos))
}

if (threads == "auto") {
  threads <- parallel::detectCores(all.tests = FALSE, logical = TRUE)
  cat(paste("Number of cores detected:", threads, "\n\n"))
}

options(
  staged.dependencies.token_mapping = split_to_map(token_mapping)
)

# Install dependencies from renv
if (file.exists("renv.lock")) {
  renv::restore()
}

# Get staged dependencies graph and install dependencies
if (file.exists("staged_dependencies.yaml")) {
  install_sd <- FALSE
  if (!require("staged.dependencies")) {
    install_sd <- TRUE
  }
  if (require("staged.dependencies")) {
    if (paste0("v", packageVersion("staged.dependencies")) != sd_version) {
      install_sd <- TRUE
    }
  }
  if (install_sd) {
    cat("Installing Staged Dependencies\n\n")
    remotes::install_github(
      "openpharma/staged.dependencies",
      ref = sd_version,
      Ncpus = threads,
      upgrade = "never",
      force = TRUE,
      quiet = TRUE
    )
  }

  cat(paste(
    "\nCalculating Staged Dependency Table for ref: ", git_ref, "...\n\n"
  ))

  if (git_ref != "" &&
    !startsWith(git_ref, "refs/pull") &&
    !startsWith(git_ref, "refs/head")) {
    x <- staged.dependencies::dependency_table(ref = git_ref)
  } else {
    x <- staged.dependencies::dependency_table()
  }

  print(x, width = 120)
  cat("\n\n")

  if (check == "true") {
    cat("\nRunning check yaml consistent...\n\n")
    staged.dependencies::check_yamls_consistent(x, skip_if_missing_yaml = TRUE)
  }

  staged.dependencies::install_deps(
    dep_structure = x,
    install_project = FALSE,
    verbose = 1,
    install_external_deps = TRUE,
    upgrade = "never",
    Ncpus = threads,
    quiet = TRUE
  )
}

# Install any remaining dependencies
remotes::install_deps(
  dependencies = TRUE,
  upgrade = "never",
  Ncpus = threads,
  quiet = TRUE
)
