utils::globalVariables(c(".", "nline_dat", "line_start", "line_end", "line_min", "line_max"))
