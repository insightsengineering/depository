## ---- message=FALSE-----------------------------------------------------------
library(teal.data)
library(scda)

# create some dummy data
adsl <- synthetic_cdisc_data("latest")$adsl
adtte <- synthetic_cdisc_data("latest")$adtte

my_data <- cdisc_data(
  cdisc_dataset("ADSL", adsl),
  cdisc_dataset("ADTTE", adtte)
)

## -----------------------------------------------------------------------------

my_general_data <- teal_data(
  dataset("iris", iris),
  dataset("mtcars", mtcars)
)

