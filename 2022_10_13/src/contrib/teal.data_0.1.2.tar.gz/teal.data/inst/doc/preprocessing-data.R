## ---- message=FALSE-----------------------------------------------------------
library(scda)
library(teal.data)
saveRDS(synthetic_cdisc_data("latest")$adsl, "adsl.rds")

## preprocessing -------------------
adsl <- readRDS("adsl.rds")
## -------------------
data <- cdisc_data(cdisc_dataset("ADSL", adsl))
data$get_code()

## ---- message=FALSE-----------------------------------------------------------
library(scda)
saveRDS(synthetic_cdisc_data("latest")$adsl, "adsl.rds")

## preprocessing -------------------
adsl <- readRDS("adsl.rds")
## -------------------
unlink("adsl.rds")


data <- cdisc_data(
  cdisc_dataset("ADSL", adsl),
  code = 'ADSL <- readRDS("adsl.rds")'
)
data$get_code()

