## ---- message=FALSE-----------------------------------------------------------
library(teal.data)
library(dplyr)

iris_with_keys <- mutate(iris, id = factor(row_number()))

ds <- dataset(
  "IRIS",
  iris_with_keys,
  code = "IRIS <- iris %>% mutate(id = factor(row_number()))",
  keys = c("id")
)

ds$get_keys()

## ---- eval=FALSE--------------------------------------------------------------
#  library(teal.data)
#  
#  data_1 <- data.frame(X = factor(1:10), Y = 21:30, Z = 1:10)
#  data_2 <- data.frame(W = factor(10:1), V = factor(5:14), M = rep(1:5, 2))
#  data_3 <- data.frame(V = factor(5:14), T = 4)
#  
#  data <- teal_data(
#    dataset("D1", data_1, code = "D1 <- data.frame(X = factor(1:10), Y = 21:30, Z = 1:10)"),
#    dataset("D2", data_2, code = "D2 <- data.frame(W = factor(10:1), V = factor(5:14), M = rep(1:5, 2))"),
#    dataset("D3", data_3, code = "D3 <- data.frame(V = factor(5:14), T = 4)"),
#    join_keys = join_keys(
#      join_key("D1", "D2", c("X" = "W")),
#      join_key("D2", "D3", c("V" = "V"))
#    )
#  )

