#' @description Logging Setup for the `teal` Family of Packages.
#'
#' @keywords internal
"_PACKAGE"

# To silence R CMD checks.
#' @importFrom lifecycle badge
NULL
