pkg_name <- "teal.logger"
library(pkg_name, character.only = TRUE)
testthat::test_check(pkg_name)
