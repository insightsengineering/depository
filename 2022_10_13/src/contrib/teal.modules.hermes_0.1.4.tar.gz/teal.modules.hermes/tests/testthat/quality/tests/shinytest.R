library(shinytest)
shinytest::testApp("../")
