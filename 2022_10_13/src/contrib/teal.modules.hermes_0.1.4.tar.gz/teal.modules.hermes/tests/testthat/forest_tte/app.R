library(teal.modules.hermes)

sample_tm_g_forest_tte()
