library(teal.modules.hermes)

sample_tm_g_boxplot()
