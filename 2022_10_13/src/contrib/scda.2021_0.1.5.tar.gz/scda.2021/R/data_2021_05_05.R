#' Cached datasets from the 2021_05_05 release of `random.cdisc.data`
#'
#' @name rcd_data_2021_05_05
#'
NULL

#' @rdname rcd_data_2021_05_05
"rcd_2021_05_05_adsl"

#' @rdname rcd_data_2021_05_05
"rcd_2021_05_05_adae"

#' @rdname rcd_data_2021_05_05
"rcd_2021_05_05_adaette"

#' @rdname rcd_data_2021_05_05
"rcd_2021_05_05_adcm"

#' @rdname rcd_data_2021_05_05
"rcd_2021_05_05_addv"

#' @rdname rcd_data_2021_05_05
"rcd_2021_05_05_adeg"

#' @rdname rcd_data_2021_05_05
"rcd_2021_05_05_adex"

#' @rdname rcd_data_2021_05_05
"rcd_2021_05_05_adhy"

#' @rdname rcd_data_2021_05_05
"rcd_2021_05_05_adlb"

#' @rdname rcd_data_2021_05_05
"rcd_2021_05_05_admh"

#' @rdname rcd_data_2021_05_05
"rcd_2021_05_05_adqs"

#' @rdname rcd_data_2021_05_05
"rcd_2021_05_05_adrs"

#' @rdname rcd_data_2021_05_05
"rcd_2021_05_05_adsub"

#' @rdname rcd_data_2021_05_05
"rcd_2021_05_05_adtr"

#' @rdname rcd_data_2021_05_05
"rcd_2021_05_05_adtte"

#' @rdname rcd_data_2021_05_05
"rcd_2021_05_05_advs"
