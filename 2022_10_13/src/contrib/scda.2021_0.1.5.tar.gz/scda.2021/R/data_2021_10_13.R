#' Cached datasets from the 2021_10_13 release of `random.cdisc.data`
#'
#' @name rcd_data_2021_10_13
#'
NULL

#' @rdname rcd_data_2021_10_13
"rcd_2021_10_13_adsl"

#' @rdname rcd_data_2021_10_13
"rcd_2021_10_13_adae"

#' @rdname rcd_data_2021_10_13
"rcd_2021_10_13_adaette"

#' @rdname rcd_data_2021_10_13
"rcd_2021_10_13_adcm"

#' @rdname rcd_data_2021_10_13
"rcd_2021_10_13_addv"

#' @rdname rcd_data_2021_10_13
"rcd_2021_10_13_adeg"

#' @rdname rcd_data_2021_10_13
"rcd_2021_10_13_adex"

#' @rdname rcd_data_2021_10_13
"rcd_2021_10_13_adhy"

#' @rdname rcd_data_2021_10_13
"rcd_2021_10_13_adlb"

#' @rdname rcd_data_2021_10_13
"rcd_2021_10_13_admh"

#' @rdname rcd_data_2021_10_13
"rcd_2021_10_13_adqs"

#' @rdname rcd_data_2021_10_13
"rcd_2021_10_13_adrs"

#' @rdname rcd_data_2021_10_13
"rcd_2021_10_13_adsub"

#' @rdname rcd_data_2021_10_13
"rcd_2021_10_13_adtr"

#' @rdname rcd_data_2021_10_13
"rcd_2021_10_13_adtte"

#' @rdname rcd_data_2021_10_13
"rcd_2021_10_13_advs"
