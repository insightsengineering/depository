#' Cached datasets from the 2021_03_22 release of `random.cdisc.data`
#'
#' @name rcd_data_2021_03_22
#'
NULL

#' @rdname rcd_data_2021_03_22
"rcd_2021_03_22_adsl"

#' @rdname rcd_data_2021_03_22
"rcd_2021_03_22_adae"

#' @rdname rcd_data_2021_03_22
"rcd_2021_03_22_adaette"

#' @rdname rcd_data_2021_03_22
"rcd_2021_03_22_adcm"

#' @rdname rcd_data_2021_03_22
"rcd_2021_03_22_addv"

#' @rdname rcd_data_2021_03_22
"rcd_2021_03_22_adeg"

#' @rdname rcd_data_2021_03_22
"rcd_2021_03_22_adex"

#' @rdname rcd_data_2021_03_22
"rcd_2021_03_22_adlb"

#' @rdname rcd_data_2021_03_22
"rcd_2021_03_22_admh"

#' @rdname rcd_data_2021_03_22
"rcd_2021_03_22_adqs"

#' @rdname rcd_data_2021_03_22
"rcd_2021_03_22_adrs"

#' @rdname rcd_data_2021_03_22
"rcd_2021_03_22_adsub"

#' @rdname rcd_data_2021_03_22
"rcd_2021_03_22_adtr"

#' @rdname rcd_data_2021_03_22
"rcd_2021_03_22_adtte"

#' @rdname rcd_data_2021_03_22
"rcd_2021_03_22_advs"
