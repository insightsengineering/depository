#' Cached datasets from `random.cdisc.data`
#'
#' Cached datasets from 2021 releases of `random.cdisc.data`.
#'
#' @name rcd_data_2021
#'
NULL

#' @rdname rcd_data_2021
"rcd_2021_03_22"

#' @rdname rcd_data_2021
"rcd_2021_05_05"

#' @rdname rcd_data_2021
"rcd_2021_07_07"

#' @rdname rcd_data_2021
"rcd_2021_10_13"
