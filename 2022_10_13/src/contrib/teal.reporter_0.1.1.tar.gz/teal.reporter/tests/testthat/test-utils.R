testthat::test_that("get_bs_version", {
  testthat::expect_identical(get_bs_version(), "3")
})
