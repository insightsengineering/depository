pkg_name <- "teal.reporter"
library(pkg_name, character.only = TRUE)
testthat::test_check(pkg_name)
