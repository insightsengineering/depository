pkg_name <- "tern.rbmi"
library(pkg_name, character.only = TRUE)
testthat::test_check(pkg_name)
