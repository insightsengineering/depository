## rlistings 0.1.1
 * add title, subtitle, and (main and prov) footer support
 * now depends on dplyr instea dof magrittr to hopefully avoid var_labels droppage issues
 * `paginate_listing` now supports pagination in both directions

## rlistings 0.1.0
 * Initial experimental rlistings API. Everything subject to change.
