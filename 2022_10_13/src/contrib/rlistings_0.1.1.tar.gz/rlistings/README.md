# rlistings
Value formatting and ASCII rendering infrastructure for tables and listings.
