library(testthat)
library(rlistings)

test_check("rlistings", reporter = "check")
