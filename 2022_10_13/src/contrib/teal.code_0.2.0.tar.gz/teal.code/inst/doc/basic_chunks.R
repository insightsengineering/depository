## -----------------------------------------------------------------------------
a <- 3

# Creating a chunk by quote ------------------------------
expr_a <- quote(sum(a, a))
print(expr_a)

# Creating a chunk by substitute ------------------------------
expr_b <- substitute(b <- sum(a, a))
print(expr_b)

# Creating a chunk by call -------------------------------
expr_c <- call("sum", a, a)
print(expr_c)

# Creating a chunk by rlang::expr -------------------------------
expr_d <- rlang::expr(sum(a, a))
print(expr_d)

## -----------------------------------------------------------------------------
a <- 3
expr_a <- quote(sum(a, a))
expr_b <- substitute(b <- a + a)

eval(expr_a)
eval(expr_b)
print(b)

## -----------------------------------------------------------------------------
chunk_1 <- teal.code::chunk$new(expression = expr_a)
chunk_1$eval()

chunk_2 <- teal.code::chunk$new(expression = expr_b)
chunk_2$eval()
print(b)

## -----------------------------------------------------------------------------
chunk_1 <- teal.code::chunk_call$new(expression = expr_a)
chunk_1$eval()

chunk_2 <- teal.code::chunk_call$new(expression = expr_b)
chunk_2$eval()
print(b)

## -----------------------------------------------------------------------------
# answers the question of whether the code executed without error
chunk_1$is_ok()

# answers the question of whether the code has been executed
chunk_1$is_evaluated()

# returns error messages, if any, in the form of a string
chunk_err <- teal.code::chunk_call$new(expression = quote(stop("error in chunk")))
chunk_err$get_errors() # no error before evaluation
chunk_err$eval()
chunk_err$get_errors()

## -----------------------------------------------------------------------------
# initializing code chunks -------------------------------------------
chunks_container_empty <- teal.code::chunks_new()

## -----------------------------------------------------------------------------
# initializing code chunks -------------------------------------------
env <- new.env()
env$var_to_be_erased <- "some_value"
env$x <- 0
chunks_container <- teal.code::chunks_new(envir = env)

# method to list all variables in the chunks environment
chunks_container$ls()

# function to add a chunk to a chunks container object
teal.code::chunks_push(chunks = chunks_container, expression = quote(print(x)))

# function to get all expressions from a chunks container code stack
teal.code::chunks_get_rcode(chunks_container)

## -----------------------------------------------------------------------------
env <- new.env()
env$anl <- data.frame(left = c(1, 2, 3), right = c(4, 5, 6))
env$x <- "abc"
env$y <- 5

teal.code::chunks_reset(envir = env, chunks = chunks_container)

# note that the variable var_to_be_erased is removed
chunks_container$ls()

# this function is used to extract values of variables in a chunks container environment
# note that the variable x is overriden
teal.code::chunks_get_var("x", chunks = chunks_container)

# note that the code stack has been emptied
teal.code::chunks_get_rcode(chunks_container)

## -----------------------------------------------------------------------------
teal.code::chunks_push(chunks = chunks_container, expression = substitute(y <- y + 1))
teal.code::chunks_push(chunks = chunks_container, expression = substitute(x <- paste0(x, y)))

## -----------------------------------------------------------------------------
teal.code::chunks_get_rcode(chunks_container)

## -----------------------------------------------------------------------------
teal.code::chunks_safe_eval(chunks_container)
teal.code::chunks_get_var("x", chunks = chunks_container)
teal.code::chunks_get_var("y", chunks = chunks_container)

## -----------------------------------------------------------------------------
teal.code::chunks_push(chunks = chunks_container, expression = quote(z <- 10))
teal.code::chunks_get_rcode(chunks_container)

teal.code::chunks_safe_eval(chunks_container)
chunks_container$ls()
teal.code::chunks_get_var("z", chunks = chunks_container)

## -----------------------------------------------------------------------------
teal.code::chunks_push(
  chunks = chunks_container,
  expression = quote(print("I will only be evaluated once"))
)
teal.code::chunks_safe_eval(chunks_container)

teal.code::chunks_push(chunks = chunks_container, expression = quote(rm(z)))

# note that the string "I will only be evaluated once" is not printed again
teal.code::chunks_safe_eval(chunks_container)

# z is removed
chunks_container$ls()

## ---- error=TRUE--------------------------------------------------------------
teal.code::chunks_is_ok(chunks_container)
teal.code::chunks_validate_is_ok(chunks = chunks_container)

# Trying an error inside a chunk ------------------------
teal.code::chunks_push(chunks = chunks_container, expression = quote(stop("ERROR")))
teal.code::chunks_safe_eval(chunks_container)

teal.code::chunks_is_ok(chunks_container)

# internally, teal.code::chunks_safe_eval calls teal.code::chunks_validate_is_ok before returning
teal.code::chunks_validate_is_ok(chunks = chunks_container)

