run_cpp_tests("mmrm")
