test_that("free_cores works as expected", {
  expect_silent(free_cores())
})
