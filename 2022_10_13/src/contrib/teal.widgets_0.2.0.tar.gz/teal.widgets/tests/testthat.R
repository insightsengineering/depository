pkg_name <- "teal.widgets"
library(pkg_name, character.only = TRUE)
testthat::test_check(pkg_name)
