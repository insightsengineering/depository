#' Cached datasets from the 2022_06_27 release of `random.cdisc.data`
#'
#' @name rcd_data_2022_06_27
#'
NULL

#' @rdname rcd_data_2022_06_27
"rcd_2022_06_27_adsl"

#' @rdname rcd_data_2022_06_27
"rcd_2022_06_27_adab"

#' @rdname rcd_data_2022_06_27
"rcd_2022_06_27_adae"

#' @rdname rcd_data_2022_06_27
"rcd_2022_06_27_adaette"

#' @rdname rcd_data_2022_06_27
"rcd_2022_06_27_adcm"

#' @rdname rcd_data_2022_06_27
"rcd_2022_06_27_addv"

#' @rdname rcd_data_2022_06_27
"rcd_2022_06_27_adeg"

#' @rdname rcd_data_2022_06_27
"rcd_2022_06_27_adex"

#' @rdname rcd_data_2022_06_27
"rcd_2022_06_27_adhy"

#' @rdname rcd_data_2022_06_27
"rcd_2022_06_27_adlb"

#' @rdname rcd_data_2022_06_27
"rcd_2022_06_27_admh"

#' @rdname rcd_data_2022_06_27
"rcd_2022_06_27_adpc"

#' @rdname rcd_data_2022_06_27
"rcd_2022_06_27_adpp"

#' @rdname rcd_data_2022_06_27
"rcd_2022_06_27_adqs"

#' @rdname rcd_data_2022_06_27
"rcd_2022_06_27_adrs"

#' @rdname rcd_data_2022_06_27
"rcd_2022_06_27_adsub"

#' @rdname rcd_data_2022_06_27
"rcd_2022_06_27_adtr"

#' @rdname rcd_data_2022_06_27
"rcd_2022_06_27_adtte"

#' @rdname rcd_data_2022_06_27
"rcd_2022_06_27_advs"
