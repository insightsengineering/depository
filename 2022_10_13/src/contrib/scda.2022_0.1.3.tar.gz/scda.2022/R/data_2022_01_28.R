#' Cached datasets from the 2022_01_28 release of `random.cdisc.data`
#'
#' @name rcd_data_2022_01_28
#'
NULL

#' @rdname rcd_data_2022_01_28
"rcd_2022_01_28_adsl"

#' @rdname rcd_data_2022_01_28
"rcd_2022_01_28_adae"

#' @rdname rcd_data_2022_01_28
"rcd_2022_01_28_adaette"

#' @rdname rcd_data_2022_01_28
"rcd_2022_01_28_adcm"

#' @rdname rcd_data_2022_01_28
"rcd_2022_01_28_addv"

#' @rdname rcd_data_2022_01_28
"rcd_2022_01_28_adeg"

#' @rdname rcd_data_2022_01_28
"rcd_2022_01_28_adex"

#' @rdname rcd_data_2022_01_28
"rcd_2022_01_28_adhy"

#' @rdname rcd_data_2022_01_28
"rcd_2022_01_28_adlb"

#' @rdname rcd_data_2022_01_28
"rcd_2022_01_28_admh"

#' @rdname rcd_data_2022_01_28
"rcd_2022_01_28_adpc"

#' @rdname rcd_data_2022_01_28
"rcd_2022_01_28_adpp"

#' @rdname rcd_data_2022_01_28
"rcd_2022_01_28_adqs"

#' @rdname rcd_data_2022_01_28
"rcd_2022_01_28_adrs"

#' @rdname rcd_data_2022_01_28
"rcd_2022_01_28_adsub"

#' @rdname rcd_data_2022_01_28
"rcd_2022_01_28_adtr"

#' @rdname rcd_data_2022_01_28
"rcd_2022_01_28_adtte"

#' @rdname rcd_data_2022_01_28
"rcd_2022_01_28_advs"
