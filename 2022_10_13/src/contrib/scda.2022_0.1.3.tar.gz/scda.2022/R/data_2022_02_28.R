#' Cached datasets from the 2022_02_28 release of `random.cdisc.data`
#'
#' @name rcd_data_2022_02_28
#'
NULL

#' @rdname rcd_data_2022_02_28
"rcd_2022_02_28_adsl"

#' @rdname rcd_data_2022_02_28
"rcd_2022_02_28_adab"

#' @rdname rcd_data_2022_02_28
"rcd_2022_02_28_adae"

#' @rdname rcd_data_2022_02_28
"rcd_2022_02_28_adaette"

#' @rdname rcd_data_2022_02_28
"rcd_2022_02_28_adcm"

#' @rdname rcd_data_2022_02_28
"rcd_2022_02_28_addv"

#' @rdname rcd_data_2022_02_28
"rcd_2022_02_28_adeg"

#' @rdname rcd_data_2022_02_28
"rcd_2022_02_28_adex"

#' @rdname rcd_data_2022_02_28
"rcd_2022_02_28_adhy"

#' @rdname rcd_data_2022_02_28
"rcd_2022_02_28_adlb"

#' @rdname rcd_data_2022_02_28
"rcd_2022_02_28_admh"

#' @rdname rcd_data_2022_02_28
"rcd_2022_02_28_adpc"

#' @rdname rcd_data_2022_02_28
"rcd_2022_02_28_adpp"

#' @rdname rcd_data_2022_02_28
"rcd_2022_02_28_adqs"

#' @rdname rcd_data_2022_02_28
"rcd_2022_02_28_adrs"

#' @rdname rcd_data_2022_02_28
"rcd_2022_02_28_adsub"

#' @rdname rcd_data_2022_02_28
"rcd_2022_02_28_adtr"

#' @rdname rcd_data_2022_02_28
"rcd_2022_02_28_adtte"

#' @rdname rcd_data_2022_02_28
"rcd_2022_02_28_advs"
