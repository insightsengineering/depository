#' Cached datasets from `random.cdisc.data`
#'
#' Cached datasets from 2022 releases of `random.cdisc.data`.
#'
#' @name rcd_data_2022
#'
NULL

#' @rdname rcd_data_2022
"rcd_2022_01_28"

#' @rdname rcd_data_2022
"rcd_2022_02_28"

#' @rdname rcd_data_2022
"rcd_2022_06_27"
