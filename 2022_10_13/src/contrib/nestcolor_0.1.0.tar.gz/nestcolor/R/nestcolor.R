# To silence false positive R CMD CHECK notes
#' @importFrom lifecycle badge
#'
#' @keywords internal
NULL
