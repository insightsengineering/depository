testthat::test_that("template_coxreg generates correct univariate cox regression expressions", {
  result <- template_coxreg_u(
    dataname = "adrs",
    cov_var = NULL,
    arm_var = "ARMCD",
    cnsr_var = "CNSR",
    aval_var = "AVAL",
    ref_arm = "ARM A",
    comp_arm = c("ARM B", "ARM C"),
    paramcd = "OS",
    at = list(AGE = c(35, 45)),
    strata = "STRATA1",
    combine_comp_arms = FALSE,
    control = control_coxreg(
      pval_method = "wald",
      ties = "efron"
    )
  )

  lapply(result, styled_expr)
  expected <- list(
    data = quote({
      anl <- adrs %>%
        dplyr::filter(ARMCD %in% c("ARM A", "ARM B", "ARM C")) %>%
        dplyr::mutate(ARMCD = stats::relevel(ARMCD, ref = "ARM A")) %>%
        dplyr::mutate(ARMCD = droplevels(ARMCD)) %>%
        dplyr::mutate(event = 1 - CNSR) %>%
        df_explicit_na(na_level = "")
      variables <- list(time = "AVAL", event = "event", arm = "ARMCD", covariates = NULL)
      variables$strata <- "STRATA1"
      model <- fit_coxreg_univar(
        variables = variables,
        data = anl,
        control = list(
          pval_method = "wald",
          ties = "efron",
          conf_level = 0.95,
          interaction = FALSE
        ),
        at = list(AGE = c(35, 45))
      )
      df <- broom::tidy(model)
    }),
    layout = quote(
      lyt <- rtables::basic_table(
        title = "Multi-Variable Cox Regression for OS",
        main_footer = c(
          "p-value method for Coxph (Hazard Ratio): wald",
          "Ties for Coxph (Hazard Ratio): efron"
        )
      ) %>%
        rtables::split_rows_by("effect") %>%
        rtables::append_topleft("OS") %>%
        rtables::split_rows_by("term", child_labels = "hidden") %>%
        summarize_coxreg(multivar = FALSE, conf_level = 0.95, vars = c("n", "hr", "ci", "pval"))
    ),
    table = quote(result <- rtables::build_table(lyt = lyt, df = df))
  )
  testthat::expect_equal(result, expected)
})


testthat::test_that("template_coxreg generates correct univariate cox regression expressions with interactions", {
  result <- template_coxreg_u(
    dataname = "adrs",
    cov_var = NULL,
    arm_var = "ARMCD",
    cnsr_var = "CNSR",
    aval_var = "AVAL",
    ref_arm = "ARM A",
    comp_arm = c("ARM B", "ARM C"),
    paramcd = "OS",
    at = list(AGE = c(35, 45)),
    strata = "STRATA1",
    combine_comp_arms = FALSE,
    control = control_coxreg(
      pval_method = "wald",
      ties = "efron",
      interaction = TRUE
    )
  )

  lapply(result, styled_expr)
  expected <- list(
    data = quote({
      anl <- adrs %>%
        dplyr::filter(ARMCD %in% c("ARM A", "ARM B", "ARM C")) %>%
        dplyr::mutate(ARMCD = stats::relevel(ARMCD, ref = "ARM A")) %>%
        dplyr::mutate(ARMCD = droplevels(ARMCD)) %>%
        dplyr::mutate(event = 1 - CNSR) %>%
        df_explicit_na(na_level = "")
      variables <- list(time = "AVAL", event = "event", arm = "ARMCD", covariates = NULL)
      variables$strata <- "STRATA1"
      model <- fit_coxreg_univar(
        variables = variables,
        data = anl,
        control = list(
          pval_method = "wald",
          ties = "efron",
          conf_level = 0.95,
          interaction = TRUE
        ),
        at = list(AGE = c(35, 45))
      )
      df <- broom::tidy(model)
    }),
    layout = quote(
      lyt <- rtables::basic_table(
        title = "Multi-Variable Cox Regression for OS",
        main_footer = c(
          "p-value method for Coxph (Hazard Ratio): wald",
          "Ties for Coxph (Hazard Ratio): efron"
        )
      ) %>%
        rtables::split_rows_by("effect") %>%
        rtables::append_topleft("OS") %>%
        rtables::split_rows_by("term", child_labels = "hidden") %>%
        summarize_coxreg(multivar = FALSE, conf_level = 0.95, vars = c("n", "hr", "ci", "pval", "pval_inter"))
    ),
    table = quote(result <- rtables::build_table(lyt = lyt, df = df))
  )
  testthat::expect_equal(result, expected)
})

testthat::test_that("template_coxreg generates correct multivariate cox regression expressions", {
  result <- template_coxreg_m(
    dataname = "adrs",
    cov_var = c("AGE", "SEX"),
    arm_var = "ARM",
    cnsr_var = "CNSR",
    aval_var = "AVAL",
    ref_arm = "A: Drug X",
    comp_arm = c("B: Placebo", "C: Combination"),
    paramcd = "OS",
    combine_comp_arms = TRUE,
    control = control_coxreg()
  )

  expected <- list(
    data = quote({
      anl <- adrs %>%
        dplyr::filter(ARM %in% c("A: Drug X", "B: Placebo", "C: Combination")) %>%
        dplyr::mutate(ARM = stats::relevel(ARM, ref = "A: Drug X")) %>%
        dplyr::mutate(ARM = droplevels(ARM)) %>%
        dplyr::mutate(ARM = combine_levels(x = ARM, levels = c("B: Placebo", "C: Combination"))) %>%
        dplyr::mutate(event = 1 - CNSR) %>%
        df_explicit_na(na_level = "")
      variables <- list(time = "AVAL", event = "event", arm = "ARM", covariates = c("AGE", "SEX"))
      model <- fit_coxreg_multivar(
        variables = variables,
        data = anl,
        control = list(
          pval_method = "wald",
          ties = "exact",
          conf_level = 0.95,
          interaction = FALSE
        )
      )
      df <- broom::tidy(model)
    }),
    layout = quote(
      lyt <- rtables::basic_table(
        title = "Cox Regression for OS",
        main_footer = c(
          "p-value method for Coxph (Hazard Ratio): wald",
          "Ties for Coxph (Hazard Ratio): exact"
        )
      ) %>%
        rtables::append_topleft("OS") %>%
        rtables::split_rows_by("term", child_labels = "hidden") %>%
        summarize_coxreg(multivar = TRUE, conf_level = 0.95, vars = c("n", "hr", "ci", "pval"))
    ),
    table = quote({
      result <- rtables::build_table(lyt = lyt, df = df)
      result
    })
  )
  testthat::expect_equal(result, expected)
})
