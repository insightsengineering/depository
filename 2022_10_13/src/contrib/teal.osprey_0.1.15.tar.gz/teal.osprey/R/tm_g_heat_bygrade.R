#' Teal module for the heatmap by grade
#'
#' Display the heatmap by grade as a shiny module
#'
#' @inheritParams teal.widgets::standard_layout
#' @inheritParams argument_convention
#' @param sl_dataname (\code{character}) subject level dataset name,
#' needs to be available in the list passed to the \code{data}
#' argument of \code{\link[teal]{init}}
#' @param ex_dataname (\code{character}) exposures dataset name,
#' needs to be available in the list passed to the \code{data}
#' argument of \code{\link[teal]{init}} \cr
#' @param ae_dataname (\code{character}) adverse events dataset name,
#' needs to be available in the list passed to the \code{data}
#' argument of \code{\link[teal]{init}} \cr
#' @param cm_dataname (\code{character}) concomitant medications dataset name,
#' needs to be available in the list passed to the \code{data}
#' argument of \code{\link[teal]{init}} \cr
#' specify to \code{NA} if no concomitant medications data is available
#' @param id_var (\code{choices_seleced}) unique subject ID variable
#' @param visit_var (\code{choices_seleced}) analysis visit variable
#' @param ongo_var (\code{choices_seleced}) study ongoing status variable,
#' This variable is a derived logical variable. Usually it can be derived from \code{EOSSTT}.
#' @param anno_var (\code{choices_seleced}) annotation variable
#' @param heat_var (\code{choices_seleced}) heatmap variable
#' @param conmed_var (\code{choices_seleced}) concomitant medications variable,
#' specify to \code{NA} if no concomitant medications data is available
#'
#' @inherit argument_convention return
#'
#' @export
#'
#' @examples
#' library(scda)
#' library(dplyr)
#' library(nestcolor)
#' latest_data <- synthetic_cdisc_data("latest")
#' ADSL <- latest_data$adsl %>% slice(1:30)
#' ADEX <- latest_data$adex %>% filter(USUBJID %in% ADSL$USUBJID)
#' ADAE <- latest_data$adae %>% filter(USUBJID %in% ADSL$USUBJID)
#' ADCM <- latest_data$adcm %>% filter(USUBJID %in% ADSL$USUBJID)
#'
#' # This preprocess is only to force legacy standard on ADCM
#' ADCM <- ADCM %>%
#'   select(-starts_with("ATC")) %>%
#'   unique()
#'
#' # function to derive AVISIT from ADEX
#' add_visit <- function(data_need_visit) {
#'   visit_dates <- ADEX %>%
#'     filter(PARAMCD == "DOSE") %>%
#'     distinct(USUBJID, AVISIT, ASTDTM) %>%
#'     group_by(USUBJID) %>%
#'     arrange(ASTDTM) %>%
#'     mutate(next_vis = lead(ASTDTM), is_last = ifelse(is.na(next_vis), TRUE, FALSE)) %>%
#'     rename(this_vis = ASTDTM)
#'   data_visit <- data_need_visit %>%
#'     select(USUBJID, ASTDTM) %>%
#'     left_join(visit_dates, by = "USUBJID") %>%
#'     filter(ASTDTM > this_vis & (ASTDTM < next_vis | is_last == TRUE)) %>%
#'     left_join(data_need_visit) %>%
#'     distinct()
#'   return(data_visit)
#' }
#' # derive AVISIT for ADAE and ADCM
#' ADAE <- add_visit(ADAE)
#' ADCM <- add_visit(ADCM)
#' # derive ongoing status variable for ADEX
#' ADEX <- ADEX %>%
#'   filter(PARCAT1 == "INDIVIDUAL") %>%
#'   mutate(ongo_status = (EOSSTT == "ONGOING"))
#'
#' app <- init(
#'   data = cdisc_data(
#'     cdisc_dataset("ADSL", ADSL),
#'     cdisc_dataset("ADEX", ADEX),
#'     cdisc_dataset("ADAE", ADAE),
#'     cdisc_dataset("ADCM", ADCM, keys = c("STUDYID", "USUBJID", "ASTDTM", "CMSEQ", "CMDECOD")),
#'     code = "
#'     latest_data <- synthetic_cdisc_data('latest')
#'     ADSL <- latest_data$adsl %>% slice(1:30)
#'     ADEX <- latest_data$adex %>% filter(USUBJID %in% ADSL$USUBJID)
#'     ADAE <- latest_data$adae %>% filter(USUBJID %in% ADSL$USUBJID)
#'     ADCM <- latest_data$adcm %>% filter(USUBJID %in% ADSL$USUBJID)
#'     ADCM <- ADCM %>% select(-starts_with(\"ATC\")) %>% unique()
#'     ADEX  <- ADEX %>%
#'       filter(PARCAT1 == 'INDIVIDUAL') %>%
#'       mutate(ongo_status = (EOSSTT == 'ONGOING'))
#'     add_visit <- function(data_need_visit) {
#'       visit_dates <- ADEX %>%
#'         filter(PARAMCD == 'DOSE') %>%
#'         distinct(USUBJID, AVISIT, ASTDTM) %>%
#'         group_by(USUBJID) %>%
#'         arrange(ASTDTM) %>%
#'         mutate(next_vis = lead(ASTDTM), is_last = ifelse(is.na(next_vis), TRUE, FALSE)) %>%
#'         rename(this_vis = ASTDTM)
#'       data_visit <- data_need_visit %>%
#'         select(USUBJID, ASTDTM) %>%
#'         left_join(visit_dates, by = 'USUBJID') %>%
#'         filter(ASTDTM > this_vis & (ASTDTM < next_vis | is_last == TRUE)) %>%
#'         left_join(data_need_visit) %>% distinct()
#'       return(data_visit)
#'     }
#'     ADAE <- add_visit(ADAE)
#'     ADCM <- add_visit(ADCM)
#'     ",
#'     check = TRUE
#'   ),
#'   modules = modules(
#'     tm_g_heat_bygrade(
#'       label = "Heatmap by grade",
#'       sl_dataname = "ADSL",
#'       ex_dataname = "ADEX",
#'       ae_dataname = "ADAE",
#'       cm_dataname = "ADCM",
#'       id_var = choices_selected(
#'         selected = "USUBJID",
#'         choices = c("USUBJID", "SUBJID")
#'       ),
#'       visit_var = choices_selected(
#'         selected = "AVISIT",
#'         choices = c("AVISIT")
#'       ),
#'       ongo_var = choices_selected(
#'         selected = "ongo_status",
#'         choices = c("ongo_status")
#'       ),
#'       anno_var = choices_selected(
#'         selected = c("SEX", "COUNTRY"),
#'         choices = c("SEX", "COUNTRY", "USUBJID")
#'       ),
#'       heat_var = choices_selected(
#'         selected = "AETOXGR",
#'         choices = c("AETOXGR")
#'       ),
#'       conmed_var = choices_selected(
#'         selected = "CMDECOD",
#'         choices = c("CMDECOD")
#'       ),
#'       plot_height = c(600, 200, 2000)
#'     )
#'   )
#' )
#' \dontrun{
#' shinyApp(app$ui, app$server)
#' }
tm_g_heat_bygrade <- function(label,
                              sl_dataname,
                              ex_dataname,
                              ae_dataname,
                              cm_dataname,
                              id_var,
                              visit_var,
                              ongo_var,
                              anno_var,
                              heat_var,
                              conmed_var = NULL,
                              fontsize = c(5, 3, 7),
                              plot_height = c(600L, 200L, 2000L),
                              plot_width = NULL) {
  logger::log_info("Initializing tm_g_heat_bygrade")
  args <- as.list(environment())

  checkmate::assert_string(label)
  checkmate::assert_string(sl_dataname)
  checkmate::assert_string(ex_dataname)
  checkmate::assert_string(ae_dataname)
  checkmate::assert_string(cm_dataname, na.ok = TRUE)
  checkmate::assert_class(id_var, classes = "choices_selected")
  checkmate::assert_class(visit_var, classes = "choices_selected")
  checkmate::assert_class(ongo_var, classes = "choices_selected")
  checkmate::assert_class(anno_var, classes = "choices_selected")
  checkmate::assert_class(heat_var, classes = "choices_selected")
  checkmate::assert_class(conmed_var, classes = "choices_selected", null.ok = TRUE)
  checkmate::assert(
    checkmate::check_number(fontsize, finite = TRUE),
    checkmate::assert(
      combine = "and",
      .var.name = "fontsize",
      checkmate::check_numeric(fontsize, len = 3, any.missing = FALSE, finite = TRUE),
      checkmate::check_numeric(fontsize[1], lower = fontsize[2], upper = fontsize[3])
    )
  )
  checkmate::assert_numeric(plot_height, len = 3, any.missing = FALSE, finite = TRUE)
  checkmate::assert_numeric(plot_height[1], lower = plot_height[2], upper = plot_height[3], .var.name = "plot_height")
  checkmate::assert_numeric(plot_width, len = 3, any.missing = FALSE, null.ok = TRUE, finite = TRUE)
  checkmate::assert_numeric(
    plot_width[1],
    lower = plot_width[2],
    upper = plot_width[3],
    null.ok = TRUE,
    .var.name = "plot_width"
  )

  module(
    label = label,
    server = srv_g_heatmap_bygrade,
    server_args = list(
      label = label,
      sl_dataname = sl_dataname,
      ex_dataname = ex_dataname,
      ae_dataname = ae_dataname,
      cm_dataname = cm_dataname,
      plot_height = plot_height,
      plot_width = plot_width
    ),
    ui = ui_g_heatmap_bygrade,
    ui_args = args,
    filters = "all"
  )
}

ui_g_heatmap_bygrade <- function(id, ...) {
  ns <- NS(id)
  args <- list(...)

  shiny::tagList(
    include_css_files("custom"),
    teal.widgets::standard_layout(
      output = teal.widgets::white_small_well(
        plot_decorate_output(id = ns(NULL))
      ),
      encoding = div(
        ### Reporter
        teal.reporter::simple_reporter_ui(ns("simple_reporter")),
        ###
        teal.widgets::optionalSelectInput(
          ns("id_var"),
          "ID Variable",
          choices = args$id_var$choices,
          selected = args$id_var$selected,
          multiple = FALSE
        ),
        teal.widgets::optionalSelectInput(
          ns("visit_var"),
          "Visit Variable",
          choices = args$visit_var$choices,
          selected = args$visit_var$selected,
          multiple = FALSE
        ),
        teal.widgets::optionalSelectInput(
          ns("ongo_var"),
          "Study Ongoing Status Variable",
          choices = args$ongo_var$choices,
          selected = args$ongo_var$selected,
          multiple = FALSE
        ),
        teal.widgets::optionalSelectInput(
          ns("anno_var"),
          "Annotation Variables",
          choices = args$anno_var$choices,
          selected = args$anno_var$selected,
          multiple = TRUE
        ),
        teal.widgets::optionalSelectInput(
          ns("heat_var"),
          "Heat Variable",
          choices = args$heat_var$choices,
          selected = args$heat_var$selected,
          multiple = FALSE
        ),
        helpText("Plot conmed"),
        div(
          class = "pretty-left-border",
          uiOutput(ns("plot_cm_output"))
        ),
        conditionalPanel(
          paste0("input['", ns("plot_cm"), "']"),
          teal.widgets::optionalSelectInput(
            ns("conmed_var"),
            "Conmed Variable",
            choices = args$conmed_var$choices,
            selected = args$conmed_var$selected,
            multiple = FALSE
          ),
          selectInput(
            ns("conmed_level"),
            "Conmed Levels",
            choices = args$conmed_var$choices,
            selected = args$conmed_var$selected,
            multiple = TRUE
          )
        ),
        ui_g_decorate(
          ns(NULL),
          fontsize = args$fontsize,
          titles = "Heatmap by Grade",
          footnotes = ""
        )
      ),
      forms = get_rcode_ui(ns("rcode"))
    )
  )
}

srv_g_heatmap_bygrade <- function(id,
                                  datasets,
                                  reporter,
                                  sl_dataname,
                                  ex_dataname,
                                  ae_dataname,
                                  cm_dataname,
                                  label,
                                  plot_height,
                                  plot_width) {
  with_reporter <- !missing(reporter) && inherits(reporter, "Reporter")

  moduleServer(id, function(input, output, session) {
    iv <- shinyvalidate::InputValidator$new()
    iv$add_rule("heat_var", shinyvalidate::sv_required())
    iv$add_rule("id_var", shinyvalidate::sv_required())
    iv$add_rule("visit_var", shinyvalidate::sv_required())
    iv$add_rule("ongo_var", shinyvalidate::sv_required())
    iv$enable()

    teal.code::init_chunks()
    decorate_output <- srv_g_decorate(id = NULL, plt = plt, plot_height = plot_height, plot_width = plot_width) # nolint
    font_size <- decorate_output$font_size
    pws <- decorate_output$pws

    observeEvent(cm_dataname, {
      if (!is.na(cm_dataname)) {
        output$plot_cm_output <- renderUI({
          checkboxInput(
            session$ns("plot_cm"),
            "Yes",
            value = !is.na(cm_dataname)
          )
        })
      }
    })

    observeEvent(input$plot_cm, {
      ADCM <- datasets$get_data(cm_dataname, filtered = TRUE) # nolint
      ADCM_label <- formatters::var_labels(datasets$get_data(cm_dataname, filtered = FALSE), fill = FALSE) # nolint
      formatters::var_labels(ADCM) <- ADCM_label # nolint
      choices <- levels(ADCM[[input$conmed_var]])

      updateSelectInput(
        session,
        "conmed_level",
        selected = choices[1:3],
        choices = choices
      )
    })

    plt <- reactive({
      iv_len <- shinyvalidate::InputValidator$new()
      anno_var <- input$anno_var
      iv_len$add_rule("anno_var", function(x) if (length(x) > 2) "Please include no more than 2 annotation variables.")
      iv_len$enable()
      validate(need(iv_len$is_valid(), "Misspecification error: please observe red flags in the encodings."))
      validate(need(iv$is_valid(), "Misspecification error: please observe red flags in the encodings."))

      ADSL <- datasets$get_data(sl_dataname, filtered = TRUE) # nolint
      ADEX <- datasets$get_data(ex_dataname, filtered = TRUE) # nolint
      ADAE <- datasets$get_data(ae_dataname, filtered = TRUE) # nolint

      # assign labels back to the data
      formatters::var_labels(ADSL) <- # nolint
        formatters::var_labels(datasets$get_data(sl_dataname, filtered = FALSE), fill = FALSE)
      formatters::var_labels(ADEX) <- # nolint
        formatters::var_labels(datasets$get_data(ex_dataname, filtered = FALSE), fill = FALSE)
      formatters::var_labels(ADAE) <- # nolint
        formatters::var_labels(datasets$get_data(ae_dataname, filtered = FALSE), fill = FALSE)
      validate(need(nrow(ADSL) > 0, "Please select at least one subject"))

      validate(need(
        input$ongo_var %in% names(ADEX),
        paste("Study Ongoing Status must be a variable in", ex_dataname, sep = " ")
      ))

      validate(need(
        checkmate::test_logical(ADEX[[input$ongo_var]], min.len = 1, any.missing = FALSE),
        "Study Ongoing Status must be a logical variable"
      ))

      validate(need(
        all(anno_var %in% names(ADSL)),
        paste("Please only select annotation variable(s) in", sl_dataname, sep = " ")
      ))

      validate(need(
        !(input$id_var %in% anno_var),
        paste("Please de-select", input$id_var, "in annotation variable(s)", sep = " ")
      ))

      if (input$plot_cm) {
        ADCM <- datasets$get_data(cm_dataname, filtered = TRUE) # nolint
        ADCM_label <- formatters::var_labels(datasets$get_data(cm_dataname, filtered = FALSE), fill = FALSE) # nolint
        formatters::var_labels(ADCM) <- ADCM_label # nolint
        validate(
          need(
            input$conmed_var %in% names(ADCM),
            paste("Please select a Conmed Variable in", cm_dataname, sep = " ")
          )
        )
        validate(need(
          all(input$conmed_level %in% levels(ADCM[[input$conmed_var]])),
          "Updating Conmed Levels"
        ))
      }

      teal.code::chunks_reset(envir = environment())

      if (input$plot_cm) {
        iv_cm <- shinyvalidate::InputValidator$new()
        conmed_var <- input$conmed_var
        iv_cm$add_rule("conmed_var", shinyvalidate::sv_required())
        iv_cm$enable()
        validate(need(iv_cm$is_valid(), "Misspecification error: please observe red flags in the encodings."))

        teal.code::chunks_push(
          id = "conmed_data call",
          expression = bquote({
            conmed_data <- ADCM %>%
              filter(!!sym(.(conmed_var)) %in% .(input$conmed_level))
            conmed_var <- .(conmed_var)
            conmed_data[[conmed_var]] <-
              factor(conmed_data[[conmed_var]], levels = unique(conmed_data[[conmed_var]]))
            formatters::var_labels(conmed_data)[conmed_var] <-
              formatters::var_labels(ADCM, fill = FALSE)[conmed_var]
          })
        )
      } else {
        teal.code::chunks_push(
          id = "conmed_data call",
          expression = bquote({
            conmed_data <- conmed_var <- NULL
          })
        )
      }
      teal.code::chunks_safe_eval()

      validate(
        need(length(input$conmed_level) <= 3, "Please select no more than 3 conmed levels")
      )

      teal.code::chunks_push(
        id = "g_heat_bygrade call",
        expression = bquote({
          exp_data <- ADEX %>%
            filter(PARCAT1 == "INDIVIDUAL")

          osprey::g_heat_bygrade(
            id_var = .(input$id_var),
            exp_data = exp_data,
            visit_var = .(input$visit_var),
            ongo_var = .(input$ongo_var),
            anno_data = ADSL[c(.(input$anno_var), .(input$id_var))],
            anno_var = .(input$anno_var),
            heat_data = ADAE %>% select(!!.(input$id_var), !!.(input$visit_var), !!.(input$heat_var)),
            heat_color_var = .(input$heat_var),
            conmed_data = conmed_data,
            conmed_var = conmed_var
          )
        })
      )

      teal.code::chunks_safe_eval()
    })


    get_rcode_srv(
      id = "rcode",
      datasets = datasets,
      modal_title = paste("R code for", label),
      datanames = datasets$datanames()
    )

    ### REPORTER
    if (with_reporter) {
      card_fun <- function(comment) {
        card <- teal.reporter::TealReportCard$new()
        card$set_name("Heatmap by Grade")
        card$append_text("Heatmap by Grade", "header2")
        card$append_fs(datasets$get_filter_state())
        card$append_text("Plot", "header3")
        card$append_plot(plt(), dim = pws$dim())
        if (!comment == "") {
          card$append_text("Comment", "header3")
          card$append_text(comment)
        }
        card$append_src(paste(get_rcode(
          chunks = teal.code::get_chunks_object(parent_idx = 2L),
          datasets = datasets,
          title = "",
          description = ""
        ), collapse = "\n"))
        card
      }
      teal.reporter::simple_reporter_srv("simple_reporter", reporter = reporter, card_fun = card_fun)
    }
  })
}
