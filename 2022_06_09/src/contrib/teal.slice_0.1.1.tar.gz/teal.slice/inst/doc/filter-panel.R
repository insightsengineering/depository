## ----echo=FALSE, out.width='75%'----------------------------------------------
knitr::include_graphics("./images/filter_panel/filter_panel_uml_all.jpg")

## ----echo=FALSE, out.width='100%'---------------------------------------------
knitr::include_graphics("./images/filter_panel/filtered_data_init.jpg")

## ----echo=FALSE, out.width='75%'----------------------------------------------
knitr::include_graphics("./images/filter_panel/class_details_filtered_data.jpg")

## ----echo=FALSE, out.width='100%'---------------------------------------------
knitr::include_graphics("./images/filter_panel/class_details_filtered_dataset.jpg")

## ----echo=FALSE, out.width='100%'---------------------------------------------
knitr::include_graphics("./images/filter_panel/class_details_filter_states.jpg")

## ----echo=FALSE, out.width='100%'---------------------------------------------
knitr::include_graphics("./images/filter_panel/class_details_filter_state.jpg")

## ----echo=FALSE, out.width='100%'---------------------------------------------
knitr::include_graphics("./images/filter_panel/get_call_overview.jpg")

## ----echo=FALSE, out.width='100%'---------------------------------------------
knitr::include_graphics("./images/filter_panel/get_call_example.jpg")

## ---- message=FALSE, warning=FALSE--------------------------------------------
library(teal.slice)
datasets <- teal.slice:::FilteredData$new()
datasets$set_dataset(teal.data::dataset(dataname = "iris", x = iris))
datasets$set_dataset(teal.data::dataset(dataname = "mtcars", x = mtcars))

set_filter_state(
  datasets = datasets,
  filter = list(
    iris = list(Species = list(selected = "virginica", keep_na = FALSE)),
    mtcars = list(mpg = list(selected = c(20.0, 25.0), keep_na = FALSE, keep_inf = FALSE))
  )
)

## ---- message=FALSE, warning=FALSE--------------------------------------------
get_filter_state(datasets)

## ---- message=FALSE, warning=FALSE--------------------------------------------
remove_filter_state(
  datasets = datasets,
  filter = list(iris = c("Species"))
)

## ---- message=FALSE, warning=FALSE--------------------------------------------
set_filter_state(
  datasets = datasets,
  filter = list(
    mtcars = list(mpg = list(selected = c(22.0, 25.0)))
  )
)

## ---- message=FALSE, warning=FALSE--------------------------------------------
clear_filter_states(datasets)

## -----------------------------------------------------------------------------
library(shiny)
datasets <- teal.slice:::FilteredData$new()
datasets$set_dataset(teal.data::dataset(dataname = "iris", x = iris))
datasets$set_dataset(teal.data::dataset(dataname = "mtcars", x = mtcars))

app <- shinyApp(
  ui = fluidPage(
    fluidRow(
      column(
        width = 9,
        id = "teal_primary_col",
        shiny::tagList(
          actionButton("add_species_filter", "Set iris$Species filter"),
          actionButton("remove_species_filter", "Remove iris$Species filter"),
          actionButton("remove_all_filters", "Remove all filters"),
          verbatimTextOutput("rcode"),
          verbatimTextOutput("filter_state")
        )
      ),
      column(
        width = 3,
        id = "teal_secondary_col",
        datasets$ui_filter_panel("filter_panel")
      )
    )
  ),
  server = function(input, output, session) {
    datasets$srv_filter_panel("filter_panel")
    output$filter_state <- renderPrint(get_filter_state(datasets))
    output$rcode <- renderText(
      paste(
        sapply(c("iris", "mtcars"), datasets$get_call),
        collapse = "\n"
      )
    )
    observeEvent(input$add_species_filter, {
      set_filter_state(
        datasets,
        list(iris = list(Species = list(selected = c("setosa", "versicolor"))))
      )
    })
    observeEvent(input$remove_species_filter, {
      states <- get_filter_state(datasets)
      if (!is.null(states$iris$Species)) {
        remove_filter_state(datasets, list(iris = "Species"))
      }
    })
    observeEvent(input$remove_all_filters, clear_filter_states(datasets))
  }
)
if (interactive()) {
  runApp(app)
}

