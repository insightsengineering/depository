## ----echo=FALSE, out.width='60%'----------------------------------------------
knitr::include_graphics("./images/teal-slice/filter-panel.png")

## -----------------------------------------------------------------------------
library(teal.slice)
library(shiny)

# create a FilteredData object
datasets <- teal.slice:::FilteredData$new()
# Add the teal datasets into it
datasets$set_dataset(teal.data::dataset(dataname = "iris", x = iris))
datasets$set_dataset(teal.data::dataset(dataname = "mtcars", x = mtcars))

app <- shinyApp(
  ui = fluidPage(
    fluidRow(
      column(
        width = 9,
        tabsetPanel(
          tabPanel(title = "iris", dataTableOutput("iris_table")),
          tabPanel(title = "mtcars", dataTableOutput("mtcars_table"))
        )
      ),
      # ui for the filter panel
      column(width = 3, datasets$ui_filter_panel("filter_panel"))
    )
  ),
  server = function(input, output, session) {
    # this is the shiny server function for the filter panel and the datasets
    # object can now be used inside the application
    datasets$srv_filter_panel("filter_panel")

    # get the filtered datasets and put them inside reactives for analysis
    iris_filtered_data <- reactive(datasets$get_data(dataname = "iris", filtered = TRUE))
    mtcars_filtered_data <- reactive(datasets$get_data(dataname = "mtcars", filtered = TRUE))

    output$iris_table <- renderDataTable(iris_filtered_data())
    output$mtcars_table <- renderDataTable(mtcars_filtered_data())
  }
)
if (interactive()) {
  runApp(app)
}

## ---- eval=FALSE--------------------------------------------------------------
#  set_filter_state(
#    datasets,
#    list(iris = list(Species = list(selected = c("setosa", "versicolor"))))
#  )

