# label of checkbox to keep / remove NAs
label_keep_na_count <- function(na_count) {
  sprintf("Keep NA (%s)", na_count)
}

#' Initializes `FilterState`
#'
#' Initializes `FilterState` depending on a variable class.\cr
#' @param x (`vector`)\cr
#'   values of the variable used in filter
#'
#' @param varname (`character(1)`, `name`)\cr
#'   name of the variable
#'
#' @param varlabel (`character(1)`)\cr
#'   label of the variable (optional).
#'
#' @param input_dataname (`name` or `call`)\cr
#'   name of dataset where `x` is taken from. Must be specified if `extract_type` argument
#'   is not empty.
#'
#' @param extract_type (`character(0)`, `character(1)`)\cr
#' whether condition calls should be prefixed by dataname. Possible values:
#' \itemize{
#' \item{`character(0)` (default)}{ `varname` in the condition call will not be prefixed}
#' \item{`"list"`}{ `varname` in the condition call will be returned as `<input_dataname>$<varname>`}
#' \item{`"matrix"`}{ `varname` in the condition call will be returned as `<input_dataname>[, <varname>]`}
#' }
#' @keywords internal
#'
#' @examples
#' filter_state <- teal.slice:::RangeFilterState$new(
#'   c(1:10, NA, Inf),
#'   varname = "x",
#'   varlabel = "Pretty name",
#'   input_dataname = as.name("dataname"),
#'   extract_type = "matrix"
#' )
#'
#' filter_state$get_varname()
#' filter_state$get_varlabel()
#' isolate(filter_state$get_call())
#' \dontrun{
#' shinyApp(
#'   ui = fluidPage(
#'     isolate(filter_state$ui(id = "app")),
#'     verbatimTextOutput("call")
#'   ),
#'   server = function(input, output, session) {
#'     filter_state$server("app")
#'
#'     output$call <- renderText(
#'       deparse1(filter_state$get_call(), collapse = "\n")
#'     )
#'   }
#' )
#' }
#' @return `FilterState` object
init_filter_state <- function(x,
                              varname,
                              varlabel = attr(x, "label"),
                              input_dataname = NULL,
                              extract_type = character(0)) {
  if (is.null(varlabel)) varlabel <- character(0)
  checkmate::assert(
    checkmate::check_string(varname),
    checkmate::check_class(varname, "name")
  )
  checkmate::assert_character(varlabel, max.len = 1, any.missing = FALSE)
  stopifnot(is.null(input_dataname) || is.name(input_dataname) || is.call(input_dataname))
  checkmate::assert_character(extract_type, max.len = 1, any.missing = FALSE)
  stopifnot(
    length(extract_type) == 0 ||
      length(extract_type) == 1 && !is.null(input_dataname)
  )
  stopifnot(extract_type %in% c("list", "matrix"))

  if (all(is.na(x))) {
    return(
      EmptyFilterState$new(
        x = x,
        varname = varname,
        varlabel = varlabel,
        input_dataname = input_dataname,
        extract_type = extract_type
      )
    )
  }
  UseMethod("init_filter_state")
}

#' @keywords internal
#' @export
init_filter_state.default <- function(x,
                                      varname,
                                      varlabel = attr(x, "label"),
                                      input_dataname = NULL,
                                      extract_type = character(0)) {
  if (is.null(varlabel)) varlabel <- character(0)
  FilterState$new(
    x = x,
    varname = varname,
    varlabel = varlabel,
    input_dataname = input_dataname,
    extract_type = extract_type
  )
}

#' @keywords internal
#' @export
init_filter_state.logical <- function(x,
                                      varname,
                                      varlabel = attr(x, "label"),
                                      input_dataname = NULL,
                                      extract_type = character(0)) {
  if (is.null(varlabel)) varlabel <- character(0)
  LogicalFilterState$new(
    x = x,
    varname = varname,
    varlabel = varlabel,
    input_dataname = input_dataname,
    extract_type = extract_type
  )
}

#' @keywords internal
#' @export
init_filter_state.numeric <- function(x,
                                      varname,
                                      varlabel = attr(x, "label"),
                                      input_dataname = NULL,
                                      extract_type = character(0)) {
  if (is.null(varlabel)) varlabel <- character(0)
  if (length(unique(x[!is.na(x)])) < getOption("teal.threshold_slider_vs_checkboxgroup")) {
    ChoicesFilterState$new(
      x = x,
      varname = varname,
      varlabel = varlabel,
      input_dataname = input_dataname,
      extract_type = extract_type
    )
  } else {
    RangeFilterState$new(
      x = x,
      varname = varname,
      varlabel = varlabel,
      input_dataname = input_dataname,
      extract_type = extract_type
    )
  }
}

#' @keywords internal
#' @export
init_filter_state.factor <- function(x,
                                     varname,
                                     varlabel = attr(x, "label"),
                                     input_dataname = NULL,
                                     extract_type = character(0)) {
  if (is.null(varlabel)) varlabel <- character(0)
  ChoicesFilterState$new(
    x = x,
    varname = varname,
    varlabel = varlabel,
    input_dataname = input_dataname,
    extract_type = extract_type
  )
}

#' @keywords internal
#' @export
init_filter_state.character <- function(x,
                                        varname,
                                        varlabel = attr(x, "label"),
                                        input_dataname = NULL,
                                        extract_type = character(0)) {
  if (is.null(varlabel)) varlabel <- character(0)
  ChoicesFilterState$new(
    x = x,
    varname = varname,
    varlabel = varlabel,
    input_dataname = input_dataname,
    extract_type = extract_type
  )
}

#' @keywords internal
#' @export
init_filter_state.Date <- function(x,
                                   varname,
                                   varlabel = attr(x, "label"),
                                   input_dataname = NULL,
                                   extract_type = character(0)) {
  if (is.null(varlabel)) varlabel <- character(0)
  DateFilterState$new(
    x = x,
    varname = varname,
    varlabel = varlabel,
    input_dataname = input_dataname,
    extract_type = extract_type
  )
}

#' @keywords internal
#' @export
init_filter_state.POSIXct <- function(x,
                                      varname,
                                      varlabel = attr(x, "label"),
                                      input_dataname = NULL,
                                      extract_type = character(0)) {
  if (is.null(varlabel)) varlabel <- character(0)
  DatetimeFilterState$new(
    x = x,
    varname = varname,
    varlabel = varlabel,
    input_dataname = input_dataname,
    extract_type = extract_type
  )
}

#' @keywords internal
#' @export
init_filter_state.POSIXlt <- function(x,
                                      varname,
                                      varlabel = attr(x, "label"),
                                      input_dataname = NULL,
                                      extract_type = character(0)) {
  if (is.null(varlabel)) varlabel <- character(0)
  DatetimeFilterState$new(
    x = x,
    varname = varname,
    varlabel = varlabel,
    input_dataname = input_dataname,
    extract_type = extract_type
  )
}

# FilterState ------
#' @name FilterState
#' @docType class
#'
#'
#' @title Abstract class to encapsulate filter states
#'
#' @details
#' This class is responsible for managing single filter item within
#' `FilteredData` class. Filter states depend on the variable type:
#' (`logical`, `integer`, `numeric`, `factor`, `character`, `Date`, `POSIXct`, `POSIXlt`)
#' and returns `FilterState` object with class corresponding to input variable.
#' Class controls single filter entry in `module_single_filter_item` and returns
#' code relevant to selected values.
#' - `factor`, `character`: `class = ChoicesFilterState`
#' - `numeric`: `class = RangeFilterState`
#' - `logical`: `class = LogicalFilterState`
#' - `Date`: `class = DateFilterState`
#' - `POSIXct`, `POSIXlt`: `class = DatetimeFilterState`
#' - all `NA` entries: `class: FilterState`, cannot be filtered
#' - default: `FilterState`, cannot be filtered
#' \cr
#' Each variable's filter state is an `R6` object which contains `choices`,
#' `selected`, `varname`, `dataname`, `labels`, `na_count`, `keep_na` and other
#' variable type specific fields (`keep_inf`, `inf_count`, `timezone`).
#' Object contains also shiny module (`ui` and `server`) which manages
#' state of the filter through reactive values `selected`, `keep_na`, `keep_inf`
#' which trigger `get_call()` and every R function call up in reactive
#' chain.
#' \cr
#' \cr
#' @section Modifying state:
#' Modifying a `FilterState` object is possible in three scenarios depicted below:
#' \if{html}{\figure{filter_state_reactivity.jpg}{options: width="100\%" alt="Figure: filter_state_reactivity.jpg"}}
#' \if{latex}{\figure{filter_state_reactivity.jpg}{options: width=7cm}}
#' * In the interactive session by directly specifying values of `selected`,
#'   `keep_na` or `keep_inf` using `set_state` method (to update all at once),
#'   or using `set_selected`, `set_keep_na` or `set_keep_inf`
#' * In a `teal` application by changing appropriate inputs
#' * Using methods `set_selected_reactive`, `set_keep_na_reactive`,
#'  `set_keep_inf_reactive` which serves as a programmatic API.
#'
#' @keywords internal
FilterState <- R6::R6Class( # nolint
  "FilterState",
  public = list(
    #' @description
    #' Initialize a `FilterState` object
    #' @param x (`vector`)\cr
    #'   values of the variable used in filter
    #' @param varname (`character`, `name`)\cr
    #'   name of the variable
    #' @param varlabel (`character(1)`)\cr
    #'   label of the variable (optional).
    #' @param input_dataname (`name` or `call`)\cr
    #'   name of dataset where `x` is taken from. Must be specified if `extract_type` argument
    #'   is not empty.
    #' @param extract_type (`character(0)`, `character(1)`)\cr
    #' whether condition calls should be prefixed by dataname. Possible values:
    #' \itemize{
    #' \item{`character(0)` (default)}{ `varname` in the condition call will not be prefixed}
    #' \item{`"list"`}{ `varname` in the condition call will be returned as `<input_dataname>$<varname>`}
    #' \item{`"matrix"`}{ `varname` in the condition call will be returned as `<input_dataname>[, <varname>]`}
    #' }
    initialize = function(x,
                          varname,
                          varlabel = character(0),
                          input_dataname = NULL,
                          extract_type = character(0)) {
      checkmate::assert(
        checkmate::check_class(varname, "name"),
        checkmate::check_class(varname, "call"),
        checkmate::check_string(varname)
      )
      checkmate::assert_character(varlabel, max.len = 1, any.missing = FALSE)
      stopifnot(is.null(input_dataname) || is.name(input_dataname) || is.call(input_dataname))
      checkmate::assert_character(extract_type, max.len = 1, any.missing = FALSE)
      stopifnot(
        length(extract_type) == 0 ||
          length(extract_type) == 1 && !is.null(input_dataname)
      )
      stopifnot(extract_type %in% c("list", "matrix"))
      private$input_dataname <- input_dataname
      private$varname <- if (is.character(varname)) {
        as.name(varname)
      } else {
        varname
      }
      private$varlabel <- if (identical(varlabel, as.character(varname))) {
        # to not display duplicated label
        character(0)
      } else {
        varlabel
      }
      private$extract_type <- extract_type
      private$selected <- reactiveVal(NULL)
      private$selected_reactive <- reactiveVal(NULL)
      private$na_count <- sum(is.na(x))
      private$keep_na <- reactiveVal(FALSE)
      private$keep_na_reactive <- reactiveVal(FALSE)

      logger::log_trace(
        sprintf(
          "Instantiated %s with variable %s, dataname: %s",
          class(self)[1],
          deparse1(varname),
          deparse1(private$input_dataname)
        )
      )
      invisible(self)
    },

    #' @description
    #' Destroy observers stored in `private$observers`.
    destroy_observers = function() {
      lapply(private$observers, function(x) x$destroy())
      return(invisible(NULL))
    },

    #' @description
    #' Returns a formatted string representing this `FilterState`.
    #'
    #' @param indent (`numeric(1)`) the number of spaces before after each new line character of the formatted string.
    #' Default: 0
    #' @return `character(1)` the formatted string
    #'
    format = function(indent = 0) {
      checkmate::assert_number(indent, finite = TRUE, lower = 0)

      sprintf(
        "%sFiltering on: %s\n%1$s  Selected values: %s\n%1$s  Include missing values: %s",
        format("", width = indent),
        self$get_varname(deparse = TRUE),
        paste0(format(self$get_selected(), nsmall = 3), collapse = " "),
        format(self$get_keep_na())
      )
    },

    #' @description
    #' Returns reproducible condition call for current selection relevant
    #' for selected variable type.
    #' Method is using internal reactive values which makes it reactive
    #' and must be executed in reactive or isolated context.
    get_call = function() {
      NULL
    },

    #' @description
    #' Returns dataname
    #' @param deparse (`logical(1)`)\cr
    #' whether dataname should be deparsed. `TRUE` by default
    #' @return (`name` or `character(1)`)
    get_dataname = function(deparse = TRUE) {
      if (isTRUE(deparse)) {
        deparse1(private$input_dataname)
      } else {
        private$input_dataname
      }
    },

    #' @description
    #' Returns current `keep_na` selection
    #' @return (`logical(1)`)
    get_keep_na = function() {
      private$keep_na()
    },

    #' @description
    #' Returns variable label
    #' @return (`character(1)`)
    get_varlabel = function() {
      private$varlabel
    },

    #' @description
    #' Get variable name
    #' @param deparse (`logical(1)`)\cr
    #' whether variable name should be deparsed. `FALSE` by default
    #' @return (`name` or `character(1)`)
    get_varname = function(deparse = FALSE) {
      if (isTRUE(deparse)) {
        deparse1(private$varname)
      } else {
        private$varname
      }
    },

    #' @description
    #' Get selected values from `FilterState`
    #'
    #' @return class of the returned object depends of class of the `FilterState`
    get_selected = function() {
      private$selected()
    },

    #' @description
    #' Returns the filtering state.
    #'
    #' @return `list` containing values taken from the reactive fields:
    #' * `selected` (`atomic`) length depends on a `FilterState` variant.
    #' * `keep_na` (`logical(1)`) whether `NA` should be kept.
    get_state = function() {
      list(
        selected = self$get_selected(),
        keep_na = self$get_keep_na()
      )
    },

    #' @description
    #' Prints this `FilterState` object
    #'
    #' @param ... additional arguments to this method
    print = function(...) {
      cat(shiny::isolate(self$format()), "\n")
    },

    #' @description
    #' Set if `NA` should be kept
    #' @param value (`logical(1)`)\cr
    #'  value(s) which come from the filter selection. Value is set in `server`
    #'  modules after selecting check-box-input in the shiny interface. Values are set to
    #'  `private$keep_na` which is reactive.
    set_keep_na = function(value) {
      checkmate::assert_flag(value)
      private$keep_na(value)
      logger::log_trace(
        sprintf(
          "%s$set_keep_na set for variable %s to %s.",
          class(self)[1],
          deparse1(self$get_varname()),
          value
        )
      )
      invisible(NULL)
    },

    #' @description
    #' Set if `NA` should be kept when using `set_filter_state`
    #' @param value (`logical(1)`)\cr
    #'  value(s) which come from the filter selection. Value is set in `server`
    #'  modules when using `set_filter_state` instead of the shiny interface. Values are set to
    #'  `private$keep_na_reactive` which is reactive.
    set_keep_na_reactive = function(value) {
      checkmate::assert_flag(value)
      private$keep_na_reactive(value)
      sprintf(
        "%s$set_keep_na_reactive set for variable %s to %s.",
        class(self)[1],
        deparse1(self$get_varname()),
        value
      )
      invisible(NULL)
    },

    #' @description
    #' Some methods needs additional `!is.na(varame)` condition to not include
    #' missing values. When `private$na_rm = TRUE` is set, `self$get_call` returns
    #' condition extended by `!is.na` condition.
    #' @param value (`logical(1)`) when `TRUE`, `FilterState$get_call` appends an expression
    #'  removing `NA` values to the filter expression returned by `get_call`
    set_na_rm = function(value) {
      checkmate::assert_flag(value)
      private$na_rm <- value
      invisible(NULL)
    },

    #' @description
    #' Set selection
    #' @param value (`vector`)\cr
    #'  value(s) which come from the filter selection. Values are set in `server`
    #'  module after choosing value in app interface. Values are set to
    #'  `private$selected` which is reactive. Values type have to be the
    #'  same as `private$choices`.
    set_selected = function(value) {
      logger::log_trace(
        sprintf(
          "%s$set_selected setting selection of variable %s, dataname: %s.",
          class(self)[1],
          deparse1(self$get_varname()),
          deparse1(private$input_dataname)
        )
      )
      value <- private$cast_and_validate(value)
      value <- private$remove_out_of_bound_values(value)
      private$validate_selection(value)
      private$selected(value)
      logger::log_trace(sprintf(
        "%s$set_selected selection of variable %s set, dataname: %s",
        class(self)[1],
        deparse1(self$get_varname()),
        deparse1(private$input_dataname)
      ))
      invisible(NULL)
    },

    #' @description
    #' Set selection when using `set_filter_state`
    #' @param value (`vector`)\cr
    #'  value(s) which come from the filters set by the user. Values are set in `server`
    #'  modules after setting filters in `set_filter_state`. Values are set to
    #'  `private$set_selected_reactive` which is reactive. Values type have to be the
    #'  same as `private$choices`.
    set_selected_reactive = function(value) {
      logger::log_trace(
        sprintf(
          "%s$set_selected_reactive setting selection of variable %s, dataname: %s.",
          class(self)[1],
          deparse1(self$get_varname()),
          deparse1(private$input_dataname)
        )
      )

      value <- private$cast_and_validate(value)
      value <- private$remove_out_of_bound_values(value)
      private$validate_selection(value)
      private$selected_reactive(value)
      logger::log_trace(
        "{ class(self)[1] }$set_selected_reactive selection set, dataname: { deparse1(private$input_dataname) }"
      )
      invisible(NULL)
    },

    #' @description
    #' Set state
    #' @param state (`list`)\cr
    #'  contains fields relevant for a specific class
    #' \itemize{
    #' \item{`selected`}{ defines initial selection}
    #' \item{`keep_na` (`logical`)}{ defines whether to keep or remove `NA` values}
    #' }
    set_state = function(state) {
      logger::log_trace(sprintf(
        "%s$set_state, dataname: %s setting state of variable %s to: selected=%s, keep_na=%s",
        class(self)[1],
        deparse1(private$input_dataname),
        deparse1(self$get_varname()),
        paste(state$selected, collapse = " "),
        state$keep_na
      ))
      stopifnot(is.list(state) && all(names(state) %in% c("selected", "keep_na")))
      if (!is.null(state$keep_na)) {
        self$set_keep_na(state$keep_na)
      }
      if (!is.null(state$selected)) {
        self$set_selected(state$selected)
      }
      logger::log_trace(
        sprintf(
          "%s$set_state, dataname: %s done setting state for variable %s",
          class(self)[1],
          deparse1(private$input_dataname),
          deparse1(self$get_varname())
        )
      )
      invisible(NULL)
    },

    #' @description
    #' Set state when using `set_filter_state`
    #' @param state (`list`)\cr
    #'  contains fields relevant for a specific class
    #' \itemize{
    #' \item{`selected`}{ defines initial selection}
    #' \item{`keep_na` (`logical`)}{ defines whether to keep or remove `NA` values}
    #' }
    set_state_reactive = function(state) {
      logger::log_trace(
        sprintf(
          "%s$set_state_reactive, dataname: %s setting state of variable %s to: selected=%s, keep_na=%s",
          class(self)[1],
          deparse1(private$input_dataname),
          deparse1(self$get_varname()),
          paste(state$selected, collapse = " "),
          deparse1(state$keep_na)
        )
      )
      stopifnot(is.list(state) && all(names(state) %in% c("selected", "keep_na")))
      if (!is.null(state$keep_na)) {
        self$set_keep_na_reactive(state$keep_na)
      }
      if (!is.null(state$selected)) {
        self$set_selected_reactive(state$selected)
      }
      logger::log_trace(sprintf(
        "%s$set_state_reactive, dataname: %s done setting state for variable %s.",
        class(self)[1],
        deparse1(private$input_dataname),
        deparse1(self$get_varname())
      ))
      invisible(NULL)
    },

    #' @description
    #' Server module
    #' @param id (`character(1)`)\cr
    #'   an ID string that corresponds with the ID used to call the module's UI function.
    #' @return `moduleServer` function which returns `NULL`
    server = function(id) {
      moduleServer(
        id = id,
        function(input, output, session) {
          NULL
        }
      )
    },

    #' @description
    #' UI Module
    #' @param id (`character(1)`)\cr
    #'  id of shiny element. UI for this class contains simple message
    #'  informing that it's not supported
    ui = function(id) {
      span("Variable type is not supported in teal framework. Please remove this filter and continue")
    }
  ),
  private = list(
    choices = NULL, # because each class has different choices type
    input_dataname = character(0),
    keep_na = NULL, # reactiveVal logical()
    keep_na_reactive = NULL, # reactiveVal logical()
    na_count = integer(0),
    na_rm = FALSE, # it's logical(1)
    observers = NULL, # here observers are stored
    selected = NULL, # because it holds reactiveVal and each class has different choices type
    selected_reactive = NULL, # because it holds reactiveVal and each class has different choices type
    varname = character(0),
    varlabel = character(0),
    extract_type = logical(0),

    #' description
    #' Adds `is.na(varname)` before existing condition calls if `keep_na` is selected.
    #' Otherwise, if missings are found in the variable `!is.na` will be added
    #' only if `private$na_rm = TRUE`
    #' return (`call`)
    add_keep_na_call = function(filter_call) {
      if (isTRUE(self$get_keep_na())) {
        call(
          "|",
          call("is.na", private$get_varname_prefixed()),
          filter_call
        )
      } else if (isTRUE(private$na_rm) && private$na_count > 0) {
        call(
          "&",
          substitute(!is.na(var), list(var = private$get_varname_prefixed())),
          filter_call
        )
      } else {
        filter_call
      }
    },

    #' description
    #' Prefixed (or not) variable
    #'
    #' Return variable name needed to condition call.
    #' If `isTRUE(private$use_dataset)` variable is prefixed by
    #' dataname to be evaluated as extracted object, for example
    #' `data$var`
    #' return (`name` or `call`)
    get_varname_prefixed = function() {
      if (isTRUE(private$extract_type == "list")) {
        call_extract_list(private$input_dataname, private$varname)
      } else if (isTRUE(private$extract_type == "matrix")) {
        call_extract_matrix(dataname = private$input_dataname, column = as.character(private$varname))
      } else {
        private$varname
      }
    },

    #' Sets `keep_na` field according to observed `input$keep_na`
    #' If `keep_na = TRUE` `is.na(varname)` is added to the returned call.
    #' Otherwise returned call excludes `NA` when executed.
    observe_keep_na = function(input) {
      private$observers$keep_na <- observeEvent(
        ignoreNULL = FALSE, # ignoreNULL: we don't want to ignore NULL when nothing is selected in the `selectInput`,
        ignoreInit = TRUE, # ignoreInit: should not matter because we set the UI with the desired initial state
        eventExpr = input$keep_na,
        handlerExpr = {
          keep_na <- if (is.null(input$keep_na)) {
            FALSE
          } else {
            input$keep_na
          }
          self$set_keep_na(keep_na)
          logger::log_trace(
            sprintf(
              "%s$server keep_na of variable %s set to: %s, dataname: %s",
              class(self)[1],
              deparse1(self$get_varname()),
              deparse1(input$keep_na),
              deparse1(private$input_dataname)
            )
          )
        }
      )
      invisible(NULL)
    },

    #' Sets `keep_na` field according to `keep_na` value passed in `set_filter_state`.
    #' If `keep_na = TRUE` `is.na(varname)` is added to the returned call.
    #' Otherwise returned call excludes `NA` when executed.
    observe_keep_na_reactive = function(value) {
      private$observers$keep_na_reactive <- observeEvent(
        ignoreNULL = FALSE, # ignoreNULL: we don't want to ignore NULL when nothing is selected in the `selectInput`,
        ignoreInit = TRUE, # ignoreInit: should not matter because we set the UI with the desired initial state
        eventExpr = private$keep_na_reactive(),
        handlerExpr = {
          updateCheckboxInput(
            inputId = "keep_na",
            value = value
          )
          private$keep_na_reactive(NULL)
          logger::log_trace(
            sprintf(
              "%s$server keep_na of variable %s set to: %s, dataname: %s",
              class(self)[1],
              deparse1(self$get_varname()),
              deparse1(value),
              deparse1(private$input_dataname)
            )
          )
        }
      )
      invisible(NULL)
    },

    #' Set choices
    #'
    #' Set choices is supposed to be executed once in the constructor
    #' to define set/range which selection is made from.
    #' parameter choices (`vector`)\cr
    #'  class of the vector depends on the `FilterState` class.
    #' return a `NULL`
    set_choices = function(choices) {
      private$choices <- choices
      invisible(NULL)
    },

    # Checks if the selection is valid in terms of class and length.
    # It should not return anything but throw an error if selection
    # has a wrong class or is outside of possible choices
    validate_selection = function(value) {
      invisible(NULL)
    },

    # Filters out erroneous values from an array.
    #
    # @param values the array of values
    #
    # @return the array of values without elements, which are outside of
    # the accepted set for this FilterState
    remove_out_of_bound_values = function(values) {
      values
    },

    # Casts an array of values to the type fitting this `FilterState`
    # and validates the elements of the casted array
    # satisfy the requirements of this `FilterState`.
    #
    # @param values the array of values
    #
    # @return the casted array
    #
    # @note throws an error if the casting did not execute successfully.
    cast_and_validate = function(values) {
      values
    }
  )
)

# EmptyFilterState ---------
#' @name EmptyFilterState
#' @title `FilterState` object for empty variable
#' @docType class
#' @keywords internal
#'
#'
#' @examples
#' filter_state <- teal.slice:::EmptyFilterState$new(
#'   NA,
#'   varname = "x",
#'   input_dataname = as.name("data"),
#'   extract_type = character(0)
#' )
#' isolate(filter_state$get_call())
#' isolate(filter_state$set_selected(TRUE))
#' isolate(filter_state$set_keep_na(TRUE))
#' isolate(filter_state$get_call())
EmptyFilterState <- R6::R6Class( # nolint
  "EmptyFilterState",
  inherit = FilterState,
  public = list(

    #' @description
    #' Initialize `EmptyFilterState` object
    #' @param x (`vector`)\cr
    #'   values of the variable used in filter
    #' @param varname (`character`, `name`)\cr
    #'   name of the variable
    #' @param varlabel (`character(1)`)\cr
    #'   label of the variable (optional).
    #' @param input_dataname (`name` or `call`)\cr
    #'   name of dataset where `x` is taken from
    #' @param extract_type (`character(0)`, `character(1)`)\cr
    #' whether condition calls should be prefixed by dataname. Possible values:
    #' \itemize{
    #' \item{`character(0)` (default)}{ `varname` in the condition call will not be prefixed}
    #' \item{`"list"`}{ `varname` in the condition call will be returned as `<input_dataname>$<varname>`}
    #' \item{`"matrix"`}{ `varname` in the condition call will be returned as `<input_dataname>[, <varname>]`}
    #' }
    initialize = function(x,
                          varname,
                          varlabel = character(0),
                          input_dataname = NULL,
                          extract_type = character(0)) {
      super$initialize(x, varname, varlabel, input_dataname, extract_type)
      private$set_choices(list())
      self$set_selected(list())

      return(invisible(self))
    },

    #' @description
    #' Answers the question of whether the current settings and values selected actually filters out any values.
    #' @return logical scalar
    is_any_filtered = function() {
      if (isTRUE(self$get_keep_na())) {
        FALSE
      } else {
        TRUE
      }
    },

    #' @description
    #' Returns reproducible condition call for current selection relevant
    #' for selected variable type.
    #' Method is using internal reactive values which makes it reactive
    #' and must be executed in reactive or isolated context.
    get_call = function() {
      filter_call <- if (isTRUE(self$get_keep_na())) {
        call("is.na", private$get_varname_prefixed())
      } else {
        FALSE
      }
    },

    #' @description
    #' Returns the filtering state.
    #'
    #' @return `list` containing values taken from the reactive fields:
    #' * `keep_na` (`logical(1)`) whether `NA` should be kept.
    get_state = function() {
      list(
        keep_na = self$get_keep_na()
      )
    },

    #' @description
    #' UI Module for `EmptyFilterState`.
    #' This UI element contains checkbox input to
    #' filter or keep missing values.
    #' @param id (`character(1)`)\cr
    #'  id of shiny element
    ui = function(id) {
      ns <- NS(id)
      fluidRow(
        div(
          style = "position: relative;",
          div(
            span("Variable contains missing values only"),
            checkboxInput(
              ns("keep_na"),
              label_keep_na_count(private$na_count),
              value = FALSE
            )
          )
        )
      )
    },
    #' @description
    #' Controls selection of `keep_na` checkbox input
    #' @param id (`character(1)`)\cr
    #'   an ID string that corresponds with the ID used to call the module's UI function.
    #' @return `moduleServer` function which returns `NULL`
    server = function(id) {
      moduleServer(
        id = id,
        function(input, output, session) {
          private$observe_keep_na(input)
          shiny::setBookmarkExclude("keep_na")
        }
      )
    },

    #' @description
    #' Set state
    #' @param state (`list`)\cr
    #'  contains fields relevant for a specific class
    #' \itemize{
    #' \item{`keep_na` (`logical`)}{ defines whether to keep or remove `NA` values}
    #' }
    set_state = function(state) {
      if (!is.null(state$selected)) {
        stop(
          sprintf(
            "All values in variable '%s' are `NA`. Unable to apply filter values \n  %s",
            self$get_varname(deparse = TRUE),
            paste(state$selected, collapse = ", ")
          )
        )
      }
      stopifnot(is.list(state) && all(names(state) == "keep_na"))
      if (!is.null(state$keep_na)) {
        self$set_keep_na(state$keep_na)
      }
      invisible(NULL)
    }
  )
)

# LogicalFilterState ---------
#' @name LogicalFilterState
#' @title `FilterState` object for logical variable
#' @docType class
#' @keywords internal
#'
#'
#' @examples
#' filter_state <- teal.slice:::LogicalFilterState$new(
#'   sample(c(TRUE, FALSE, NA), 10, replace = TRUE),
#'   varname = "x",
#'   input_dataname = as.name("data"),
#'   extract_type = character(0)
#' )
#' isolate(filter_state$get_call())
#'
#' isolate(filter_state$set_selected(TRUE))
#' isolate(filter_state$set_keep_na(TRUE))
#' isolate(filter_state$get_call())
LogicalFilterState <- R6::R6Class( # nolint
  "LogicalFilterState",
  inherit = FilterState,
  public = list(

    #' @description
    #' Initialize a `FilterState` object
    #' @param x (`logical`)\cr
    #'   values of the variable used in filter
    #' @param varname (`character`, `name`)\cr
    #'   label of the variable (optional).
    #' @param varlabel (`character(1)`)\cr
    #'   label of the variable (optional).
    #' @param input_dataname (`name` or `call`)\cr
    #'   name of dataset where `x` is taken from
    #' @param extract_type (`character(0)`, `character(1)`)\cr
    #' whether condition calls should be prefixed by dataname. Possible values:
    #' \itemize{
    #' \item{`character(0)` (default)}{ `varname` in the condition call will not be prefixed}
    #' \item{`"list"`}{ `varname` in the condition call will be returned as `<input_dataname>$<varname>`}
    #' \item{`"matrix"`}{ `varname` in the condition call will be returned as `<input_dataname>[, <varname>]`}
    #' }
    initialize = function(x,
                          varname,
                          varlabel = character(0),
                          input_dataname = NULL,
                          extract_type = character(0)) {
      stopifnot(is.logical(x))
      super$initialize(x, varname, varlabel, input_dataname, extract_type)
      df <- as.factor(x)
      if (length(levels(df)) != 2) {
        if (levels(df) %in% c(TRUE, FALSE)) {
          choices_not_included <- c(TRUE, FALSE)[!c(TRUE, FALSE) %in% levels(df)]
          levels(df) <- c(levels(df), choices_not_included)
        }
      }

      tbl <- table(df)

      choices <- as.logical(names(tbl))
      names(choices) <- sprintf("%s (%s)", choices, tbl)
      private$set_choices(as.list(choices))
      self$set_selected(unname(choices)[1])
      private$histogram_data <- data.frame(
        x = names(choices),
        y = as.vector(tbl)
      )

      invisible(self)
    },

    #' @description
    #' Answers the question of whether the current settings and values selected actually filters out any values.
    #' @return logical scalar
    is_any_filtered = function() {
      if (!isTRUE(self$get_keep_na()) && private$na_count > 0) {
        TRUE
      } else if (all(private$histogram_data$y > 0)) {
        TRUE
      } else if (self$get_selected() == FALSE && "FALSE (0)" %in% private$histogram_data$x) {
        TRUE
      } else if (self$get_selected() == TRUE && "TRUE (0)" %in% private$histogram_data$x) {
        TRUE
      } else {
        FALSE
      }
    },

    #' @description
    #' Returns reproducible condition call for current selection.
    #' For `LogicalFilterState` it's a `!<varname>` or `<varname>` and optionally
    #' `is.na(<varname>)`
    get_call = function() {
      filter_call <- call_condition_logical(
        varname = private$get_varname_prefixed(),
        choice = self$get_selected()
      )

      filter_call <- private$add_keep_na_call(filter_call)

      filter_call
    },

    #' @description
    #' UI Module for `EmptyFilterState`.
    #' This UI element contains available choices selection and
    #' checkbox whether to keep or not keep the `NA` values.
    #' @param id (`character(1)`)\cr
    #'  id of shiny element
    ui = function(id) {
      ns <- NS(id)
      fluidRow(
        div(
          style = "position: relative;",
          # same overlay as for choices with no more than (default: 5) elements
          div(
            class = "filterPlotOverlayBoxes",
            plotOutput(ns("plot"), height = "100%")
          ),
          radioButtons(
            ns("selection"),
            label = NULL,
            choices = private$choices,
            selected = isolate(self$get_selected()),
            width = "100%"
          )
        ),
        if (private$na_count > 0) {
          checkboxInput(
            ns("keep_na"),
            label_keep_na_count(private$na_count),
            value = isolate(self$get_keep_na())
          )
        } else {
          NULL
        }
      )
    },

    #' @description
    #' Server module
    #'
    #' @param id (`character(1)`)\cr
    #'   an ID string that corresponds with the ID used to call the module's UI function.
    #' @return `moduleServer` function which returns `NULL`
    server = function(id) {
      moduleServer(
        id = id,
        function(input, output, session) {
          logger::log_trace("LogicalFilterState$server initializing, dataname: { deparse1(private$input_dataname) }")

          shiny::setBookmarkExclude(c("selection", "keep_na"))

          output$plot <- renderPlot(
            bg = "transparent",
            expr = {
              data <- private$histogram_data
              data$y <- rev(data$y / sum(data$y)) # we have to reverse because the histogram is turned by 90 degrees
              data$x <- seq_len(nrow(data)) # to prevent ggplot reordering columns using the characters in x column
              ggplot2::ggplot(data) +
                # sort factor so that it reflects checkbox order
                ggplot2::aes_string(x = "x", y = "y") +
                ggplot2::geom_col(
                  width = 0.95,
                  fill = grDevices::rgb(66 / 255, 139 / 255, 202 / 255),
                  color = NA,
                  alpha = 0.2
                ) +
                ggplot2::coord_flip() +
                ggplot2::theme_void() +
                ggplot2::scale_x_discrete(expand = c(0, 0)) +
                ggplot2::scale_y_continuous(expand = c(0, 0), limits = c(0, 1))
            }
          )

          private$observers$selection_reactive <- observeEvent(
            private$selected_reactive(),
            ignoreNULL = TRUE,
            handlerExpr = {
              updateRadioButtons(
                session = session,
                inputId = "selection",
                selected =  private$selected_reactive()
              )
              logger::log_trace(sprintf(
                "LogicalFilterState$server@1 selection of variable %s changed, dataname: %s",
                deparse1(self$get_varname()),
                deparse1(private$input_dataname)
              ))
              private$selected_reactive(NULL)
            }
          )
          private$observe_keep_na_reactive(private$keep_na_reactive())

          private$observers$selection <- observeEvent(
            ignoreNULL = FALSE,
            ignoreInit = TRUE,
            eventExpr = input$selection,
            handlerExpr = {
              selection_state <- as.logical(input$selection)
              if (is.null(selection_state)) {
                selection_state <- logical(0)
              }
              self$set_selected(selection_state)
              logger::log_trace(
                sprintf(
                  "LogicalFilterState$server@2 selection of variable %s changed, dataname: %s",
                  deparse1(self$get_varname()),
                  deparse1(private$input_dataname)
                )
              )
            }
          )

          private$observe_keep_na(input)

          logger::log_trace("LogicalFilterState$server initialized, dataname: { deparse1(private$input_dataname) }")
          NULL
        }
      )
    },

    #' @description
    #' Sets the selected values of this `LogicalFilterState`.
    #'
    #' @param value (`logical(1)`)\cr
    #'  the value to set. Must not contain the NA value.
    #'
    #' @returns invisibly `NULL`.
    #'
    #' @note Casts the passed object to `logical` before validating the input
    #' making it possible to pass any object coercible to `logical` to this method.
    #'
    #' @examples
    #' filter <- teal.slice:::LogicalFilterState$new(c(TRUE), varname = "name")
    #' filter$set_selected(TRUE)
    set_selected = function(value) {
      super$set_selected(value)
    }
  ),
  private = list(
    histogram_data = data.frame(),
    validate_selection = function(value) {
      if (!(checkmate::test_logical(value, max.len = 1, any.missing = FALSE))) {
        stop(
          sprintf(
            "value of the selection for `%s` in `%s` should be a logical scalar (TRUE or FALSE)",
            self$get_varname(deparse = TRUE),
            self$get_dataname(deparse = TRUE)
          )
        )
      }

      pre_msg <- sprintf(
        "dataset '%s', variable '%s': ",
        self$get_dataname(deparse = TRUE),
        self$get_varname(deparse = TRUE)
      )
      check_in_subset(value, private$choices, pre_msg = pre_msg)
    },
    cast_and_validate = function(values) {
      tryCatch(
        expr = {
          values_logical <- as.logical(values)
          if (any(is.na(values_logical))) stop()
        },
        error = function(cond) stop("The array of set values must contain values coercible to logical.")
      )
      values_logical
    }
  )
)

# RangeFilterState ---------
#' @name RangeFilterState
#' @title `FilterState` object for numeric variable
#' @docType class
#' @keywords internal
#'
#'
#' @examples
#' filter_state <- teal.slice:::RangeFilterState$new(
#'   c(NA, Inf, seq(1:10)),
#'   varname = "x",
#'   input_dataname = as.name("data"),
#'   extract_type = character(0)
#' )
#' isolate(filter_state$get_call())
#' isolate(filter_state$set_selected(c(3L, 8L)))
#' isolate(filter_state$set_keep_na(TRUE))
#' isolate(filter_state$set_keep_inf(TRUE))
#' isolate(filter_state$get_call())
RangeFilterState <- R6::R6Class( # nolint
  "RangeFilterState",
  inherit = FilterState,
  public = list(

    #' @description
    #' Initialize a `FilterState` object
    #' @param x (`numeric`)\cr
    #'   values of the variable used in filter
    #' @param varname (`character`, `name`)\cr
    #'   name of the variable
    #' @param varlabel (`character(1)`)\cr
    #'   label of the variable (optional).
    #' @param input_dataname (`name` or `call`)\cr
    #'   name of dataset where `x` is taken from
    #' @param extract_type (`character(0)`, `character(1)`)\cr
    #' whether condition calls should be prefixed by dataname. Possible values:
    #' \itemize{
    #' \item{`character(0)` (default)}{ `varname` in the condition call will not be prefixed}
    #' \item{`"list"`}{ `varname` in the condition call will be returned as `<input_dataname>$<varname>`}
    #' \item{`"matrix"`}{ `varname` in the condition call will be returned as `<input_dataname>[, <varname>]`}
    #' }
    initialize = function(x,
                          varname,
                          varlabel = character(0),
                          input_dataname = NULL,
                          extract_type = character(0)) {
      stopifnot(is.numeric(x))
      stopifnot(any(is.finite(x)))

      super$initialize(x, varname, varlabel, input_dataname, extract_type)
      var_range <- range(x, finite = TRUE)

      private$set_choices(var_range)
      self$set_selected(var_range)

      private$histogram_data <- if (sum(is.finite(x)) >= 2) {
        as.data.frame(
          stats::density(x, na.rm = TRUE, n = 100)[c("x", "y")] # 100 bins only
        )
      } else {
        data.frame(x = NA_real_, y = NA_real_)
      }
      private$inf_count <- sum(is.infinite(x))
      private$is_integer <- is.integer(x)
      private$keep_inf <- reactiveVal(FALSE)
      private$keep_inf_reactive <- reactiveVal(FALSE)

      return(invisible(self))
    },

    #' @description
    #' Returns a formatted string representing this `LogicalFilterState`.
    #'
    #' @param indent (`numeric(1)`) the number of spaces before after each new line character of the formatted string.
    #' Default: 0
    #' @return `character(1)` the formatted string
    #'
    format = function(indent = 0) {
      checkmate::assert_number(indent, finite = TRUE, lower = 0)

      sprintf(
        "%sFiltering on: %s\n%1$s  Selected range: %s - %s\n%1$s  Include missing values: %s",
        format("", width = indent),
        self$get_varname(deparse = TRUE),
        format(self$get_selected(), nsmall = 3)[1],
        format(self$get_selected(), nsmall = 3)[2],
        format(self$get_keep_na())
      )
    },

    #' @description
    #' Answers the question of whether the current settings and values selected actually filters out any values.
    #' @return logical scalar
    is_any_filtered = function() {
      if (!setequal(self$get_selected(), private$choices)) {
        TRUE
      } else if (!isTRUE(self$get_keep_inf()) && private$inf_count > 0) {
        TRUE
      } else if (!isTRUE(self$get_keep_na()) && private$na_count > 0) {
        TRUE
      } else {
        FALSE
      }
    },

    #' @description
    #' Returns reproducible condition call for current selection.
    #' For this class returned call looks like
    #' `<varname> >= <min value> & <varname> <= <max value>` with
    #' optional `is.na(<varname>)` and `is.finite(<varname>)`.
    #' @return (`call`)
    get_call = function() {
      filter_call <- call_condition_range(
        varname = private$get_varname_prefixed(),
        range = self$get_selected()
      )

      filter_call <- private$add_keep_inf_call(filter_call)
      filter_call <- private$add_keep_na_call(filter_call)

      filter_call
    },

    #' @description
    #' Returns current `keep_inf` selection
    #' @return (`logical(1)`)
    get_keep_inf = function() {
      private$keep_inf()
    },

    #' @description
    #' Returns the filtering state.
    #'
    #' @return `list` containing values taken from the reactive fields:
    #' * `selected` (`numeric(2)`) range of the filter.
    #' * `keep_na` (`logical(1)`) whether `NA` should be kept.
    #' * `keep_inf` (`logical(1)`)  whether `Inf` should be kept.
    get_state = function() {
      list(
        selected = self$get_selected(),
        keep_na = self$get_keep_na(),
        keep_inf = self$get_keep_inf()
      )
    },

    #' UI Module for `RangeFilterState`.
    #' This UI element contains two values for `min` and `max`
    #' of the range and two checkboxes whether to keep the `NA` or `Inf`  values.
    #' @param id (`character(1)`)\cr
    #'  id of shiny element
    ui = function(id) {
      ns <- NS(id)
      pretty_range_inputs <- private$get_pretty_range_inputs(private$choices)
      fluidRow(
        div(
          class = "filterPlotOverlayRange",
          plotOutput(ns("plot"), height = "100%")
        ),
        teal.widgets::optionalSliderInput(
          inputId = ns("selection"),
          label = NULL,
          min = pretty_range_inputs["min"],
          max = pretty_range_inputs["max"],
          # on filter init without predefined value select "pretty" (wider) range
          value = isolate({
            if (identical(private$choices, self$get_selected())) {
              pretty_range_inputs[c("min", "max")]
            } else {
              self$get_selected()
            }
          }),
          width = "100%",
          step = pretty_range_inputs["step"]
        ),
        if (private$inf_count > 0) {
          checkboxInput(
            ns("keep_inf"),
            sprintf("Keep Inf (%s)", private$inf_count),
            value = isolate(self$get_keep_inf())
          )
        } else {
          NULL
        },
        if (private$na_count > 0) {
          checkboxInput(
            ns("keep_na"),
            label_keep_na_count(private$na_count),
            value = isolate(self$get_keep_inf())
          )
        } else {
          NULL
        }
      )
    },

    #' @description
    #' Server module
    #' @param id (`character(1)`)\cr
    #'   an ID string that corresponds with the ID used to call the module's UI function.
    #' @return `moduleServer` function which returns `NULL`
    server = function(id) {
      moduleServer(
        id = id,
        function(input, output, session) {
          logger::log_trace("RangeFilterState$server initializing, dataname: { deparse1(private$input_dataname) }")

          shiny::setBookmarkExclude(c("selection", "keep_na", "keep_inf"))

          output$plot <- renderPlot(
            bg = "transparent",
            height = 25,
            expr = {
              ggplot2::ggplot(private$histogram_data) +
                ggplot2::aes_string(x = "x", y = "y") +
                ggplot2::geom_area(
                  fill = grDevices::rgb(66 / 255, 139 / 255, 202 / 255),
                  color = NA,
                  alpha = 0.2
                ) +
                ggplot2::theme_void() +
                ggplot2::scale_y_continuous(expand = c(0, 0)) +
                ggplot2::scale_x_continuous(expand = c(0, 0))
            }
          )

          private$observers$selection_reactive <- observeEvent(
            private$selected_reactive(),
            ignoreNULL = TRUE,
            handlerExpr = {
              updateSliderInput(
                session = session,
                inputId = "selection",
                value = private$selected_reactive()
              )
              private$selected_reactive(NULL)
              logger::log_trace(sprintf(
                "RangeFilterState$server@1 selection of variable %s changed, dataname: %s",
                deparse1(self$get_varname()),
                deparse1(private$input_dataname)
              ))
            }
          )
          private$observe_keep_na_reactive(private$keep_na_reactive())

          private$observers$keep_inf_reactive <- observeEvent(
            private$keep_inf_reactive(),
            ignoreNULL = TRUE,
            handlerExpr = {
              updateCheckboxInput(
                session = session,
                inputId = "keep_inf",
                value =  private$keep_inf_reactive()
              )
              logger::log_trace(sprintf(
                "RangeFilterState$server@2 keep_inf of variable %s set to: %s, dataname: %s",
                deparse1(self$get_varname()),
                private$keep_inf_reactive(),
                deparse1(private$input_dataname)
              ))
              private$keep_inf_reactive(NULL)
            }
          )

          private$observers$selection <- observeEvent(
            ignoreNULL = FALSE, # ignoreNULL: we don't want to ignore NULL when nothing is selected in `selectInput`,
            ignoreInit = TRUE, # ignoreInit: should not matter because we set the UI with the desired initial state
            eventExpr = input$selection,
            handlerExpr = {
              # because we extended real range into rounded one we need to apply intersect(range_input, range_real)
              selection_state <- as.numeric(pmax(pmin(input$selection, private$choices[2]), private$choices[1]))
              if (!setequal(selection_state, self$get_selected())) {
                validate(
                  need(
                    input$selection[1] <= input$selection[2],
                    "Left range boundary should be lower than right"
                  )
                )
                self$set_selected(selection_state)
              }
              logger::log_trace(
                sprintf(
                  "RangeFilterState$server@3 selection of variable %s changed, dataname: %s",
                  deparse1(self$get_varname()),
                  deparse1(private$input_dataname)
                )
              )
            }
          )

          private$observe_keep_na(input)

          private$observers$keep_inf <- observeEvent(
            ignoreNULL = FALSE, # ignoreNULL: we don't want to ignore NULL when nothing is selected in the `selectInput`
            ignoreInit = TRUE, # ignoreInit: should not matter because we set the UI with the desired initial state
            eventExpr = input$keep_inf,
            handlerExpr = {
              keep_inf <- if (is.null(input$keep_inf)) FALSE else input$keep_inf
              self$set_keep_inf(keep_inf)
              logger::log_trace(
                sprintf(
                  "RangeFilterState$server@4 keep_inf of variable %s set to: %s, dataname: %s",
                  deparse1(self$get_varname()),
                  deparse1(input$keep_inf),
                  deparse1(private$input_dataname)
                )
              )
            }
          )
          logger::log_trace("RangeFilterState$server initialized, dataname: { deparse1(private$input_dataname) }")
          NULL
        }
      )
    },

    #' @description
    #' Set if `Inf` should be kept
    #' @param value (`logical(1)`)\cr
    #'  Value(s) which come from the filter selection. Value is set in `server`
    #'  modules after selecting check-box-input in the shiny interface. Values are set to
    #'  `private$keep_inf` which is reactive.
    set_keep_inf = function(value) {
      checkmate::assert_flag(value)
      private$keep_inf(value)
      logger::log_trace(
        sprintf(
          "%s$set_keep_inf of variable %s set to %s, dataname: %s.",
          class(self)[1],
          deparse1(self$get_varname()),
          value,
          deparse1(private$input_dataname)
        )
      )
    },

    #' @description
    #' Set if `Inf` should be kept when passing filters using `set_filter_state`
    #' @param value (`logical(1)`)\cr
    #'  Value(s) which come from the filter set by the user. Value is set in `server`
    #'  modules after setting the filters using `set_filter_state`. Values are set to
    #'  `private$keep_inf_reactive` which is reactive.
    set_keep_inf_reactive = function(value) {
      checkmate::assert_flag(value)
      private$keep_inf_reactive(value)
      logger::log_trace(
        sprintf(
          "%s$set_keep_inf_reactive of variable %s set to %s, dataname: %s.",
          class(self)[1],
          deparse1(self$get_varname()),
          value,
          deparse1(private$input_dataname)
        )
      )
    },

    #' @description
    #' Set state
    #' @param state (`list`)\cr
    #'  contains fields relevant for a specific class
    #' \itemize{
    #' \item{`selected`}{ defines initial selection}
    #' \item{`keep_na` (`logical`)}{ defines whether to keep or remove `NA` values}
    #' \item{`keep_inf` (`logical`)}{ defines whether to keep or remove `Inf` values}
    #' }
    set_state = function(state) {
      stopifnot(is.list(state) && all(names(state) %in% c("selected", "keep_na", "keep_inf")))
      if (!is.null(state$keep_inf)) {
        self$set_keep_inf(state$keep_inf)
      }
      super$set_state(state[names(state) %in% c("selected", "keep_na")])
      invisible(NULL)
    },

    #' @description
    #' Set state when using `set_filter_state`
    #' @param state (`list`)\cr
    #'  contains fields relevant for a specific class
    #' \itemize{
    #' \item{`selected`}{ defines initial selection}
    #' \item{`keep_na` (`logical`)}{ defines whether to keep or remove `NA` values}
    #' \item{`keep_inf` (`logical`)}{ defines whether to keep or remove `Inf` values}
    #' }
    set_state_reactive = function(state) {
      stopifnot(is.list(state) && all(names(state) %in% c("selected", "keep_na", "keep_inf")))
      if (!is.null(state$keep_inf)) {
        self$set_keep_inf_reactive(state$keep_inf)
      }
      super$set_state_reactive(state[names(state) %in% c("selected", "keep_na")])
      invisible(NULL)
    },

    #' @description
    #' Sets the selected values of this `RangeFilterState`.
    #'
    #' @param value (`numeric(2)`) the two-elements array of the lower and upper bound
    #'   of the selected range. Must not contain NA values.
    #'
    #' @returns invisibly `NULL`
    #'
    #' @note Casts the passed object to `numeric` before validating the input
    #' making it possible to pass any object coercible to `numeric` to this method.
    #'
    #' @examples
    #' filter <- teal.slice:::RangeFilterState$new(c(1, 2, 3, 4), varname = "name")
    #' filter$set_selected(c(2, 3))
    #'
    set_selected = function(value) {
      super$set_selected(value)
    }
  ),
  private = list(
    histogram_data = data.frame(),
    keep_inf = NULL, # because it holds reactiveVal
    keep_inf_reactive = NULL, # because it holds reactiveVal
    inf_count = integer(0),
    is_integer = logical(0),

    # Adds is.infinite(varname) before existing condition calls if keep_inf is selected
    # returns a call
    add_keep_inf_call = function(filter_call) {
      if (isTRUE(self$get_keep_inf())) {
        call(
          "|",
          call("is.infinite", private$get_varname_prefixed()),
          filter_call
        )
      } else {
        filter_call
      }
    },

    # @description
    # formats range to pretty numbers to reduce decimal precision
    # @param values (numeric) initial range to be formatted
    # @return numeric(3) with names min, max, step - relevant for sliderInput
    get_pretty_range_inputs = function(values) {
      v_pretty_range <- pretty(values, n = 100)
      c(
        min = v_pretty_range[1],
        max = v_pretty_range[length(v_pretty_range)],
        step = `if`(private$is_integer, 1L, v_pretty_range[2] - v_pretty_range[1])
      )
    },
    validate_selection = function(value) {
      if (!is.numeric(value)) {
        stop(
          sprintf(
            "value of the selection for `%s` in `%s` should be a numeric",
            self$get_varname(deparse = TRUE),
            self$get_dataname(deparse = TRUE)
          )
        )
      }
      pre_msg <- sprintf(
        "data '%s', variable '%s': ",
        self$get_dataname(deparse = TRUE),
        self$get_varname(deparse = TRUE)
      )
      check_in_range(value, private$choices, pre_msg = pre_msg)
    },
    cast_and_validate = function(values) {
      tryCatch(
        expr = {
          values <- as.numeric(values)
          if (any(is.na(values))) stop()
        },
        error = function(error) stop("The array of set values must contain values coercible to numeric.")
      )
      if (length(values) != 2) stop("The array of set values must have length two.")
      values
    },
    remove_out_of_bound_values = function(values) {
      if (values[1] < private$choices[1]) {
        warning(paste(
          "Value:", values[1], "is outside of the possible range for column", private$varname,
          "of dataset", private$input_dataname, "."
        ))
        values[1] <- private$choices[1]
      }

      if (values[2] > private$choices[2]) {
        warning(paste(
          "Value:", values[2], "is outside of the possible range for column", private$varname,
          "of dataset", private$input_dataname, "."
        ))
        values[2] <- private$choices[2]
      }
      values
    }
  )
)

# ChoicesFilterState --------
#' @name ChoicesFilterState
#' @title `FilterState` object for factor or character variable
#' @docType class
#' @keywords internal
#'
#'
#' @examples
#' filter_state <- teal.slice:::ChoicesFilterState$new(
#'   c(LETTERS, NA),
#'   varname = "x",
#'   input_dataname = as.name("data"),
#'   extract_type = character(0)
#' )
#' isolate(filter_state$get_call())
#' isolate(filter_state$set_selected("B"))
#' isolate(filter_state$set_keep_na(TRUE))
#' isolate(filter_state$get_call())
ChoicesFilterState <- R6::R6Class( # nolint
  "ChoicesFilterState",
  inherit = FilterState,
  public = list(

    #' @description
    #' Initialize a `FilterState` object
    #' @param x (`character` or `factor`)\cr
    #'   values of the variable used in filter
    #' @param varname (`character`, `name`)\cr
    #'   name of the variable
    #' @param varlabel (`character(1)`)\cr
    #'   label of the variable (optional).
    #' @param input_dataname (`name` or `call`)\cr
    #'   name of dataset where `x` is taken from
    #' @param extract_type (`character(0)`, `character(1)`)\cr
    #' whether condition calls should be prefixed by dataname. Possible values:
    #' \itemize{
    #' \item{`character(0)` (default)}{ `varname` in the condition call will not be prefixed}
    #' \item{`"list"`}{ `varname` in the condition call will be returned as `<input_dataname>$<varname>`}
    #' \item{`"matrix"`}{ `varname` in the condition call will be returned as `<input_dataname>[, <varname>]`}
    #' }
    initialize = function(x,
                          varname,
                          varlabel = character(0),
                          input_dataname = NULL,
                          extract_type = character(0)) {
      stopifnot(
        is.character(x) ||
          is.factor(x) ||
          (length(unique(x[!is.na(x)])) < getOption("teal.threshold_slider_vs_checkboxgroup"))
      )
      super$initialize(x, varname, varlabel, input_dataname, extract_type)

      if (!is(x, "factor")) {
        x <- factor(x, levels = as.character(sort(unique(x))))
      }

      x <- droplevels(x)
      choices <- levels(x)
      names(choices) <- sprintf("%s (%s)", choices, tabulate(x))


      private$set_choices(as.list(choices))
      self$set_selected(unname(choices))
      private$histogram_data <- data.frame(
        x = levels(x),
        y = tabulate(x)
      )

      return(invisible(self))
    },

    #' @description
    #' Answers the question of whether the current settings and values selected actually filters out any values.
    #' @return logical scalar
    is_any_filtered = function() {
      if (!setequal(self$get_selected(), private$choices)) {
        TRUE
      } else if (!isTRUE(self$get_keep_na()) && private$na_count > 0) {
        TRUE
      } else {
        FALSE
      }
    },

    #' @description
    #' Returns reproducible condition call for current selection.
    #' For this class returned call looks like
    #' `<varname> %in%  c(<values selected>)` with
    #' optional `is.na(<varname>)`.
    #' @return (`call`)
    get_call = function() {
      filter_call <- call_condition_choice(
        varname = private$get_varname_prefixed(),
        choice = self$get_selected()
      )

      filter_call <- private$add_keep_na_call(filter_call)

      filter_call
    },

    #' @description
    #' UI Module for `ChoicesFilterState`.
    #' This UI element contains available choices selection and
    #' checkbox whether to keep or not keep the `NA` values.
    #' @param id (`character(1)`)\cr
    #'  id of shiny element
    ui = function(id) {
      ns <- NS(id)
      fluidRow(
        if (length(private$choices) <= getOption("teal.threshold_slider_vs_checkboxgroup")) {
          div(
            style = "position: relative;",
            div(
              class = "filterPlotOverlayBoxes",
              plotOutput(ns("plot"), height = "100%")
            ),
            checkboxGroupInput(
              ns("selection"),
              label = NULL,
              choices =  private$choices,
              selected = self$get_selected(),
              width = "100%"
            )
          )
        } else {
          teal.widgets::optionalSelectInput(
            inputId = ns("selection"),
            choices = private$choices,
            selected = self$get_selected(),
            multiple = TRUE,
            options = shinyWidgets::pickerOptions(
              actionsBox = TRUE,
              liveSearch = (length(private$choices) > 10),
              noneSelectedText = "Select a value"
            )
          )
        },
        if (private$na_count > 0) {
          checkboxInput(
            ns("keep_na"),
            label = label_keep_na_count(private$na_count),
            value = isolate(self$get_keep_na())
          )
        } else {
          NULL
        }
      )
    },

    #' @description
    #' Server module
    #' @param id (`character(1)`)\cr
    #'   an ID string that corresponds with the ID used to call the module's UI function.
    #' @return `moduleServer` function which returns `NULL`
    server = function(id) {
      moduleServer(
        id = id,
        function(input, output, session) {
          logger::log_trace("ChoicesFilterState$server initializing, dataname: { deparse1(private$input_dataname) }")
          shiny::setBookmarkExclude(c("selection", "keep_na"))
          output$plot <- renderPlot(
            bg = "transparent",
            expr = {
              if (length(private$choices) <= getOption("teal.threshold_slider_vs_checkboxgroup")) {
                # Proportional
                data <- private$histogram_data
                data$y <- rev(data$y / sum(data$y)) # we have to reverse because the histogram is turned by 90 degrees
                data$x <- seq_len(nrow(data)) # to prevent ggplot reordering columns using the characters in x column
                ggplot2::ggplot(data) +
                  # sort factor so that it reflects checkbox order
                  ggplot2::aes_string(x = "x", y = "y") +
                  ggplot2::geom_col(
                    width = 0.95,
                    fill = grDevices::rgb(66 / 255, 139 / 255, 202 / 255),
                    color = NA,
                    alpha = 0.2
                  ) +
                  ggplot2::coord_flip() +
                  ggplot2::theme_void() +
                  ggplot2::scale_x_discrete(expand = c(0, 0)) +
                  ggplot2::scale_y_continuous(expand = c(0, 0), limits = c(0, 1))
              }
            }
          )

          private$observers$selection_reactive <- observeEvent(
            private$selected_reactive(),
            ignoreNULL = TRUE,
            handlerExpr = {
              updateCheckboxInput(
                session = session,
                inputId = "selection",
                value =  private$selected_reactive()
              )

              logger::log_trace(sprintf(
                "ChoicesFilterState$server@1 selection of variable %s changed, dataname: %s",
                deparse1(self$get_varname()),
                deparse1(private$input_dataname)
              ))
              private$selected_reactive(NULL)
            }
          )
          private$observe_keep_na_reactive(private$keep_na_reactive())

          private$observers$selection <- observeEvent(
            ignoreNULL = FALSE, # ignoreNULL: we don't want to ignore NULL when nothing is selected in `selectInput`
            ignoreInit = TRUE, # ignoreInit: should not matter because we set the UI with the desired initial state
            eventExpr = input$selection,
            handlerExpr = {
              selection <- if (is.null(input$selection)) character(0) else input$selection
              self$set_selected(selection)
              logger::log_trace(sprintf(
                "ChoicesFilterState$server@2 selection of variable %s changed, dataname: %s",
                deparse1(self$get_varname()),
                deparse1(private$input_dataname)
              ))
            }
          )
          private$observe_keep_na(input)

          logger::log_trace("ChoicesFilterState$server initialized, dataname: { deparse1(private$input_dataname) }")
          NULL
        }
      )
    },

    #' @description
    #' Set state
    #' @param state (`list`)\cr
    #'  contains fields relevant for a specific class
    #' \itemize{
    #' \item{`selected`}{ defines initial selection}
    #' \item{`keep_na` (`logical`)}{ defines whether to keep or remove `NA` values}
    #' }
    set_state = function(state) {
      if (!is.null(state$selected)) {
        state$selected <- as.character(state$selected)
      }
      super$set_state(state)
      invisible(NULL)
    },

    #' @description
    #' Set state when using `set_filter_state`
    #' @param state (`list`)\cr
    #'  contains fields relevant for a specific class
    #' \itemize{
    #' \item{`selected`}{ defines initial selection}
    #' \item{`keep_na` (`logical`)}{ defines whether to keep or remove `NA` values}
    #' }
    set_state_reactive = function(state) {
      if (!is.null(state$selected)) {
        state$selected <- as.character(state$selected)
      }
      super$set_state_reactive(state)
      invisible(NULL)
    },

    #' @description
    #' Sets the selected values of this `ChoicesFilterState`.
    #'
    #' @param value (`character`) the array of the selected choices.
    #'   Must not contain NA values.
    #'
    #' @return invisibly `NULL`
    #'
    #' @note Casts the passed object to `character` before validating the input
    #' making it possible to pass any object coercible to `character` to this method.
    #'
    #' @examples
    #' filter <- teal.slice:::ChoicesFilterState$new(c("a", "b", "c"), varname = "name")
    #' filter$set_selected(c("c", "a"))
    set_selected = function(value) {
      super$set_selected(value)
    }
  ),
  private = list(
    histogram_data = data.frame(),
    validate_selection = function(value) {
      if (!is.character(value)) {
        stop(
          sprintf(
            "Values of the selection for `%s` in `%s` should be an array of character.",
            self$get_varname(deparse = TRUE),
            self$get_dataname(deparse = TRUE)
          )
        )
      }
      pre_msg <- sprintf(
        "data '%s', variable '%s': ",
        self$get_dataname(deparse = TRUE),
        self$get_varname(deparse = TRUE)
      )
      check_in_subset(value, private$choices, pre_msg = pre_msg)
    },
    cast_and_validate = function(values) {
      tryCatch(
        expr = {
          values <- as.character(values)
          if (any(is.na(values))) stop()
        },
        error = function(error) stop("The array of set values must contain values coercible to character.")
      )
      values
    },
    remove_out_of_bound_values = function(values) {
      in_choices_mask <- values %in% private$choices
      if (length(values[!in_choices_mask]) > 0) {
        warning(paste(
          "Values:", strtrim(paste(values[!in_choices_mask], collapse = ", "), 360),
          "are not in choices of column", private$varname, "in dataset", private$input_dataname, "."
        ))
      }
      values[in_choices_mask]
    }
  )
)

# DateFilterState ---------
#' @name DateFilterState
#' @title `FilterState` object for Date variable
#' @docType class
#' @keywords internal
#'
#'
#' @examples
#' filter_state <- teal.slice:::DateFilterState$new(
#'   c(Sys.Date() + seq(1:10), NA),
#'   varname = "x",
#'   input_dataname = as.name("data"),
#'   extract_type = character(0)
#' )
#' isolate(filter_state$get_call())
#'
#' isolate(filter_state$set_selected(c(Sys.Date() + 3L, Sys.Date() + 8L)))
#' isolate(filter_state$set_keep_na(TRUE))
#' isolate(filter_state$get_call())
DateFilterState <- R6::R6Class( # nolint
  "DateFilterState",
  inherit = FilterState,
  public = list(

    #' @description
    #' Initialize a `FilterState` object
    #' @param x (`Date`)\cr
    #'   values of the variable used in filter
    #' @param varname (`character`, `name`)\cr
    #'   name of the variable
    #' @param varlabel (`character(1)`)\cr
    #'   label of the variable (optional).
    #' @param input_dataname (`name` or `call`)\cr
    #'   name of dataset where `x` is taken from
    #' @param extract_type (`character(0)`, `character(1)`)\cr
    #' whether condition calls should be prefixed by dataname. Possible values:
    #' \itemize{
    #' \item{`character(0)` (default)}{ `varname` in the condition call will not be prefixed}
    #' \item{`"list"`}{ `varname` in the condition call will be returned as `<input_dataname>$<varname>`}
    #' \item{`"matrix"`}{ `varname` in the condition call will be returned as `<input_dataname>[, <varname>]`}
    #' }
    initialize = function(x,
                          varname,
                          varlabel = character(0),
                          input_dataname = NULL,
                          extract_type = character(0)) {
      stopifnot(is(x, "Date"))
      super$initialize(x, varname, varlabel, input_dataname, extract_type)

      var_range <- range(x, na.rm = TRUE)
      private$set_choices(var_range)
      self$set_selected(var_range)

      return(invisible(self))
    },

    #' @description
    #' Returns a formatted string representing this `DateFilterState`.
    #'
    #' @param indent (`numeric(1)`) the number of spaces before after each new line character of the formatted string.
    #' Default: 0
    #' @return `character(1)` the formatted string
    #'
    format = function(indent = 0) {
      checkmate::assert_number(indent, finite = TRUE, lower = 0)

      sprintf(
        "%sFiltering on: %s\n%1$s  Selected range: %s - %s\n%1$s  Include missing values: %s",
        format("", width = indent),
        self$get_varname(deparse = TRUE),
        format(self$get_selected()[1], nsmall = 3),
        format(self$get_selected()[2], nsmall = 3),
        format(self$get_keep_na())
      )
    },

    #' @description
    #' Answers the question of whether the current settings and values selected actually filters out any values.
    #' @return logical scalar
    is_any_filtered = function() {
      if (!setequal(self$get_selected(), private$choices)) {
        TRUE
      } else if (!isTRUE(self$get_keep_na()) && private$na_count > 0) {
        TRUE
      } else {
        FALSE
      }
    },

    #' @description
    #' Returns reproducible condition call for current selection.
    #' For this class returned call looks like
    #' `<varname> >= <min value> & <varname> <= <max value>` with
    #' optional `is.na(<varname>)`.
    #' @return (`call`)
    get_call = function() {
      filter_call <- call_condition_range_date(
        varname = private$get_varname_prefixed(),
        range = self$get_selected()
      )

      filter_call <- private$add_keep_na_call(filter_call)

      filter_call
    },

    #' @description
    #' UI Module for `DateFilterState`.
    #' This UI element contains two date selections for `min` and `max`
    #' of the range and a checkbox whether to keep the `NA` values.
    #' @param id (`character(1)`)\cr
    #'  id of shiny element
    ui = function(id) {
      ns <- NS(id)
      fluidRow(
        div(
          actionButton(
            inputId = ns("start_date_reset"),
            label = NULL,
            icon = icon("fas fa-undo"),
            style = "float: left; padding: 0; padding-top: 4px; padding-bottom: 5px; width: 10%;"
          ),
          actionButton(
            inputId = ns("end_date_reset"),
            label = NULL,
            icon = icon("fas fa-undo"),
            style = "float: right; padding: 0; padding-top: 4px; padding-bottom: 5px; width: 10%;"
          ),
          div(
            style = "margin: auto; width: 80%;",
            dateRangeInput(
              inputId = ns("selection"),
              label = NULL,
              start = isolate(self$get_selected())[1],
              end = isolate(self$get_selected())[2],
              min = private$choices[1],
              max = private$choices[2]
            )
          )
        ),
        if (private$na_count > 0) {
          checkboxInput(
            ns("keep_na"),
            label_keep_na_count(private$na_count),
            value = isolate(self$get_keep_na())
          )
        } else {
          NULL
        }
      )
    },

    #' @description
    #' Server module
    #' @param id (`character(1)`)\cr
    #'   an ID string that corresponds with the ID used to call the module's UI function.
    #' @return `moduleServer` function which returns `NULL`
    server = function(id) {
      moduleServer(
        id = id,
        function(input, output, session) {
          logger::log_trace("DateFilterState$server initializing, dataname: { deparse1(private$input_dataname) }")
          shiny::setBookmarkExclude(c("selection", "keep_na"))
          private$observers$selection_reactive <- observeEvent(
            private$selected_reactive(),
            ignoreNULL = TRUE,
            handlerExpr = {
              updateDateRangeInput(
                session = session,
                inputId = "selection",
                start = private$selected_reactive()[1],
                end = private$selected_reactive()[2]
              )
              logger::log_trace(sprintf(
                "DateFilterState$server@1 selection of variable %s changed, dataname: %s",
                deparse1(self$get_varname()),
                deparse1(private$input_dataname)
              ))
              private$selected_reactive(NULL)
            }
          )
          private$observe_keep_na_reactive(private$keep_na_reactive())

          private$observers$selection <- observeEvent(
            ignoreNULL = FALSE, # ignoreNULL: we don't want to ignore NULL when nothing is selected in `selectInput`,
            ignoreInit = TRUE, # ignoreInit: should not matter because we set the UI with the desired initial state
            eventExpr = input$selection,
            handlerExpr = {
              start_date <- input$selection[1]
              end_date <- input$selection[2]

              self$set_selected(c(start_date, end_date))
              logger::log_trace(sprintf(
                "DateFilterState$server@2 selection of variable %s changed, dataname: %s",
                deparse1(self$get_varname()),
                deparse1(private$input_dataname)
              ))
            }
          )

          private$observe_keep_na(input)

          private$observers$reset1 <- observeEvent(input$start_date_reset, {
            updateDateRangeInput(
              session = session,
              inputId = "selection",
              start = private$choices[1]
            )
            logger::log_trace(sprintf(
              "DateFilterState$server@3 reset start date of variable %s, dataname: %s",
              deparse1(self$get_varname()),
              deparse1(private$input_dataname)
            ))
          })

          private$observers$reset2 <- observeEvent(input$end_date_reset, {
            updateDateRangeInput(
              session = session,
              inputId = "selection",
              end = private$choices[2]
            )
            logger::log_trace(sprintf(
              "DateFilterState$server@4 reset end date of variable %s, dataname: %s",
              deparse1(self$get_varname()),
              deparse1(private$input_dataname)
            ))
          })
          logger::log_trace("DateFilterState$server initialized, dataname: { deparse1(private$input_dataname) }")
          NULL
        }
      )
    },

    #' @description
    #' Sets the selected time frame of this `DateFilterState`.
    #'
    #' @param value (`Date(2)`) the lower and the upper bound of the selected
    #'   time frame. Must not contain NA values.
    #'
    #' @return invisibly `NULL`.
    #'
    #' @note Casts the passed object to `Date` before validating the input
    #' making it possible to pass any object coercible to `Date` to this method.
    #'
    #' @examples
    #' date <- as.Date("13/09/2021")
    #' filter <- teal.slice:::DateFilterState$new(
    #'   c(date, date + 1, date + 2, date + 3),
    #'   varname = "name"
    #' )
    #' filter$set_selected(c(date + 1, date + 2))
    set_selected = function(value) {
      super$set_selected(value)
    }
  ),
  private = list(
    validate_selection = function(value) {
      if (!is(value, "Date")) {
        stop(
          sprintf(
            "value of the selection for `%s` in `%s` should be a Date",
            self$get_varname(deparse = TRUE),
            self$get_dataname(deparse = TRUE)
          )
        )
      }
      pre_msg <- sprintf(
        "dataset '%s', variable '%s': ",
        self$get_dataname(deparse = TRUE),
        self$get_varname(deparse = TRUE)
      )
      check_in_range(value, private$choices, pre_msg = pre_msg)
    },
    cast_and_validate = function(values) {
      tryCatch(
        expr = {
          values <- as.Date(values)
          if (any(is.na(values))) stop()
        },
        error = function(error) stop("The array of set values must contain values coercible to Date.")
      )
      if (length(values) != 2) stop("The array of set values must have length two.")
      values
    },
    remove_out_of_bound_values = function(values) {
      if (values[1] < private$choices[1]) {
        warning(paste(
          "Value:", values[1], "is outside of the possible range for column", private$varname,
          "of dataset", private$input_dataname, "."
        ))
        values[1] <- private$choices[1]
      }

      if (values[2] > private$choices[2]) {
        warning(paste(
          "Value:", values[2], "is outside of the possible range for column", private$varname,
          "of dataset", private$input_dataname, "."
        ))
        values[2] <- private$choices[2]
      }
      values
    }
  )
)

# DatetimeFilterState ---------
#' @rdname DatetimeFilterState
#' @title `FilterState` object for `POSIXct` variable
#' @docType class
#' @keywords internal
#'
#'
#' @examples
#' filter_state <- teal.slice:::DatetimeFilterState$new(
#'   c(Sys.time() + seq(0, by = 3600, length.out = 10), NA),
#'   varname = "x",
#'   input_dataname = as.name("data"),
#'   extract_type = character(0)
#' )
#'
#' isolate(filter_state$get_call())
#' isolate(filter_state$set_selected(c(Sys.time() + 3L, Sys.time() + 8L)))
#' isolate(filter_state$set_keep_na(TRUE))
#' isolate(filter_state$get_call())
DatetimeFilterState <- R6::R6Class( # nolint
  "DatetimeFilterState",
  inherit = FilterState,
  public = list(

    #' @description
    #' Initialize a `FilterState` object. This class
    #' has an extra field, `private$timezone`, which is set to `Sys.timezone()` by
    #' default. However, in case when using this module in `teal` app, one needs
    #' timezone of the app user. App user timezone is taken from `session$userData$timezone`
    #' and is set only if object is initialized in `shiny`.
    #' @param x (`POSIXct` or `POSIXlt`)\cr
    #'   values of the variable used in filter
    #' @param varname (`character`, `name`)\cr
    #'   name of the variable
    #' @param varlabel (`character(1)`)\cr
    #'   label of the variable (optional).
    #' @param input_dataname (`name` or `call`)\cr
    #'   name of dataset where `x` is taken from
    #' @param extract_type (`character(0)`, `character(1)`)\cr
    #' whether condition calls should be prefixed by dataname. Possible values:
    #' \itemize{
    #' \item{`character(0)` (default)}{ `varname` in the condition call will not be prefixed}
    #' \item{`"list"`}{ `varname` in the condition call will be returned as `<input_dataname>$<varname>`}
    #' \item{`"matrix"`}{ `varname` in the condition call will be returned as `<input_dataname>[, <varname>]`}
    #' }
    initialize = function(x,
                          varname,
                          varlabel = character(0),
                          input_dataname = NULL,
                          extract_type = character(0)) {
      stopifnot(is(x, "POSIXct") || is(x, "POSIXlt"))
      super$initialize(x, varname, varlabel, input_dataname, extract_type)

      var_range <- range(x, na.rm = TRUE)
      private$set_choices(var_range)
      self$set_selected(var_range)

      if (shiny::isRunning()) {
        session <- getDefaultReactiveDomain()
        if (!is.null(session$userData$timezone)) {
          private$timezone <- session$userData$timezone
        }
      } else if (isTRUE(attr(x, "tz") != "")) {
        private$timezone <- attr(x, "tz")
      }

      return(invisible(self))
    },

    #' @description
    #' Returns a formatted string representing this `DatetimeFilterState`.
    #'
    #' @param indent (`numeric(1)`) the number of spaces before after each new line character of the formatted string.
    #' Default: 0
    #' @return `character(1)` the formatted string
    #'
    format = function(indent = 0) {
      checkmate::assert_number(indent, finite = TRUE, lower = 0)

      sprintf(
        "%sFiltering on: %s\n%1$s  Selected range: %s - %s\n%1$s  Include missing values: %s",
        format("", width = indent),
        self$get_varname(deparse = TRUE),
        format(self$get_selected(), nsmall = 3)[1],
        format(self$get_selected(), nsmall = 3)[2],
        format(self$get_keep_na())
      )
    },

    #' @description
    #' Answers the question of whether the current settings and values selected actually filters out any values.
    #' @return logical scalar
    is_any_filtered = function() {
      if (!setequal(self$get_selected(), private$choices)) {
        TRUE
      } else if (!isTRUE(self$get_keep_na()) && private$na_count > 0) {
        TRUE
      } else {
        FALSE
      }
    },

    #' @description
    #' Returns reproducible condition call for current selection.
    #' For this class returned call looks like
    #' `<varname> >= as.POSIXct(<min>, tz = <timezone>) & <varname> <= <max>, tz = <timezone>)`
    #' with optional `is.na(<varname>)`.
    get_call = function() {
      filter_call <- call_condition_range_posixct(
        varname = private$get_varname_prefixed(),
        range = self$get_selected(),
        timezone = private$timezone
      )

      filter_call <- private$add_keep_na_call(filter_call)

      filter_call
    },

    #' @description
    #' UI Module for `DatetimeFilterState`.
    #' This UI element contains two date-time selections for `min` and `max`
    #' of the range and a checkbox whether to keep the `NA` values.
    #' @param id (`character(1)`)\cr
    #'  id of shiny element
    ui = function(id) {
      ns <- NS(id)
      fluidRow(
        div(
          actionButton(
            inputId = ns("start_date_reset"),
            label = NULL,
            icon = icon("fas fa-undo"),
            style = "float: left; padding: 0; padding-top: 4px; padding-bottom: 5px; width: 10%;"
          ),
          actionButton(
            inputId = ns("end_date_reset"),
            label = NULL,
            icon = icon("fas fa-undo"),
            style = "float: right; padding: 0; padding-top: 4px; padding-bottom: 5px; width: 10%;"
          ),
          div(
            class = "input-daterange input-group",
            style = "margin: auto; width: 80%;",
            div(style = "float: left; width: 100%;", {
              x <- shinyWidgets::airDatepickerInput(
                inputId = ns("selection_start"),
                value = isolate(self$get_selected())[1],
                startView = isolate(self$get_selected())[1],
                timepicker = TRUE,
                minDate = private$choices[1],
                maxDate = private$choices[2],
                update_on = "close",
                addon = "none",
                position = "bottom right"
              )
              x$children[[2]]$attribs <- c(x$children[[2]]$attribs, list(class = " input-sm"))
              x
            }),
            span(
              class = "input-group-addon",
              "to",
              title = "Times are displayed in the local timezone and are converted to UTC in the analysis"
            ),
            div(style = "float: right; width: 100%;", {
              x <- shinyWidgets::airDatepickerInput(
                inputId = ns("selection_end"),
                value = isolate(self$get_selected())[2],
                startView = isolate(self$get_selected())[2],
                timepicker = TRUE,
                minDate = private$choices[1],
                maxDate = private$choices[2],
                update_on = "close",
                addon = "none",
                position = "bottom right"
              )
              x$children[[2]]$attribs <- c(x$children[[2]]$attribs, list(class = " input-sm"))
              x
            })
          )
        ),
        if (private$na_count > 0) {
          checkboxInput(
            ns("keep_na"),
            label_keep_na_count(private$na_count),
            value = isolate(self$get_keep_na())
          )
        } else {
          NULL
        }
      )
    },

    #' @description
    #' Server module
    #' @param id (`character(1)`)\cr
    #'   an ID string that corresponds with the ID used to call the module's UI function.
    #' @return `moduleServer` function which returns `NULL`
    server = function(id) {
      moduleServer(
        id = id,
        function(input, output, session) {
          logger::log_trace("DatetimeFilterState$server initializing, dataname: { deparse1(private$input_dataname) }")
          shiny::setBookmarkExclude(c("selection_start", "selection_end", "keep_na"))
          private$observers$selection_reactive <- observeEvent(
            private$selected_reactive(),
            ignoreNULL = TRUE,
            handlerExpr = {
              shinyWidgets::updateAirDateInput(
                session = session,
                inputId = "selection_start",
                value = private$selected_reactive()[1]
              )

              shinyWidgets::updateAirDateInput(
                session = session,
                inputId = "selection_end",
                value = private$selected_reactive()[2]
              )
              logger::log_trace(sprintf(
                "DatetimeFilterState$server@1 selection of variable %s changed, dataname: %s",
                deparse1(self$get_varname()),
                deparse1(private$input_dataname)
              ))
              private$selected_reactive(NULL)
            }
          )
          private$observe_keep_na_reactive(private$keep_na_reactive())

          private$observers$selection <- observeEvent(
            ignoreNULL = FALSE, # ignoreNULL: we don't want to ignore NULL when nothing is selected in `selectInput`,
            ignoreInit = TRUE, # ignoreInit: should not matter because we set the UI with the desired initial state
            eventExpr = {
              input$selection_start
              input$selection_end
            },
            handlerExpr = {
              start_date <- input$selection_start
              end_date <- input$selection_end

              if (start_date < private$choices[1]) {
                start_date <- private$choices[1]
              }

              if (end_date > private$choices[2]) {
                end_date <- private$choices[2]
              }


              self$set_selected(c(start_date, end_date))
              logger::log_trace(sprintf(
                "DatetimeFilterState$server@2 selection of variable %s changed, dataname: %s",
                deparse1(self$get_varname()),
                deparse1(private$input_dataname)
              ))
            }
          )

          private$observe_keep_na(input)

          private$observers$reset1 <- observeEvent(input$start_date_reset, {
            shinyWidgets::updateAirDateInput(
              session = session,
              inputId = "selection_start",
              value = private$choices[1]
            )
            logger::log_trace(sprintf(
              "DatetimeFilterState$server@2 reset start date of variable %s, dataname: %s",
              deparse1(self$get_varname()),
              deparse1(private$input_dataname)
            ))
          })
          private$observers$reset2 <- observeEvent(input$end_date_reset, {
            shinyWidgets::updateAirDateInput(
              session = session,
              inputId = "selection_end",
              value = private$choices[2]
            )
            logger::log_trace(sprintf(
              "DatetimeFilterState$server@3 reset end date of variable %s, dataname: %s",
              deparse1(self$get_varname()),
              deparse1(private$input_dataname)
            ))
          })
          logger::log_trace("DatetimeFilterState$server initialized, dataname: { deparse1(private$input_dataname) }")
          NULL
        }
      )
    },

    #' @description
    #' Sets the selected time frame of this `DatetimeFilterState`.
    #'
    #' @param value (`POSIX(2)`) the lower and the upper bound of the selected
    #'   time frame. Must not contain NA values.
    #'
    #' @return invisibly `NULL`.
    #'
    #' @note Casts the passed object to `POSIXct` before validating the input
    #' making it possible to pass any object coercible to `POSIXct` to this method.
    #'
    #' @examples
    #' date <- as.POSIXct(1, origin = "01/01/1970")
    #' filter <- teal.slice:::DatetimeFilterState$new(
    #'   c(date, date + 1, date + 2, date + 3),
    #'   varname = "name"
    #' )
    #' filter$set_selected(c(date + 1, date + 2))
    set_selected = function(value) {
      super$set_selected(value)
    }
  ),
  private = list(
    timezone = Sys.timezone(),
    validate_selection = function(value) {
      if (!(is(value, "POSIXct") || is(value, "POSIXlt"))) {
        stop(
          sprintf(
            "value of the selection for `%s` in `%s` should be a POSIXct or POSIXlt",
            self$get_varname(deparse = TRUE),
            self$get_dataname(deparse = TRUE)
          )
        )
      }

      pre_msg <- sprintf(
        "dataset '%s', variable '%s': ",
        self$get_dataname(deparse = TRUE),
        self$get_varname(deparse = TRUE)
      )
      check_in_range(value, private$choices, pre_msg = pre_msg)
    },
    cast_and_validate = function(values) {
      tryCatch(
        expr = {
          values <- as.POSIXct(values)
          if (any(is.na(values))) stop()
        },
        error = function(error) stop("The array of set values must contain values coercible to POSIX.")
      )
      if (length(values) != 2) stop("The array of set values must have length two.")
      values
    },
    remove_out_of_bound_values = function(values) {
      if (values[1] < private$choices[1]) {
        warning(paste(
          "Value:", values[1], "is outside of the possible range for column", private$varname,
          "of dataset", private$input_dataname, "."
        ))
        values[1] <- private$choices[1]
      }

      if (values[2] > private$choices[2]) {
        warning(paste(
          "Value:", values[2], "is outside of the possible range for column", private$varname,
          "of dataset", private$input_dataname, "."
        ))
        values[2] <- private$choices[2]
      }
      values
    }
  )
)
