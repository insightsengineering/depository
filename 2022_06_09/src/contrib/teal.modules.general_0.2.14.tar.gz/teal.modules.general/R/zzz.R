.onLoad <- function(libname, pkgname) { # nolint
  teal.logger::register_logger(namespace = "teal.modules.general")
}
