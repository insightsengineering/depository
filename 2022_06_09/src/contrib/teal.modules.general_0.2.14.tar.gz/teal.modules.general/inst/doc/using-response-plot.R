## ----echo=TRUE, message=FALSE, warning=FALSE, results="hide"------------------
library(teal.modules.general) # used to create the app
library(scda) # used to create data sets
library(dplyr) # used to modify data sets

## ----echo=TRUE, message=FALSE, warning=FALSE, results="hide"------------------
ADSL <- synthetic_cdisc_data("latest")$adsl # nolint
ADSL2 <- synthetic_cdisc_data("latest")$adsl %>% # nolint
  mutate(TRTDUR = round(as.numeric(TRTEDTM - TRTSDTM), 1))
ADRS <- synthetic_cdisc_data("latest")$adrs # nolint
ADTTE <- synthetic_cdisc_data("latest")$adtte # nolint
ADLB <- synthetic_cdisc_data("latest")$adlb %>% # nolint
  mutate(CHGC = as.factor(case_when(
    CHG < 1 ~ "N",
    CHG > 1 ~ "P",
    TRUE ~ "-"
  )))

## ----echo=TRUE, message=FALSE, warning=FALSE, results="hide"------------------
app <- init(
  data = cdisc_data(
    cdisc_dataset("ADSL", ADSL, code = "ADSL <- synthetic_cdisc_data(\"latest\")$adsl"),
    cdisc_dataset(
      "ADSL2",
      ADSL2,
      keys = get_cdisc_keys("ADSL"),
      code = "ADSL2 <- synthetic_cdisc_data(\"latest\")$adsl %>%
              mutate(TRTDUR = round(as.numeric(TRTEDTM - TRTSDTM), 1))"
    ),
    cdisc_dataset("ADRS", ADRS, code = "ADRS <- synthetic_cdisc_data(\"latest\")$adrs"),
    cdisc_dataset("ADTTE", ADTTE, code = "ADTTE <- synthetic_cdisc_data(\"latest\")$adtte"),
    cdisc_dataset(
      "ADLB",
      ADLB,
      code = "ADLB <- synthetic_cdisc_data(\"latest\")$adlb %>%
            mutate(CHGC = as.factor(case_when(
            CHG < 1 ~ 'N',
            CHG > 1 ~ 'P',
            TRUE ~ '-'
            )))"
    ),
    check = TRUE
  ),
  modules = modules(
    modules(
      label = "Response plot",
      tm_g_response(
        label = "Single wide dataset",
        response = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            label = "Select variable:",
            choices = variable_choices(ADSL, c("BMRKR2", "ITTFL", "BEP01FL")),
            selected = "BMRKR2",
            multiple = FALSE,
            fixed = FALSE
          )
        ),
        x = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            label = "Select variable:",
            choices = variable_choices(ADSL, c("SEX", "RACE", "COUNTRY", "ARMCD", "STRATA1")),
            selected = "ARMCD",
            multiple = FALSE,
            fixed = FALSE
          )
        )
      ),
      tm_g_response(
        label = "Two wide datasets",
        response = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            label = "Select variable:",
            choices = variable_choices(ADSL, c("BMRKR2", "ITTFL", "BEP01FL")),
            selected = "BMRKR2",
            multiple = FALSE
          )
        ),
        x = data_extract_spec(
          dataname = "ADSL2",
          select = select_spec(
            label = "Select variable:",
            choices = c("SEX", "COUNTRY", "RACE", "STRATA1", "ARMCD"),
            selected = "ARMCD",
            multiple = FALSE
          )
        )
      ),
      tm_g_response(
        label = "Multiple long datasets",
        response = data_extract_spec(
          dataname = "ADLB",
          filter = list(
            filter_spec(
              label = "Select parameter:",
              vars = "PARAMCD",
              choices = levels(ADLB$PARAMCD),
              selected = levels(ADLB$PARAMCD)[1],
              multiple = FALSE
            ),
            filter_spec(
              label = "Select visit:",
              vars = "AVISIT",
              choices = levels(ADLB$AVISIT),
              selected = levels(ADLB$AVISIT)[1],
              multiple = FALSE
            )
          ),
          select = select_spec(
            label = "Select variable:",
            choices = variable_choices(ADLB, c("BMRKR2", "ITTFL", "BEP01FL")),
            selected = "BMRKR2",
            multiple = FALSE
          )
        ),
        x = data_extract_spec(
          dataname = "ADRS",
          filter = list(
            filter_spec(
              label = "Select parameter:",
              vars = "PARAMCD",
              choices = levels(ADRS$PARAMCD),
              selected = levels(ADRS$PARAMCD)[3],
              multiple = FALSE
            ),
            filter_spec(
              label = "Select visit:",
              vars = "AVISIT",
              choices = levels(ADRS$AVISIT),
              selected = levels(ADRS$AVISIT)[3],
              multiple = FALSE
            )
          ),
          select = select_spec(
            choices = c("AVALC", "ITTFL", "BEP01FL"),
            selected = "AVALC",
            multiple = FALSE,
            fixed = TRUE
          )
        ),
        row_facet = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            label = "Select variable:",
            choices = "SEX",
            selected = NULL,
            multiple = FALSE
          )
        ),
        col_facet = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            label = "Select variable:",
            choices = variable_choices(ADSL, c("SEX", "COUNTRY")),
            selected = NULL,
            multiple = FALSE
          )
        )
      ),
      tm_g_response(
        label = "Wide and long dataset",
        response = data_extract_spec(
          dataname = "ADLB",
          filter = list(
            filter_spec(
              vars = "PARAMCD",
              choices = levels(ADLB$PARAMCD),
              selected = levels(ADLB$PARAMCD)[2],
              multiple = TRUE,
              label = "Select measurement:"
            ),
            filter_spec(
              vars = "AVISIT",
              choices = levels(ADLB$AVISIT),
              selected = levels(ADLB$AVISIT)[2],
              multiple = TRUE,
              label = "Select visit:"
            )
          ),
          select = select_spec(
            choices = variable_choices(ADLB, c("BMRKR2", "ITTFL", "BEP01FL")),
            selected = "BMRKR2",
            multiple = FALSE,
            fixed = FALSE,
            label = "Select variable:"
          )
        ),
        x = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            choices = variable_choices(ADSL, c("ARMCD", "BMRKR1", "BMRKR2", "BEP01FL")),
            selected = "BMRKR2",
            multiple = FALSE,
            fixed = FALSE
          )
        )
      ),
      tm_g_response(
        label = "Same long datasets",
        response = data_extract_spec(
          dataname = "ADRS",
          select = select_spec(
            choices = variable_choices(ADRS, c("BMRKR2", "AVALC", "BEP01FL")),
            selected = "AVALC",
            multiple = FALSE,
            fixed = TRUE,
            label = "Select variable:"
          )
        ),
        x = data_extract_spec(
          dataname = "ADRS",
          select = select_spec(
            choices = variable_choices(ADRS, c("AVALC", "AGE", "SEX", "ARMCD", "STRATA1")),
            selected = "ARMCD",
            multiple = FALSE,
            fixed = FALSE,
            label = "Select variable:"
          )
        ),
        row_facet = data_extract_spec(
          dataname = "ADRS",
          select = select_spec(
            choices = "PARAMCD",
            selected = "PARAMCD",
            multiple = FALSE,
            fixed = FALSE,
            label = "Select variable:"
          )
        ),
        col_facet = data_extract_spec(
          dataname = "ADRS",
          select = select_spec(
            choices = "AVISIT",
            selected = "AVISIT",
            multiple = FALSE,
            fixed = FALSE,
            label = "Select variable:"
          )
        )
      ),
      tm_g_response(
        label = "Same long datasets  (different subsets)",
        response = data_extract_spec(
          dataname = "ADLB",
          filter = filter_spec(
            vars = "PARAMCD",
            choices = levels(ADLB$PARAMCD),
            selected = levels(ADLB$PARAMCD)[2],
            multiple = FALSE,
            label = "Select lab:"
          ),
          select = select_spec(
            choices = "BMRKR2",
            selected = "BMRKR2",
            multiple = FALSE,
            fixed = TRUE
          )
        ),
        x = data_extract_spec(
          dataname = "ADLB",
          filter = filter_spec(
            vars = "PARAMCD",
            choices = levels(ADLB$PARAMCD),
            selected = levels(ADLB$PARAMCD)[1],
            multiple = FALSE,
            label = "Select lab:"
          ),
          select = select_spec(
            choices = variable_choices(ADLB, c("AVISIT", "PARAMCD", "BEP01FL")),
            selected = "AVISIT",
            multiple = FALSE,
            fixed = TRUE
          )
        ),
        row_facet = data_extract_spec(
          dataname = "ADLB",
          filter = list(
            filter_spec(
              vars = "PARAMCD",
              choices = levels(ADLB$PARAMCD),
              selected = levels(ADLB$PARAMCD)[1],
              multiple = FALSE,
              label = "Select lab:"
            ),
            filter_spec(
              vars = "AVISIT",
              choices = levels(ADLB$AVISIT),
              selected = levels(ADLB$AVISIT)[1],
              multiple = FALSE,
              label = "Select visit:"
            )
          ),
          select = select_spec(
            choices = variable_choices(ADLB, c("SEX", "RACE", "ARMCD")),
            selected = NULL,
            multiple = FALSE,
            fixed = FALSE,
            label = "Select Variable"
          )
        ),
        col_facet = data_extract_spec(
          dataname = "ADLB",
          filter = list(
            filter_spec(
              vars = "PARAMCD",
              choices = levels(ADLB$PARAMCD),
              selected = levels(ADLB$PARAMCD)[1],
              multiple = FALSE,
              label = "Select lab:"
            ),
            filter_spec(
              vars = "AVISIT",
              choices = levels(ADLB$AVISIT),
              selected = levels(ADLB$AVISIT)[1],
              multiple = FALSE,
              label = "Select visit:"
            )
          ),
          select = select_spec(
            choices = variable_choices(ADLB, c("SEX", "RACE", "ARMCD")),
            selected = NULL,
            multiple = FALSE,
            fixed = FALSE,
            label = "Select variable:"
          )
        )
      )
    )
  )
)

## ----echo=TRUE----------------------------------------------------------------
shinyApp(app$ui, app$server, options = list(height = 1024, width = 1024))

