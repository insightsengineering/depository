## ----echo=TRUE, message=FALSE, warning=FALSE, results="hide"------------------
library(teal.modules.general) # used to create the app
library(scda) # used to create data sets
library(dplyr) # used to modify data sets

## ----echo=TRUE, message=FALSE, warning=FALSE, results="hide"------------------
ADSL <- synthetic_cdisc_data("latest")$adsl # nolint
ADRS <- synthetic_cdisc_data("latest")$adrs # nolint
ADLB <- synthetic_cdisc_data("latest")$adlb # nolint

## ----echo=TRUE, message=FALSE, warning=FALSE, results="hide"------------------
app <- init(
  data = cdisc_data(
    cdisc_dataset("ADSL", ADSL, code = "ADSL <- synthetic_cdisc_data(\"latest\")$adsl"),
    cdisc_dataset("ADRS", ADRS, code = "ADRS <- synthetic_cdisc_data(\"latest\")$adrs"),
    cdisc_dataset("ADLB", ADLB, code = "ADLB <- synthetic_cdisc_data(\"latest\")$adlb"),
    check = TRUE
  ),
  modules = modules(
    # tm_outliers ----
    modules(
      label = "Outliers module",
      tm_outliers(
        label = "Single wide dataset",
        outlier_var = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            label = "Select variable:",
            choices = variable_choices(ADSL, c("AGE", "BMRKR1")),
            selected = "AGE",
            fixed = FALSE
          )
        ),
        categorical_var = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            label = "Select variables:",
            choices = variable_choices(ADSL, subset = names(Filter(isTRUE, sapply(ADSL, is.factor)))),
            selected = "RACE",
            multiple = FALSE,
            fixed = FALSE
          )
        )
      ),
      tm_outliers(
        label = "Wide and long datasets",
        outlier_var = list(
          data_extract_spec(
            dataname = "ADSL",
            select = select_spec(
              label = "Select variable:",
              choices = variable_choices(ADSL, c("AGE", "BMRKR1")),
              selected = "AGE",
              fixed = FALSE
            )
          ),
          data_extract_spec(
            dataname = "ADLB",
            select = select_spec(
              label = "Select variable:",
              choices = variable_choices(ADLB, c("AVAL", "CHG2")),
              selected = "AVAL",
              multiple = FALSE,
              fixed = FALSE
            )
          )
        ),
        categorical_var =
          data_extract_spec(
            dataname = "ADSL",
            select = select_spec(
              label = "Select variables:",
              choices = variable_choices(ADSL, subset = names(Filter(isTRUE, sapply(ADSL, is.factor)))),
              selected = "RACE",
              multiple = FALSE,
              fixed = FALSE
            )
          )
      ),
      tm_outliers(
        label = "Multiple long datasets",
        outlier_var = list(
          data_extract_spec(
            dataname = "ADRS",
            select = select_spec(
              label = "Select variable:",
              choices = variable_choices(ADRS, c("ADY", "EOSDY")),
              selected = "ADY",
              fixed = FALSE
            )
          ),
          data_extract_spec(
            dataname = "ADLB",
            select = select_spec(
              label = "Select variable:",
              choices = variable_choices(ADLB, c("AVAL", "CHG2")),
              selected = "AVAL",
              multiple = FALSE,
              fixed = FALSE
            )
          )
        ),
        categorical_var = list(
          data_extract_spec(
            dataname = "ADRS",
            select = select_spec(
              label = "Select variables:",
              choices = variable_choices(ADRS, c("ARM", "ACTARM")),
              selected = "ARM",
              multiple = FALSE,
              fixed = FALSE
            )
          ),
          data_extract_spec(
            dataname = "ADLB",
            select = select_spec(
              label = "Select variables:",
              choices = variable_choices(ADLB, subset = names(Filter(isTRUE, sapply(ADLB, is.factor)))),
              selected = "RACE",
              multiple = FALSE,
              fixed = FALSE
            )
          )
        )
      )
    )
  )
)

## ----echo=TRUE----------------------------------------------------------------
shinyApp(app$ui, app$server, options = list(height = 1024, width = 1024))

