## ----echo=TRUE, message=FALSE, warning=FALSE, results="hide"------------------
library(teal.modules.general) # used to create the app
library(scda) # used to create data sets
library(dplyr) # used to modify data sets

## ----echo=TRUE, message=FALSE, warning=FALSE, results="hide"------------------
ADSL <- synthetic_cdisc_data("latest")$adsl # nolint
ADSL2 <- synthetic_cdisc_data("latest")$adsl %>% # nolint
  mutate(TRTDUR = round(as.numeric(TRTEDTM - TRTSDTM), 1))
ADRS <- synthetic_cdisc_data("latest")$adrs # nolint
ADTTE <- synthetic_cdisc_data("latest")$adtte # nolint
ADLB <- synthetic_cdisc_data("latest")$adlb %>% # nolint
  mutate(CHGC = as.factor(case_when(
    CHG < 1 ~ "N",
    CHG > 1 ~ "P",
    TRUE ~ "-"
  )))

## ----echo=TRUE, message=FALSE, warning=FALSE, results="hide"------------------
app <- init(
  data = cdisc_data(
    cdisc_dataset("ADSL", ADSL, code = "ADSL <- synthetic_cdisc_data(\"latest\")$adsl"),
    cdisc_dataset("ADSL2", ADSL2,
      keys = get_cdisc_keys("ADSL"),
      code = "ADSL2 <- synthetic_cdisc_data(\"latest\")$adsl %>%
              mutate(TRTDUR = round(as.numeric(TRTEDTM - TRTSDTM), 1))"
    ),
    cdisc_dataset("ADRS", ADRS, code = "ADRS <- synthetic_cdisc_data(\"latest\")$adrs"),
    cdisc_dataset("ADTTE", ADTTE, code = "ADTTE <- synthetic_cdisc_data(\"latest\")$adtte"),
    cdisc_dataset(
      "ADLB",
      ADLB,
      code = "ADLB <- synthetic_cdisc_data(\"latest\")$adlb %>%
            mutate(CHGC = as.factor(case_when(
            CHG < 1 ~ 'N',
            CHG > 1 ~ 'P',
            TRUE ~ '-'
            )))"
    ),
    check = TRUE
  ),
  modules = modules(
    modules(
      label = "Regression plots",
      tm_a_regression(
        label = "Single wide dataset",
        response = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            label = "Select variable:",
            choices = variable_choices(ADSL, c("BMRKR1", "BMRKR2")),
            selected = "BMRKR1",
            multiple = FALSE,
            fixed = FALSE
          )
        ),
        regressor = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            label = "Select variables:",
            choices = variable_choices(ADSL, c("AGE", "SEX", "RACE")),
            selected = "AGE",
            multiple = TRUE,
            fixed = FALSE
          )
        )
      ),
      tm_a_regression(
        label = "Two wide datasets",
        default_plot_type = 2,
        response = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            label = "Select variable:",
            choices = variable_choices(ADSL, c("BMRKR1", "BMRKR2")),
            selected = "BMRKR1",
            multiple = FALSE,
            fixed = FALSE
          )
        ),
        regressor = data_extract_spec(
          dataname = "ADSL2",
          select = select_spec(
            label = "Select variables:",
            choices = variable_choices(ADSL2, c("AGE", "SEX", "RACE")),
            selected = c("AGE", "RACE"),
            multiple = TRUE,
            fixed = FALSE
          )
        )
      ),
      tm_a_regression(
        label = "Same long datasets (same subset)",
        default_plot_type = 2,
        response = data_extract_spec(
          dataname = "ADTTE",
          select = select_spec(
            label = "Select variable:",
            choices = variable_choices(ADTTE, c("AVAL", "CNSR")),
            selected = "AVAL",
            multiple = FALSE,
            fixed = FALSE
          ),
          filter = filter_spec(
            label = "Select parameter:",
            vars = "PARAMCD",
            choices = value_choices(ADTTE, "PARAMCD", "PARAM"),
            selected = "PFS",
            multiple = FALSE
          )
        ),
        regressor = data_extract_spec(
          dataname = "ADTTE",
          select = select_spec(
            label = "Select variable:",
            choices = variable_choices(ADTTE, c("AGE", "CNSR", "SEX")),
            selected = c("AGE", "CNSR", "SEX"),
            multiple = TRUE
          ),
          filter = filter_spec(
            label = "Select parameter:",
            vars = "PARAMCD",
            choices = value_choices(ADTTE, "PARAMCD", "PARAM"),
            selected = "PFS",
            multiple = FALSE
          )
        )
      ),
      tm_a_regression(
        label = "Wide and long datasets",
        response = data_extract_spec(
          dataname = "ADLB",
          filter = list(
            filter_spec(
              vars = "PARAMCD",
              choices = value_choices(ADLB, "PARAMCD", "PARAM"),
              selected = levels(ADLB$PARAMCD)[2],
              multiple = TRUE,
              label = "Select measurement:"
            ),
            filter_spec(
              vars = "AVISIT",
              choices = levels(ADLB$AVISIT),
              selected = levels(ADLB$AVISIT)[2],
              multiple = TRUE,
              label = "Select visit:"
            )
          ),
          select = select_spec(
            label = "Select variable:",
            choices = "AVAL",
            selected = "AVAL",
            multiple = FALSE,
            fixed = TRUE
          )
        ),
        regressor = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            label = "Select variables:",
            choices = variable_choices(ADSL, c("BMRKR1", "BMRKR2", "AGE")),
            selected = "AGE",
            multiple = TRUE,
            fixed = FALSE
          )
        )
      ),
      tm_a_regression(
        label = "Same long datasets (different subsets)",
        default_plot_type = 2,
        response = data_extract_spec(
          dataname = "ADLB",
          filter = list(
            filter_spec(
              vars = "PARAMCD",
              choices = value_choices(ADLB, "PARAMCD", "PARAM"),
              selected = levels(ADLB$PARAMCD)[1],
              multiple = TRUE,
              label = "Select lab:"
            ),
            filter_spec(
              vars = "AVISIT",
              choices = levels(ADLB$AVISIT),
              selected = levels(ADLB$AVISIT)[1],
              multiple = TRUE,
              label = "Select visit:"
            )
          ),
          select = select_spec(
            choices = "AVAL",
            selected = "AVAL",
            multiple = FALSE,
            fixed = TRUE
          )
        ),
        regressor = data_extract_spec(
          dataname = "ADLB",
          filter = list(
            filter_spec(
              vars = "PARAMCD",
              choices = value_choices(ADLB, "PARAMCD", "PARAM"),
              selected = levels(ADLB$PARAMCD)[1],
              multiple = FALSE,
              label = "Select labs:"
            ),
            filter_spec(
              vars = "AVISIT",
              choices = levels(ADLB$AVISIT),
              selected = levels(ADLB$AVISIT)[1],
              multiple = FALSE,
              label = "Select visit:"
            )
          ),
          select = select_spec(
            choices = variable_choices(ADLB, c("AVAL", "AGE", "BMRKR1", "BMRKR2", "SEX", "ARM")),
            selected = c("AVAL", "BMRKR1"),
            multiple = TRUE
          )
        )
      )
    )
  )
)

## ----echo=TRUE----------------------------------------------------------------
shinyApp(app$ui, app$server, options = list(height = 1024, width = 1024))

