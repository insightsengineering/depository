## ----echo=TRUE, message=FALSE, warning=FALSE, results="hide"------------------
library(teal.modules.general) # used to create the app
library(scda) # used to create data sets
library(dplyr) # used to modify data sets

## ----echo=TRUE, message=FALSE, warning=FALSE, results="hide"------------------
ADSL <- synthetic_cdisc_data("latest")$adsl # nolint
ADSL2 <- synthetic_cdisc_data("latest")$adsl %>% # nolint
  mutate(TRTDUR = round(as.numeric(TRTEDTM - TRTSDTM), 1))
ADRS <- synthetic_cdisc_data("latest")$adrs # nolint
ADTTE <- synthetic_cdisc_data("latest")$adtte # nolint
ADLB <- synthetic_cdisc_data("latest")$adlb %>% # nolint
  mutate(CHGC = as.factor(case_when(
    CHG < 1 ~ "N",
    CHG > 1 ~ "P",
    TRUE ~ "-"
  )))

## ----echo=TRUE, message=FALSE, warning=FALSE, results="hide"------------------
app <- init(
  data = cdisc_data(
    cdisc_dataset("ADSL", ADSL, code = "ADSL <- synthetic_cdisc_data(\"latest\")$adsl"),
    cdisc_dataset(
      "ADSL2",
      ADSL2,
      keys = get_cdisc_keys("ADSL"),
      code = "ADSL2 <- synthetic_cdisc_data(\"latest\")$adsl %>%
              mutate(TRTDUR = round(as.numeric(TRTEDTM - TRTSDTM), 1))"
    ),
    cdisc_dataset("ADRS", ADRS, code = "ADRS <- synthetic_cdisc_data(\"latest\")$adrs"),
    cdisc_dataset("ADTTE", ADTTE, code = "ADTTE <- synthetic_cdisc_data(\"latest\")$adtte"),
    cdisc_dataset("ADLB", ADLB,
      code = "ADLB <- synthetic_cdisc_data(\"latest\")$adlb %>%
            mutate(CHGC = as.factor(case_when(
            CHG < 1 ~ 'N',
            CHG > 1 ~ 'P',
            TRUE ~ '-'
            )))"
    ),
    check = TRUE
  ),
  modules = modules(
    modules(
      label = "Scatterplot matrix",
      # .. single wide ----
      tm_g_scatterplotmatrix(
        label = "Single wide dataset",
        variables = data_extract_spec(
          dataname = "ADSL",
          select = select_spec(
            label = "Select variables:",
            choices = variable_choices(ADSL),
            selected = c("AGE", "RACE", "SEX", "BMRKR1", "BMRKR2"),
            multiple = TRUE,
            fixed = FALSE,
            ordered = TRUE
          )
        )
      ),
      tm_g_scatterplotmatrix(
        label = "Multiple wide datasets",
        variables = list(
          data_extract_spec(
            dataname = "ADSL",
            select = select_spec(
              label = "Select variables:",
              choices = variable_choices(ADSL),
              selected = c("AGE", "ACTARM", "SEX", "BMRKR1"),
              multiple = TRUE,
              fixed = FALSE,
              ordered = TRUE
            )
          ),
          data_extract_spec(
            dataname = "ADSL2",
            select = select_spec(
              label = "Select variables:",
              choices = variable_choices(ADSL2),
              selected = c("COUNTRY", "ACTARM", "STRATA1"),
              multiple = TRUE,
              fixed = FALSE,
              ordered = TRUE
            )
          )
        )
      ),
      tm_g_scatterplotmatrix(
        "One long dataset",
        variables = data_extract_spec(
          dataname = "ADTTE",
          select = select_spec(
            choices = variable_choices(ADTTE, c("AVAL", "BMRKR1", "BMRKR2")),
            selected = c("AVAL", "BMRKR1", "BMRKR2"),
            multiple = TRUE,
            fixed = FALSE,
            ordered = TRUE,
            label = "Select variables:"
          )
        )
      ),
      tm_g_scatterplotmatrix(
        label = "Two long datasets",
        variables = list(
          data_extract_spec(
            dataname = "ADRS",
            select = select_spec(
              label = "Select variables:",
              choices = variable_choices(ADRS),
              selected = c("AVAL", "AVALC"),
              multiple = TRUE,
              fixed = FALSE,
              ordered = TRUE,
            ),
            filter = filter_spec(
              label = "Select endpoints:",
              vars = c("PARAMCD", "AVISIT"),
              choices = value_choices(ADRS, c("PARAMCD", "AVISIT"), c("PARAM", "AVISIT")),
              selected = "OVRINV - SCREENING",
              multiple = FALSE
            )
          ),
          data_extract_spec(
            dataname = "ADTTE",
            select = select_spec(
              label = "Select variables:",
              choices = variable_choices(ADTTE),
              selected = c("AVAL", "CNSR"),
              multiple = TRUE,
              fixed = FALSE,
              ordered = TRUE
            ),
            filter = filter_spec(
              label = "Select parameters:",
              vars = "PARAMCD",
              choices = value_choices(ADTTE, "PARAMCD", "PARAM"),
              selected = "OS",
              multiple = TRUE
            )
          )
        )
      )
    )
  )
)

## ----echo=TRUE----------------------------------------------------------------
shinyApp(app$ui, app$server, options = list(height = 1024, width = 1024))

