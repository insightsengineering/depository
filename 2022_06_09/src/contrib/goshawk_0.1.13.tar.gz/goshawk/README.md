# goshawk R package

Longitudinal biomarker/lab visualizations functions. These can be used stand alone but are also called by the
[teal.goshawk](https://github.com/insightsengineering/teal.goshawk) package which provides `teal` modules to be used
inside `teal` applications.

## Functions
<!-- markdownlint-disable MD007 MD030 -->
-   `g_boxplot`
-   `g_correlationplot`
-   `g_density_distribution_plot`
-   `g_lineplot`
-   `g_scatterplot`
-   `g_spaghettiplot`
-   `t_summarytable`
<!-- markdownlint-enable MD007 MD030 -->

## Installation

It is recommended that you [create and use a Github PAT](https://docs.github.com/en/github/authenticating-to-github/keeping-your-account-and-data-secure/creating-a-personal-access-token) to install the latest version of this package. Once you have the PAT, run the following:

```r
Sys.setenv(GITHUB_PAT = "your_access_token_here")
if (!require("devtools")) install.packages("devtools")
devtools::install_github("insightsengineering/goshawk@*release")
```

In order to run many of the examples you will also need to install the [`scda`](https://github.com/insightsengineering/scda) package.
