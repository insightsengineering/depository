## ----setup, include = FALSE, echo=FALSE---------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(teal.transform)
library(shiny)

extract_ui <- function(id, data_extract) {
  ns <- NS(id)
  teal.widgets::standard_layout(
    output = teal.widgets::white_small_well(verbatimTextOutput(ns("output"))),
    encoding = data_extract_ui(ns("data_extract"), label = "variable", data_extract)
  )
}

extract_srv <- function(id, datasets, data_extract) {
  moduleServer(id, function(input, output, session) {
    reactive_extract_input <- data_extract_srv("data_extract", datasets, data_extract)
    s <- reactive({
      format_data_extract(reactive_extract_input())
    })
    output$output <- renderPrint({
      cat(s())
    })
  })
}

## -----------------------------------------------------------------------------
sample_filtered_data <- function() {
  # create TealData
  adsl <- teal.data::cdisc_dataset("ADSL", scda::synthetic_cdisc_data("latest")$adsl)
  adtte <- teal.data::cdisc_dataset("ADTTE", scda::synthetic_cdisc_data("latest")$adtte)
  data <- teal.data::cdisc_data(adsl, adtte)

  # covert TealData to FilteredData
  datasets <- teal.slice:::filtered_data_new(data)
  teal.slice:::filtered_data_set(data, datasets)
  datasets
}

datasets <- sample_filtered_data()

## -----------------------------------------------------------------------------
simple_des <- data_extract_spec(
  dataname = "ADSL",
  filter = filter_spec(vars = "SEX", choices = c("F", "M")),
  select = select_spec(choices = c("BMRKR1", "AGE"))
)

## ----eval=FALSE---------------------------------------------------------------
#  shinyApp(
#    ui = fluidPage(extract_ui("data_extract", simple_des)),
#    server = function(input, output, session) {
#      extract_srv("data_extract", datasets, simple_des)
#    }
#  )

