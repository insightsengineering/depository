test_that("loading hermes works", {
  expect_silent(library(hermes))
})
