# teal.logger 0.1.0

* Initial release of `teal.logger`, a package for the logging setup for `teal` applications.

## Changes (from behavior when functionality was part of `teal`)

### Misc
* The functions `suppress_logs` and `log_system_info` are now part of the API of the package as they are now exported.
