#' @description Logging setup for the `teal` family of packages.
#'
#' @keywords internal
"_PACKAGE"

# To silence R CMD checks.
#' @importFrom lifecycle badge
NULL
