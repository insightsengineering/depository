## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- echo=FALSE--------------------------------------------------------------
library(knitr)
output <- data.frame(
  A1 = c("100 (20)", "50 (30)"),
  B1 = c("90 (35)", "40 (15)"),
  "..." = c("", "")
)
row.names(output) <- c("M", "F")
kable(output, align = "c")

## -----------------------------------------------------------------------------
library(tern.mmrm)
data(mmrm_test_data)
head(mmrm_test_data)

## ----message=FALSE, results="hide"--------------------------------------------
mmrm_results <- fit_mmrm(
  vars = list(
    response = "FEV1",
    covariates = c("RACE", "SEX", "FEV1_BL"),
    id = "USUBJID",
    arm = "ARMCD",
    visit = "AVISIT"
  ),
  data = mmrm_test_data,
  cor_struct = "unstructured",
  weights_emmeans = "proportional"
)

## -----------------------------------------------------------------------------
mmrm_results$lsmeans$contrasts

## ---- eval=F------------------------------------------------------------------
#  fit_mmrm(
#    vars = list(
#      response = "FEV1",
#      covariates = c("RACE", "SEX", "FEV1_BL"),
#      id = "USUBJID",
#      arm = "ARMCD",
#      visit = "AVISIT"
#    ),
#    data = mmrm_test_data,
#    cor_struct = "compound-symmetry",
#    weights_emmeans = "equal"
#  )

## ---- eval=FALSE--------------------------------------------------------------
#  library(lme4)
#  library(emmeans)
#  
#  fit <- lmer(
#    formula = FEV1 ~ RACE + SEX + FEV1_BL + ARMCD * AVISIT + (0 + AVISIT | USUBJID),
#    data = mmrm_test_data,
#    control = lmerControl(
#      check.nobs.vs.nRE = "ignore",
#      optimizer = "nloptwrap",
#      optCtrl = list(algorithm = "NLOPT_LN_BOBYQA")
#    )
#  )
#  emmeans::emmeans(fit, mode = "satterthwaite", pairwise ~ ARMCD | AVISIT, weights = "proportional")

## ----eval=F-------------------------------------------------------------------
#  mmrm_results$diagnostics

