## -----------------------------------------------------------------------------
library(teal)
library(scda)

# specify keys x and y on a general dataset
dataset("x", data.frame(x = c(1, 1:9), y = 2:11, z = 1), keys = c("x", "y"))

# or for ADSL
adsl <- synthetic_cdisc_data("latest")$adsl
dataset("ADSL", adsl, keys = c("STUDYID", "USUBJID"))

# using cdisc_dataset keys are automatically derieved for standard datanames
# (although they can be overwritten)
adtte <- synthetic_cdisc_data("latest")$adtte
cdisc_dataset("ADTTE", adtte)

## -----------------------------------------------------------------------------
adsl <- synthetic_cdisc_data("latest")$adsl
adtte <- synthetic_cdisc_data("latest")$adtte

cdisc_data(
  cdisc_dataset(dataname = "ADSL", x = adsl, code = "ADSL <- synthetic_cdisc_data(\"latest\")$adsl"),
  cdisc_dataset(dataname = "ADTTE", x = adtte, code = "ADTTE <- synthetic_cdisc_data(\"latest\")$adtte")
)

# which is equivalent to:
example_data <- cdisc_data(
  cdisc_dataset(
    dataname = "ADSL",
    x = adsl,
    code = "ADSL <- synthetic_cdisc_data(\"latest\")$adsl",
    keys = c("STUDYID", "USUBJID")
  ),
  cdisc_dataset(
    dataname = "ADTTE",
    x = adtte,
    code = "ADTTE <- synthetic_cdisc_data(\"latest\")$adtte",
    parent = "ADSL",
    keys = c("USUBJID", "STUDYID", "PARAMCD")
  ),
  join_keys = join_keys(
    join_key("ADSL", "ADSL", c("STUDYID", "USUBJID")),
    join_key("ADTTE", "ADTTE", c("USUBJID", "STUDYID", "PARAMCD")),
    join_key("ADSL", "ADTTE", c("STUDYID", "USUBJID"))
  )
)

app <- init(
  data = example_data,
  modules = modules(example_module())
)

if (interactive()) {
  shinyApp(app$ui, app$server)
}

