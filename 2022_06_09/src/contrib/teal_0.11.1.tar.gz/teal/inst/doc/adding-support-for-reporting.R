## -----------------------------------------------------------------------------
library(teal)
teal_example_module <- function(label = "example teal module") {
  checkmate::assert_string(label)
  module(
    label,
    server = function(id, datasets) {
      moduleServer(id, function(input, output, session) {
        output$text <- renderPrint(datasets$get_data(input$dataname, filtered = TRUE))
      })
    },
    ui = function(id, datasets) {
      ns <- NS(id)
      teal.widgets::standard_layout(
        output = verbatimTextOutput(ns("text")),
        encoding = selectInput(ns("dataname"), "Choose a dataset", choices = datasets$datanames())
      )
    },
    filters = "all"
  )
}

## -----------------------------------------------------------------------------
app <- init(
  data = teal_data(
    dataset("IRIS", iris),
    dataset("MTCARS", mtcars)
  ),
  modules = modules(teal_example_module())
)

if (interactive()) shinyApp(app$ui, app$server)

## -----------------------------------------------------------------------------
example_module_with_reporting <- function(label = "example teal module") {
  checkmate::assert_string(label)
  module(
    label,
    server = function(id, datasets, reporter) {
      moduleServer(id, function(input, output, session) {
        output$text <- renderPrint(datasets$get_data(input$dataname, filtered = TRUE))
      })
    },
    ui = function(id, datasets) {
      ns <- NS(id)
      teal.widgets::standard_layout(
        output = verbatimTextOutput(ns("text")),
        encoding = selectInput(ns("dataname"), "Choose a dataset", choices = datasets$datanames())
      )
    },
    filters = "all"
  )
}

## -----------------------------------------------------------------------------
app <- init(
  data = teal_data(
    dataset("IRIS", iris),
    dataset("MTCARS", mtcars)
  ),
  modules = modules(example_module_with_reporting())
)

if (interactive()) shinyApp(app$ui, app$server)

## -----------------------------------------------------------------------------
example_module_with_reporting <- function(label = "example teal module") {
  checkmate::assert_string(label)
  module(
    label,
    server = function(id, datasets, reporter) {
      moduleServer(id, function(input, output, session) {
        teal.reporter::simple_reporter_srv(
          id = "reporter",
          reporter = reporter,
          card_fun = function(card) card
        )
        output$text <- renderPrint(datasets$get_data(input$dataname, filtered = TRUE))
      })
    },
    ui = function(id, datasets) {
      ns <- NS(id)
      teal.widgets::standard_layout(
        output = tagList(
          teal.reporter::simple_reporter_ui(ns("reporter")),
          verbatimTextOutput(ns("text"))
        ),
        encoding = selectInput(ns("dataname"), "Choose a dataset", choices = datasets$datanames())
      )
    },
    filters = "all"
  )
}

## -----------------------------------------------------------------------------
app <- init(
  data = teal_data(
    dataset("IRIS", iris),
    dataset("MTCARS", mtcars)
  ),
  modules = modules(example_module_with_reporting())
)

if (interactive()) shinyApp(app$ui, app$server)

## -----------------------------------------------------------------------------
custom_function <- function(card = teal.reporter::ReportCard$new()) {
  card$append_text("This is content from a custom teal module!")
  card
}

example_module_with_reporting <- function(label = "example teal module") {
  checkmate::assert_string(label)
  module(
    label,
    server = function(id, datasets, reporter) {
      moduleServer(id, function(input, output, session) {
        teal.reporter::simple_reporter_srv(id = "simpleReporter", reporter = reporter, card_fun = custom_function)
        output$text <- renderPrint(datasets$get_data(input$dataname, filtered = TRUE))
      })
    },
    ui = function(id, datasets) {
      ns <- NS(id)
      teal.widgets::standard_layout(
        output = tagList(
          teal.reporter::simple_reporter_ui(ns("simpleReporter")),
          verbatimTextOutput(ns("text"))
        ),
        encoding = selectInput(ns("dataname"), "Choose a dataset", choices = datasets$datanames())
      )
    },
    filters = "all"
  )
}

## -----------------------------------------------------------------------------
app <- init(
  data = teal_data(
    dataset("IRIS", iris),
    dataset("MTCARS", mtcars)
  ),
  modules = modules(example_module_with_reporting())
)

if (interactive()) shinyApp(app$ui, app$server)

## -----------------------------------------------------------------------------
custom_fun <- function(card = teal.reporter::TealReportCard$new()) {
  card
}

## -----------------------------------------------------------------------------
library(teal)
library(teal.reporter)

example_reporter_module <- function(label = "Example") {
  module(
    label,
    server = function(id, datasets, reporter) {
      moduleServer(id, function(input, output, session) {
        simple_chunks <- teal.code::chunks_new()
        dat <- reactive(dat <- datasets$get_data(input$dataname, filtered = TRUE))
        output$nrow_ui <- renderUI({
          sliderInput(session$ns("nrow"), "Number of rows:", 1, nrow(dat()), 10)
        })
        table_r <- reactive({
          req(input$nrow)
          teal.code::chunks_reset(chunks = simple_chunks)
          teal.code::chunks_push(bquote(result <- .(dat())), id = "get_data", chunks = simple_chunks)
          teal.code::chunks_push(bquote(result <- head(result, .(input$nrow))), id = "nrow", chunks = simple_chunks)
          teal.code::chunks_push(quote(result), id = "print_result", chunks = simple_chunks)
          teal.code::chunks_safe_eval(chunks = simple_chunks)
        })
        output$table <- renderTable(table_r())
        ### REPORTER
        card_fun <- function(card = ReportCard$new(), comment) {
          card$set_name("Table Module")
          card$append_text(paste("Selected dataset", input$dataname), "header2")
          card$append_text("Selected Filters", "header3")
          card$append_text(datasets$get_formatted_filter_state(), "verbatim")
          card$append_text("Encoding", "header3")
          card$append_text(
            yaml::as.yaml(
              stats::setNames(lapply(c("dataname", "nrow"), function(x) input[[x]]), c("dataname", "nrow"))
            ),
            "verbatim"
          )
          card$append_text("Module Table", "header3")
          card$append_table(table_r())
          card$append_text("Show R Code", "header3")
          card$append_text(paste(teal.code::chunks_get_rcode(simple_chunks), collapse = "\n"), "verbatim")
          if (!comment == "") {
            card$append_text("Comment", "header3")
            card$append_text(comment)
          }
          card
        }
        teal.reporter::add_card_button_srv("addReportCard", reporter = reporter, card_fun = card_fun)
        teal.reporter::download_report_button_srv("downloadButton", reporter = reporter)
        teal.reporter::reset_report_button_srv("resetButton", reporter)
        ###
      })
    },
    ui = function(id, datasets) {
      ns <- NS(id)
      teal.widgets::standard_layout(
        output = tableOutput(ns("table")),
        encoding = tagList(
          div(
            teal.reporter::add_card_button_ui(ns("addReportCard")),
            teal.reporter::download_report_button_ui(ns("downloadButton")),
            teal.reporter::reset_report_button_ui(ns("resetButton"))
          ),
          selectInput(ns("dataname"), "Choose a dataset", choices = datasets$datanames()),
          uiOutput(ns("nrow_ui"))
        )
      )
    },
    filters = "all"
  )
}

app <- init(
  data = teal_data(dataset("AIR", airquality), dataset("IRIS", iris), check = FALSE),
  modules = modules(
    example_reporter_module(label = "with Reporter"),
    example_module(label = "without Reporter")
  ),
  filter = list(AIR = list(Month = c(5, 5))),
  header = "Example teal app with reporter"
)

if (interactive()) shinyApp(app$ui, app$server)

