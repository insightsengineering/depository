## -----------------------------------------------------------------------------
# for the purpose of example save the file to the current directory
library(scda)
library(teal)
synthetic_cdisc_data("latest")$adsl
saveRDS(synthetic_cdisc_data("latest")$adsl, "adsl.rds")

## preprocessing -------------------
adsl <- readRDS("adsl.rds")
## -------------------

cs_arm <- choices_selected(c("ACTARMCD", "ARMCD"), "ACTARMCD")

app <- init(
  data = cdisc_data(cdisc_dataset("ADSL", adsl)),
  modules = modules(example_module())
)

shinyApp(app$ui, app$server)

## -----------------------------------------------------------------------------
# for the purpose of example save the file to current directory
library(scda)
library(teal)
synthetic_cdisc_data("latest")$adsl
saveRDS(synthetic_cdisc_data("latest")$adsl, "adsl.rds")

## preprocessing -------------------
adsl <- readRDS("adsl.rds")
## -------------------
unlink("adsl.rds")

cs_arm <- choices_selected(c("ACTARMCD", "ARMCD"), "ACTARMCD")

app <- init(
  data = cdisc_data(
    cdisc_dataset("ADSL", adsl),
    code = 'ADSL <- readRDS("adsl.rds")'
  ),
  modules = modules(example_module())
)

shinyApp(app$ui, app$server)

## ----eval=FALSE---------------------------------------------------------------
#  # Code needs modification before it can be run:
#  #     - save as app.R
#  # for the purpose of example save the file to current directory
#  library(scda)
#  library(teal)
#  synthetic_cdisc_data("latest")$adsl
#  saveRDS(synthetic_cdisc_data("latest")$adsl, "adsl.rds")
#  # code>
#  adsl <- readRDS("adsl.rds")
#  # <code
#  
#  cs_arm <- choices_selected(c("ACTARMCD", "ARMCD"), "ACTARMCD")
#  
#  app <- init(
#    data = cdisc_data(cdisc_dataset("ADSL", adsl), code = get_code(file = "app.R")),
#    modules = modules(example_module())
#  )
#  
#  shinyApp(app$ui, app$server)

## ----eval=FALSE---------------------------------------------------------------
#  # Code needs modification before it can be run:
#  #     - save as app.R
#  library(scda)
#  library(teal)
#  
#  # code>
#  # data import
#  adsl <- synthetic_cdisc_data("latest")$adsl
#  
#  excluded_obj1 <- 1:10 # nocode
#  
#  # nocode>
#  excluded_obj2 <- 1:10
#  # <nocode
#  
#  # <code
#  
#  x <- init(
#    data = cdisc_data(cdisc_dataset("ADSL", adsl),
#      code = get_code("app.R", exclude_comments = TRUE, read_sources = TRUE),
#      check = TRUE
#    ),
#    modules = modules(example_module()),
#    header = "Simple app with preprocessing",
#    footer = tags$p(class = "text-muted", "Source: agile-R website")
#  )
#  
#  shinyApp(x$ui, x$server)

