// This file contains functions that should be executed at the start of each session,
// not included in the original HTML

// this code alows the show R code "copy to clipbaord" button to work
var clipboard = new ClipboardJS('.btn[data-clipboard-target]');
