#' osprey: R package to create TLGs
#'
#' @description R package to create TLGs
#'
#' @import dplyr ggplot2
#' @importFrom rlang .data :=
#' @docType package
#' @name osprey
#' @keywords internal
NULL
