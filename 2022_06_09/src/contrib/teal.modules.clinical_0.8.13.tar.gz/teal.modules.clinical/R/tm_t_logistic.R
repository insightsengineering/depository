#' Template: Logistic Regression
#'
#' Creates an expression for logistic regressions.
#'
#' @inheritParams template_arguments
#' @param arm_var (`character`)\cr
#'   variable names that can be used as `arm_var`. No arm or treatment variable is included in the logistic model is
#'   being `NULL`.
#' @param topleft (`character`)\cr
#'  the top-left annotation in the table.
#' @param at optional, (`NULL` or `numeric`)\cr
#'  values for the interaction variable. Otherwise the median is used.
#' @param interaction_var (`character`)\cr
#'  names of the variables that can be used for interaction variable selection.
#' @param responder_val (`character`)\cr
#'  values of the responder variable corresponding with a successful response.
#' @param paramcd (`character`)\cr response parameter value to use in the table title.
#' @param label_paramcd (`character`)\cr Label of response parameter value to use in the table title.
#'
#' @seealso [tm_t_logistic()]
#' @keywords internal
#'
template_logistic <- function(dataname,
                              arm_var,
                              aval_var,
                              paramcd,
                              label_paramcd,
                              cov_var,
                              interaction_var,
                              ref_arm,
                              comp_arm,
                              topleft = "Logistic Regression",
                              conf_level = 0.95,
                              combine_comp_arms = FALSE,
                              responder_val = c("CR", "PR"),
                              at = NULL,
                              basic_table_args = teal.widgets::basic_table_args()) {
  # Common assertion no matter if arm_var is NULL or not.
  assertthat::assert_that(
    assertthat::is.string(dataname),
    assertthat::is.string(aval_var),
    assertthat::is.string(paramcd),
    assertthat::is.string(label_paramcd) || is.null(label_paramcd),
    assertthat::is.string(topleft) || is.null(topleft),
    is.character(cov_var) || is.null(cov_var),
    assertthat::is.string(interaction_var) || is.null(interaction_var)
  )

  y <- list()

  data_pipe <- list()
  data_list <- list()

  # Conditional assertion depends on if arm_var isn't NULL.
  if (!is.null(arm_var)) {
    assertthat::assert_that(
      assertthat::is.string(arm_var),
      assertthat::is.flag(combine_comp_arms)
    )

    ref_arm_val <- paste(ref_arm, collapse = "/")

    y$arm_lab <- substitute(
      expr = arm_var_lab <- formatters::var_labels(anl[arm_var], fill = FALSE),
      env = list(anl = as.name(dataname), arm_var = arm_var)
    )

    # Start to build data when arm_var is not NULL.
    data_pipe <- add_expr(
      data_pipe,
      prepare_arm(
        dataname = dataname,
        arm_var = arm_var,
        ref_arm = ref_arm,
        comp_arm = comp_arm,
        ref_arm_val = ref_arm_val
      )
    )

    if (combine_comp_arms) {
      data_pipe <- add_expr(
        data_pipe,
        substitute_names(
          expr = dplyr::mutate(arm_var = combine_levels(x = arm_var, levels = comp_arm)),
          names = list(arm_var = as.name(arm_var)),
          others = list(comp_arm = comp_arm)
        )
      )
    }

    data_list <- add_expr(
      data_list,
      substitute(
        expr = ANL <- data_pipe, # nolint
        env = list(data_pipe = pipe_expr(data_pipe))
      )
    )
  }

  data_list <- add_expr(
    data_list,
    substitute(
      expr = ANL <- df %>% # nolint
        dplyr::mutate(Response = aval_var %in% responder_val) %>%
        df_explicit_na(na_level = ""),
      env = list(df = as.name("ANL"), aval_var = as.name(aval_var), responder_val = responder_val)
    )
  )

  y$data <- bracket_expr(data_list)

  if (!is.null(arm_var)) {
    y$relabel <- substitute(
      expr = formatters::var_labels(ANL[arm_var]) <- arm_var_lab, # nolint
      env = list(arm_var = arm_var)
    )
  }

  model_list <- list()
  model_list <- if (is.null(interaction_var)) {
    add_expr(
      model_list,
      substitute(
        expr = fit_logistic(
          ANL,
          variables = list(response = "Response", arm = arm_var, covariates = cov_var)
        ),
        env = list(arm_var = arm_var, cov_var = cov_var)
      )
    )
  } else {
    add_expr(
      model_list,
      substitute(
        expr = fit_logistic(
          ANL,
          variables = list(
            response = "Response", arm = arm_var, covariates = cov_var,
            interaction = interaction_var
          )
        ),
        env = list(arm_var = arm_var, cov_var = cov_var, interaction_var = interaction_var)
      )
    )
  }

  model_list <- if (is.null(interaction_var)) {
    add_expr(
      model_list,
      substitute(
        expr = broom::tidy(conf_level = conf_level),
        env = list(conf_level = conf_level)
      )
    )
  } else {
    add_expr(
      model_list,
      substitute(
        expr = broom::tidy(conf_level = conf_level, at = at),
        env = list(conf_level = conf_level, at = at)
      )
    )
  }

  model_list <- add_expr(model_list, quote(df_explicit_na(na_level = "")))

  y$model <- substitute(
    expr = mod <- model_pipe,
    env = list(model_pipe = pipe_expr(model_list))
  )

  layout_list <- list()

  basic_title <- if (length(responder_val) > 1) {
    paste(
      "Summary of Logistic Regression Analysis for", label_paramcd, "for",
      paste(utils::head(responder_val, -1), collapse = ", "),
      "and", utils::tail(responder_val, 1), "Responders"
    )
  } else {
    paste("Summary of Logistic Regression Analysis for", label_paramcd, "for", responder_val, "Responders")
  }



  parsed_basic_table_args <- teal.widgets::parse_basic_table_args(
    teal.widgets::resolve_basic_table_args(
      user_table = basic_table_args,
      module_table = teal.widgets::basic_table_args(title = basic_title)
    )
  )

  y$table <- substitute(
    expr = {
      result <- expr_basic_table_args %>%
        summarize_logistic(conf_level = conf_level) %>%
        rtables::append_topleft(topleft) %>%
        rtables::build_table(df = mod)
      result
    },
    env = list(
      expr_basic_table_args = parsed_basic_table_args,
      conf_level = conf_level,
      topleft = topleft
    )
  )

  y
}


#' Teal Module: Logistic Regression
#'
#' @description This module produces a multi-variable logistic regression table that matches the
#'   STREAM template `lgrt02`.
#'
#' @inheritParams module_arguments
#' @param arm_var ([teal.transform::choices_selected()] or [teal.transform::data_extract_spec()]) or `NULL`\cr
#'   object with all available choices
#'   and preselected option for variable names that can be used as `arm_var`.
#'   It defines the grouping variable(s) in the results table. If there are two elements selected for `arm_var`,
#'   second variable will be nested under the first variable.
#'   arm_var is optional, when being NULL, no arm or treatment variable is included in the logistic model.
#' @param avalc_var ([teal.transform::choices_selected()] or [teal.transform::data_extract_spec()])\cr
#'  object with all available choices and preselected option for the analysis variable (categorical).
#'
#' @export
#' @examples
#'
#' library(scda)
#' library(dplyr)
#' ADSL <- synthetic_cdisc_data("latest")$adsl
#' ADRS <- synthetic_cdisc_data("latest")$adrs %>%
#'   filter(PARAMCD %in% c("BESRSPI", "INVET"))
#'
#' arm_ref_comp <- list(
#'   ACTARMCD = list(
#'     ref = "ARM B",
#'     comp = c("ARM A", "ARM C")
#'   ),
#'   ARM = list(
#'     ref = "B: Placebo",
#'     comp = c("A: Drug X", "C: Combination")
#'   )
#' )
#'
#' app <- init(
#'   data = cdisc_data(
#'     cdisc_dataset("ADSL", ADSL, code = 'ADSL <- synthetic_cdisc_data("latest")$adsl'),
#'     cdisc_dataset("ADRS", ADRS, code = 'ADRS <- synthetic_cdisc_data("latest")$adrs %>%
#'       filter(PARAMCD %in% c("BESRSPI", "INVET"))'),
#'     check = TRUE
#'   ),
#'   modules = modules(
#'     tm_t_logistic(
#'       label = "Logistic Regression",
#'       dataname = "ADRS",
#'       arm_var = choices_selected(
#'         choices = variable_choices(ADRS, c("ARM", "ARMCD")),
#'         selected = "ARM"
#'       ),
#'       arm_ref_comp = arm_ref_comp,
#'       paramcd = choices_selected(
#'         choices = value_choices(ADRS, "PARAMCD", "PARAM"),
#'         selected = "BESRSPI"
#'       ),
#'       cov_var = choices_selected(
#'         choices = c("SEX", "AGE", "BMRKR1", "BMRKR2"),
#'         selected = "SEX"
#'       )
#'     )
#'   )
#' )
#' \dontrun{
#' shinyApp(ui = app$ui, server = app$server)
#' }
#'
tm_t_logistic <- function(label,
                          dataname,
                          parentname = ifelse(
                            inherits(arm_var, "data_extract_spec"),
                            teal.transform::datanames_input(arm_var),
                            "ADSL"
                          ),
                          arm_var = NULL,
                          arm_ref_comp = NULL,
                          paramcd,
                          cov_var = NULL,
                          avalc_var = teal.transform::choices_selected(
                            teal.transform::variable_choices(dataname, "AVALC"), "AVALC",
                            fixed = TRUE
                          ),
                          conf_level = teal.transform::choices_selected(c(0.95, 0.9, 0.8), 0.95, keep_order = TRUE),
                          pre_output = NULL,
                          post_output = NULL,
                          basic_table_args = teal.widgets::basic_table_args()) {
  logger::log_info("Initializing tm_t_logistic")
  checkmate::assert_string(label)
  checkmate::assert_string(dataname)
  checkmate::assert_string(parentname)
  checkmate::assert_class(avalc_var, classes = "choices_selected")
  checkmate::assert_class(conf_level, classes = "choices_selected")
  checkmate::assert_class(pre_output, classes = "shiny.tag", null.ok = TRUE)
  checkmate::assert_class(post_output, classes = "shiny.tag", null.ok = TRUE)
  checkmate::assert_class(basic_table_args, "basic_table_args")

  args <- as.list(environment())

  data_extract_list <- list(
    arm_var = `if`(is.null(arm_var), NULL, cs_to_des_select(arm_var, dataname = parentname)),
    paramcd = cs_to_des_filter(paramcd, dataname = dataname),
    avalc_var = cs_to_des_select(avalc_var, dataname = dataname),
    cov_var = cs_to_des_select(cov_var, dataname = dataname, multiple = TRUE)
  )

  module(
    label = label,
    server = srv_t_logistic,
    ui = ui_t_logistic,
    ui_args = c(data_extract_list, args),
    server_args = c(
      data_extract_list,
      list(
        arm_ref_comp = arm_ref_comp,
        label = label,
        dataname = dataname,
        parentname = parentname,
        basic_table_args = basic_table_args
      )
    ),
    filters = teal.transform::get_extract_datanames(data_extract_list)
  )
}

#' User Interface for `tm_t_logistic`
#' @noRd
#'
ui_t_logistic <- function(id, ...) {
  a <- list(...)
  if (!is.null(a$arm_var)) {
    is_single_dataset_value <- teal.transform::is_single_dataset(
      a$arm_var,
      a$paramcd,
      a$avalc_var,
      a$cov_var
    )
  } else {
    is_single_dataset_value <- teal.transform::is_single_dataset(
      a$paramcd,
      a$avalc_var,
      a$cov_var
    )
  }


  ns <- shiny::NS(id)
  teal.widgets::standard_layout(
    output = teal.widgets::white_small_well(
      teal.widgets::table_with_settings_ui(ns("table"))
    ),
    encoding = shiny::div(
      shiny::tags$label("Encodings", class = "text-primary"),
      teal.transform::datanames_input(a[c("arm_var", "paramcd", "avalc_var", "cov_var")]),
      teal.transform::data_extract_ui(
        id = ns("paramcd"),
        label = "Select Endpoint",
        data_extract_spec = a$paramcd,
        is_single_dataset = is_single_dataset_value
      ),
      teal.transform::data_extract_ui(
        id = ns("avalc_var"),
        label = "Analysis Variable",
        data_extract_spec = a$avalc_var,
        is_single_dataset = is_single_dataset_value
      ),
      shiny::selectInput(
        ns("responders"),
        "Responders",
        choices = c("CR", "PR"),
        selected = c("CR", "PR"),
        multiple = TRUE
      ),
      if (!is.null(a$arm_var)) {
        shiny::div(
          teal.transform::data_extract_ui(
            id = ns("arm_var"),
            label = "Select Treatment Variable",
            data_extract_spec = a$arm_var,
            is_single_dataset = is_single_dataset_value
          ),
          shiny::selectInput(
            ns("ref_arm"),
            "Reference Group",
            choices = NULL,
            multiple = TRUE
          ),
          shiny::selectInput(
            ns("comp_arm"),
            "Comparison Group",
            choices = NULL,
            multiple = TRUE
          ),
          shiny::checkboxInput(
            ns("combine_comp_arms"),
            "Combine all comparison groups?",
            value = FALSE
          )
        )
      },
      teal.transform::data_extract_ui(
        id = ns("cov_var"),
        label = "Covariates",
        data_extract_spec = a$cov_var,
        is_single_dataset = is_single_dataset_value
      ),
      shiny::uiOutput(ns("interaction_var")),
      shiny::uiOutput(ns("interaction_input")),
      teal.widgets::optionalSelectInput(
        inputId = ns("conf_level"),
        label = shiny::p(
          "Confidence level for ",
          shiny::span(style = "color:darkblue", "Coxph"),
          " (Hazard Ratio)",
          sep = ""
        ),
        a$conf_level$choices,
        a$conf_level$selected,
        multiple = FALSE,
        fixed = a$conf_level$fixed
      )
    ),
    forms = teal::get_rcode_ui(ns("rcode")),
    pre_output = a$pre_output,
    post_output = a$post_output
  )
}

#' Server Function for `tm_t_logistic`
#' @noRd
#'
srv_t_logistic <- function(id,
                           datasets,
                           dataname,
                           parentname,
                           arm_var,
                           arm_ref_comp,
                           paramcd,
                           avalc_var,
                           cov_var,
                           label,
                           basic_table_args) {
  stopifnot(is_cdisc_data(datasets))
  shiny::moduleServer(id, function(input, output, session) {
    teal.code::init_chunks()

    # Observer to update reference and comparison arm input options.
    if (!is.null(arm_var)) {
      arm_ref_comp_observer(
        session,
        input,
        id_ref = "ref_arm",
        id_comp = "comp_arm",
        id_arm_var = extract_input("arm_var", parentname),
        datasets = datasets,
        dataname = parentname,
        arm_ref_comp = arm_ref_comp,
        module = "tm_t_logistic"
      )
    }

    anl_merged <- teal.transform::data_merge_module(
      datasets = datasets,
      data_extract = list(arm_var = arm_var, paramcd = paramcd, avalc_var = avalc_var, cov_var = cov_var),
      merge_function = "dplyr::inner_join"
    )

    if (!is.null(arm_var)) {
      adsl_merged <- teal.transform::data_merge_module(
        datasets = datasets,
        data_extract = list(arm_var = arm_var),
        anl_name = "ANL_ADSL"
      )
    }

    # Because the AVALC values depends on the selected PARAMCD.
    shiny::observeEvent(anl_merged(), {
      avalc_var <- anl_merged()$columns_source$avalc_var
      if (nrow(anl_merged()$data()) == 0) {
        responder_choices <- c("CR", "PR")
        responder_sel <- c("CR", "PR")
      } else {
        responder_choices <- unique(anl_merged()$data()[[avalc_var]])
        responder_sel <- intersect(responder_choices, shiny::isolate(input$responders))
      }
      shiny::updateSelectInput(
        session, "responders",
        choices = responder_choices,
        selected = responder_sel
      )
    })

    output$interaction_var <- shiny::renderUI({
      anl_m <- anl_merged()
      cov_var <- as.vector(anl_m$columns_source$cov_var)
      if (length(cov_var) > 0) {
        teal.widgets::optionalSelectInput(
          session$ns("interaction_var"),
          label = "Interaction",
          choices = cov_var,
          selected = NULL,
          multiple = FALSE
        )
      } else {
        NULL
      }
    })

    output$interaction_input <- shiny::renderUI({
      anl_m <- anl_merged()
      interaction_var <- input$interaction_var
      if (length(interaction_var) > 0) {
        if (is.numeric(anl_m$data()[[interaction_var]])) {
          shiny::tagList(
            shiny::textInput(
              session$ns("interaction_values"),
              label = sprintf("Specify %s values (comma delimited) for treatment ORs calculation:", interaction_var),
              value = as.character(stats::median(anl_m$data()[[interaction_var]]))
            )
          )
        }
      } else {
        NULL
      }
    })

    validate_checks <- shiny::reactive({
      adsl_filtered <- datasets$get_data(parentname, filtered = TRUE)
      anl_filtered <- datasets$get_data(dataname, filtered = TRUE)

      anl_m <- anl_merged()
      input_arm_var <- as.vector(anl_m$columns_source$arm_var)
      input_avalc_var <- as.vector(anl_m$columns_source$avalc_var)
      input_cov_var <- as.vector(anl_m$columns_source$cov_var)
      input_paramcd <- unlist(paramcd$filter)["vars_selected"]
      input_interaction_var <- input$interaction_var

      input_interaction_at <- input_interaction_var[input_interaction_var %in% input_cov_var]
      interaction_flag <- length(input_interaction_at) != 0

      at_values <- if (is.null(input$interaction_values)) {
        NA
      } else {
        unlist(as_num(input$interaction_values))
      }

      # validate inputs
      validate_args <- list(
        adsl = adsl_filtered,
        adslvars = c("USUBJID", "STUDYID", input_arm_var),
        anl = anl_filtered,
        anlvars = c("USUBJID", "STUDYID", input_paramcd, input_avalc_var, input_cov_var),
        arm_var = input_arm_var,
        ref_arm = input$ref_arm,
        comp_arm = input$comp_arm,
        min_nrow = 4
      )

      shiny::validate(shiny::need(
        input$conf_level >= 0 && input$conf_level <= 1,
        "Please choose a confidence level between 0 and 1"
      ))

      # validate arm levels
      if (!is.null(arm_var)) {
        if (length(input_arm_var) > 0 && length(unique(adsl_filtered[[input_arm_var]])) == 1) {
          validate_args <- append(validate_args, list(min_n_levels_armvar = NULL))
        }

        do.call(what = "validate_standard_inputs", validate_args)

        arm_n <- base::table(anl_m$data()[[input_arm_var]])
        anl_arm_n <- if (input$combine_comp_arms) {
          c(sum(arm_n[input$ref_arm]), sum(arm_n[input$comp_arm]))
        } else {
          c(sum(arm_n[input$ref_arm]), arm_n[input$comp_arm])
        }
        shiny::validate(shiny::need(
          all(anl_arm_n >= 2),
          "Each treatment group should have at least 2 records."
        ))
      }

      shiny::validate(
        shiny::need(checkmate::test_string(input_avalc_var), "Analysis variable should be a single column."),
        shiny::need(input$responders, "`Responders` field is empty")
      )

      # validate interaction values
      if (interaction_flag && (is.numeric(anl_m$data()[[input_interaction_at]]))) {
        shiny::validate(shiny::need(
          !is.na(at_values),
          "If interaction is specified the level should be entered."
        ))
      }

      # validate covariate has at least two levels
      shiny::validate(
        shiny::need(
          all(
            vapply(
              anl_m$data()[input_cov_var],
              FUN = function(x) {
                length(unique(x)) > 1
              },
              logical(1)
            )
          ),
          "All covariates need to have at least two levels"
        )
      )
    })

    call_preparation <- shiny::reactive({
      validate_checks()

      teal.code::chunks_reset()
      anl_m <- anl_merged()
      teal.code::chunks_push_data_merge(anl_m)
      teal.code::chunks_push_new_line()

      if (!is.null(arm_var)) {
        anl_adsl <- adsl_merged()
        teal.code::chunks_push_data_merge(anl_adsl)
        teal.code::chunks_push_new_line()
      }

      ANL <- teal.code::chunks_get_var("ANL") # nolint

      label_paramcd <- get_paramcd_label(ANL, paramcd)

      paramcd <- as.character(unique(ANL[[unlist(paramcd$filter)["vars_selected"]]]))

      interaction_var <- input$interaction_var
      interaction_flag <- length(interaction_var) != 0

      at_values <- if (is.null(input$interaction_values)) {
        NA
      } else {
        unlist(as_num(input$interaction_values))
      }
      at_flag <- interaction_flag && is.numeric(anl_m$data()[[interaction_var]])

      cov_var <- as.vector(anl_m$columns_source$cov_var)

      calls <- template_logistic(
        dataname = "ANL",
        arm_var = as.vector(anl_m$columns_source$arm_var),
        aval_var = as.vector(anl_m$columns_source$avalc_var),
        paramcd = paramcd,
        label_paramcd = label_paramcd,
        cov_var = if (length(cov_var) > 0) cov_var else NULL,
        interaction_var = if (interaction_flag) interaction_var else NULL,
        ref_arm = input$ref_arm,
        comp_arm = input$comp_arm,
        combine_comp_arms = input$combine_comp_arms,
        topleft = paramcd,
        conf_level = as.numeric(input$conf_level),
        at = if (at_flag) at_values else NULL,
        responder_val = input$responders,
        basic_table_args = basic_table_args
      )

      mapply(expression = calls, id = paste(names(calls), "call", sep = "_"), teal.code::chunks_push)
    })

    table <- shiny::reactive({
      call_preparation()
      teal.code::chunks_safe_eval()
      teal.code::chunks_get_var("result")
    })

    teal.widgets::table_with_settings_srv(
      id = "table",
      table_r = table
    )

    teal::get_rcode_srv(
      id = "rcode",
      datasets = datasets,
      datanames = teal.transform::get_extract_datanames(
        list(arm_var, paramcd, avalc_var, cov_var)
      ),
      modal_title = "R Code for the Current Logistic Regression",
      code_header = label
    )
  })
}
