# scda.2021 0.1.3

* Updated `README` file.

# scda.2021 0.1.2

* Updated R version requirement to >= 3.6.
* Added `rcd_2021_10_13` data to the package.
* Updated data to include `ADPP` and `ADPC`.

# scda.2021 0.1.1

* Updated `LICENCE` and `README` with new package references.
* Added `rcd_2021_07_07` data to the package.
* Added `error_on_lint: TRUE` to `.lintr`.

# scda.2021 0.1.0

* Added a `NEWS.md` file to track changes to the package.
